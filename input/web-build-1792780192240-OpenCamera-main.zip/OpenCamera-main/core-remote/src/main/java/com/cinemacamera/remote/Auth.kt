package com.cinemacamera.remote

import java.security.SecureRandom
import java.util.Base64
import java.util.Collections

/**
 * PIN pairing + opaque bearer-token session auth for the remote server.
 * A fresh 6-digit PIN is generated at construction and whenever
 * [regeneratePin] is called; any previously paired tokens still stay valid
 * (regenerating the PIN only affects future pairing attempts).
 */
class SessionAuth {
    private val secureRandom = SecureRandom()
    private val tokens: MutableSet<String> = Collections.synchronizedSet(mutableSetOf())

    @Volatile
    var pin: String = generatePin()
        private set

    fun regeneratePin(): String {
        pin = generatePin()
        return pin
    }

    /** Returns a fresh session token if [candidatePin] matches the current PIN, else null. */
    fun pair(candidatePin: String): String? {
        if (candidatePin != pin) return null
        val bytes = ByteArray(32)
        secureRandom.nextBytes(bytes)
        val token = Base64.getUrlEncoder().withoutPadding().encodeToString(bytes)
        tokens.add(token)
        return token
    }

    fun isValid(token: String?): Boolean = token != null && tokens.contains(token)

    private fun generatePin(): String {
        val n = secureRandom.nextInt(1_000_000)
        return n.toString().padStart(6, '0')
    }
}
