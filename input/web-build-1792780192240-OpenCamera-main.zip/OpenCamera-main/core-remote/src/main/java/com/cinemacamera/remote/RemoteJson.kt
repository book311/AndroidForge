package com.cinemacamera.remote

import com.cinemacamera.domain.AutoTrack
import com.cinemacamera.domain.AutoTrackKind
import com.cinemacamera.domain.CaptureSettings
import com.cinemacamera.domain.Easing
import com.cinemacamera.domain.ExposureSettings
import com.cinemacamera.domain.Keyframe
import com.cinemacamera.domain.LogProfile
import com.cinemacamera.domain.OutputMode
import com.cinemacamera.domain.Preset
import com.cinemacamera.domain.ProcessingToggles
import com.cinemacamera.domain.Sequence
import com.cinemacamera.domain.SlateInfo
import com.cinemacamera.domain.VideoCodec
import org.json.JSONArray
import org.json.JSONObject

/**
 * JSON (de)serializers shared by the web control panel and the REST API.
 * Field names for [CaptureSettings] MUST match app/PresetsRepository.kt's
 * on-disk preset schema so the web app and presets agree on keys.
 */
object RemoteJson {

    fun settingsToJson(s: CaptureSettings): JSONObject = JSONObject().apply {
        put("sensorId", s.sensorId ?: JSONObject.NULL)
        put("rawWidth", s.rawWidth)
        put("rawHeight", s.rawHeight)
        put("fps", s.fps)
        put("guideAspect", s.guideAspect.toDouble())
        put("autoExposure", s.exposure.auto)
        put("iso", s.exposure.iso)
        put("shutterNs", s.exposure.shutterNs)
        put("shutterAngle", s.exposure.shutterAngle.toDouble())
        put("focusDiopters", s.focusDiopters.toDouble())
        put("logProfile", s.logProfile.name)
        put("encodeFullRes", s.encodeFullRes)
        put("bitrateMbps", s.bitrateMbps)
        put("codec", s.codec.name)
        put("outputMode", s.outputMode.name)
        put("acesIdt", s.acesIdt)
        put("previewLutName", s.previewLutName ?: JSONObject.NULL)
        put("audioEnabled", s.audioEnabled)
        val t = s.processing
        put("noiseReduction", t.noiseReduction)
        put("edgeEnhancement", t.edgeEnhancement)
        put("lensShading", t.lensShading)
        put("hotPixel", t.hotPixel)
        put("aberrationCorrection", t.aberrationCorrection)
        put("distortionCorrection", t.distortionCorrection)
        put("forceIdentityTonemap", t.forceIdentityTonemap)
        put("videoStabilization", t.videoStabilization)
    }

    /** Only overwrites keys present in [patch]; everything else is left as-is in [current]. */
    fun applySettingsPatch(current: CaptureSettings, patch: JSONObject): CaptureSettings {
        var s = current
        if (patch.has("sensorId")) {
            s = s.copy(sensorId = if (patch.isNull("sensorId")) null else patch.optString("sensorId").ifEmpty { null })
        }
        if (patch.has("rawWidth")) s = s.copy(rawWidth = patch.optInt("rawWidth", s.rawWidth))
        if (patch.has("rawHeight")) s = s.copy(rawHeight = patch.optInt("rawHeight", s.rawHeight))
        if (patch.has("fps")) s = s.copy(fps = patch.optInt("fps", s.fps))
        if (patch.has("guideAspect")) s = s.copy(guideAspect = patch.optDouble("guideAspect", s.guideAspect.toDouble()).toFloat())
        if (patch.has("focusDiopters")) s = s.copy(focusDiopters = patch.optDouble("focusDiopters", s.focusDiopters.toDouble()).toFloat())
        if (patch.has("logProfile")) {
            s = s.copy(logProfile = runCatching { LogProfile.valueOf(patch.optString("logProfile")) }.getOrDefault(s.logProfile))
        }
        if (patch.has("encodeFullRes")) s = s.copy(encodeFullRes = patch.optBoolean("encodeFullRes", s.encodeFullRes))
        if (patch.has("bitrateMbps")) s = s.copy(bitrateMbps = patch.optInt("bitrateMbps", s.bitrateMbps))
        if (patch.has("codec")) {
            s = s.copy(codec = runCatching { VideoCodec.valueOf(patch.optString("codec")) }.getOrDefault(s.codec))
        }
        if (patch.has("outputMode")) {
            s = s.copy(outputMode = runCatching { OutputMode.valueOf(patch.optString("outputMode")) }
                .getOrDefault(s.outputMode))
        }
        if (patch.has("acesIdt")) s = s.copy(acesIdt = patch.optBoolean("acesIdt", s.acesIdt))
        if (patch.has("previewLutName")) {
            s = s.copy(previewLutName = if (patch.isNull("previewLutName")) null else patch.optString("previewLutName").ifEmpty { null })
        }
        if (patch.has("audioEnabled")) s = s.copy(audioEnabled = patch.optBoolean("audioEnabled", s.audioEnabled))

        var exposure: ExposureSettings = s.exposure
        var exposureChanged = false
        if (patch.has("autoExposure")) {
            exposure = exposure.copy(auto = patch.optBoolean("autoExposure", exposure.auto)); exposureChanged = true
        }
        if (patch.has("iso")) {
            exposure = exposure.copy(iso = patch.optInt("iso", exposure.iso)); exposureChanged = true
        }
        if (patch.has("shutterNs")) {
            exposure = exposure.copy(shutterNs = patch.optLong("shutterNs", exposure.shutterNs)); exposureChanged = true
        }
        if (patch.has("shutterAngle")) {
            exposure = exposure.copy(shutterAngle = patch.optDouble("shutterAngle", exposure.shutterAngle.toDouble()).toFloat())
            exposureChanged = true
        }
        if (exposureChanged) s = s.copy(exposure = exposure)

        var proc: ProcessingToggles = s.processing
        var procChanged = false
        if (patch.has("noiseReduction")) { proc = proc.copy(noiseReduction = patch.optBoolean("noiseReduction", proc.noiseReduction)); procChanged = true }
        if (patch.has("edgeEnhancement")) { proc = proc.copy(edgeEnhancement = patch.optBoolean("edgeEnhancement", proc.edgeEnhancement)); procChanged = true }
        if (patch.has("lensShading")) { proc = proc.copy(lensShading = patch.optBoolean("lensShading", proc.lensShading)); procChanged = true }
        if (patch.has("hotPixel")) { proc = proc.copy(hotPixel = patch.optBoolean("hotPixel", proc.hotPixel)); procChanged = true }
        if (patch.has("aberrationCorrection")) { proc = proc.copy(aberrationCorrection = patch.optBoolean("aberrationCorrection", proc.aberrationCorrection)); procChanged = true }
        if (patch.has("distortionCorrection")) { proc = proc.copy(distortionCorrection = patch.optBoolean("distortionCorrection", proc.distortionCorrection)); procChanged = true }
        if (patch.has("forceIdentityTonemap")) { proc = proc.copy(forceIdentityTonemap = patch.optBoolean("forceIdentityTonemap", proc.forceIdentityTonemap)); procChanged = true }
        if (patch.has("videoStabilization")) { proc = proc.copy(videoStabilization = patch.optBoolean("videoStabilization", proc.videoStabilization)); procChanged = true }
        if (procChanged) s = s.copy(processing = proc)

        return s
    }

    fun slateToJson(s: SlateInfo): JSONObject = JSONObject().apply {
        put("roll", s.roll)
        put("scene", s.scene)
        put("take", s.take)
    }

    fun applySlatePatch(current: SlateInfo, patch: JSONObject): SlateInfo {
        var s = current
        if (patch.has("roll")) s = s.copy(roll = patch.optString("roll", s.roll))
        if (patch.has("scene")) s = s.copy(scene = patch.optString("scene", s.scene))
        if (patch.has("take")) s = s.copy(take = patch.optInt("take", s.take))
        return s
    }

    fun presetToJson(p: Preset): JSONObject =
        settingsToJson(p.settings).apply { put("name", p.name) }

    fun sequenceToJson(seq: Sequence): JSONObject = JSONObject().apply {
        put("name", seq.name)
        put("durationMs", seq.durationMs)
        put("schemaVersion", seq.schemaVersion)
        put("tracks", JSONArray().apply {
            seq.tracks.forEach { track ->
                put(JSONObject().apply {
                    put("kind", track.kind.name)
                    put("keyframes", JSONArray().apply {
                        track.keyframes.forEach { kf ->
                            put(JSONObject().apply {
                                put("t", kf.timeMs)
                                put("v", kf.value)
                                put("e", kf.easing.name)
                            })
                        }
                    })
                })
            }
        })
    }

    fun sequenceFromJson(o: JSONObject): Sequence {
        val tracksArr = o.optJSONArray("tracks") ?: JSONArray()
        val tracks = (0 until tracksArr.length()).map { i ->
            val t = tracksArr.getJSONObject(i)
            val kfArr = t.optJSONArray("keyframes") ?: JSONArray()
            val keyframes = (0 until kfArr.length()).map { j ->
                val k = kfArr.getJSONObject(j)
                Keyframe(
                    timeMs = k.getLong("t"),
                    value = k.getDouble("v"),
                    easing = runCatching { Easing.valueOf(k.optString("e")) }.getOrDefault(Easing.SMOOTH),
                )
            }.sortedBy { it.timeMs }
            AutoTrack(kind = AutoTrackKind.valueOf(t.getString("kind")), keyframes = keyframes)
        }
        return Sequence(
            name = o.getString("name"),
            durationMs = o.optLong("durationMs", 5000L),
            tracks = tracks,
            schemaVersion = o.optInt("schemaVersion", 1),
        )
    }
}
