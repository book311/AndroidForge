package com.cinemacamera.remote

import android.content.Context
import android.net.nsd.NsdManager
import android.net.nsd.NsdServiceInfo
import android.os.Build
import android.util.Log
import dagger.hilt.android.qualifiers.ApplicationContext
import io.ktor.http.ContentDisposition
import io.ktor.http.ContentType
import io.ktor.http.HttpHeaders
import io.ktor.http.HttpStatusCode
import io.ktor.server.application.ApplicationCall
import io.ktor.server.application.call
import io.ktor.server.application.install
import io.ktor.server.cio.CIO
import io.ktor.server.engine.ApplicationEngine
import io.ktor.server.engine.embeddedServer
import io.ktor.server.request.receiveText
import io.ktor.server.response.header
import io.ktor.server.response.respond
import io.ktor.server.response.respondBytes
import io.ktor.server.response.respondFile
import io.ktor.server.response.respondText
import io.ktor.server.routing.get
import io.ktor.server.routing.post
import io.ktor.server.routing.routing
import io.ktor.server.websocket.WebSockets
import java.net.Inet4Address
import java.net.NetworkInterface
import javax.inject.Inject
import javax.inject.Singleton
import org.json.JSONObject

private const val TAG = "RemoteServer"
private const val PORT = 8080

/** Service type OpenMotionFX Nodes/Conductor discover cameras under. */
private const val NSD_SERVICE_TYPE = "_openmotionfx._tcp."

/**
 * Embedded Ktor/CIO HTTP server that runs in-process and exposes the "Laptop
 * Director" web control panel + REST API described in V10a. Holds no camera
 * logic itself: everything mutating state goes through the injected
 * [RemoteController] (implemented by MainViewModel).
 */
@Singleton
class RemoteServer @Inject constructor(
    @ApplicationContext private val context: Context,
) {
    private val auth = SessionAuth()

    @Volatile
    private var controller: RemoteController? = null

    @Volatile
    private var engine: ApplicationEngine? = null

    @Volatile
    private var nsdRegistrationListener: NsdManager.RegistrationListener? = null

    val pin: String get() = auth.pin

    fun regeneratePin(): String = auth.regeneratePin()

    /** Idempotent: does nothing if already running. */
    fun start(controller: RemoteController) {
        if (engine != null) {
            this.controller = controller
            return
        }
        this.controller = controller
        engine = embeddedServer(CIO, host = "0.0.0.0", port = PORT) {
            install(WebSockets)
            routing {
                get("/") { serveIndex(call) }
                get("/index.html") { serveIndex(call) }

                // Fonts served from assets so the web UI matches the app's type
                // (Manrope for chrome, JetBrains Mono for telemetry). No auth:
                // the pairing screen needs them too.
                get("/fonts/manrope.ttf") { serveAsset(call, "web/fonts/manrope.ttf") }
                get("/fonts/jetbrains-mono.ttf") { serveAsset(call, "web/fonts/jetbrains-mono.ttf") }

                post("/api/pair") { handlePair(call) }

                get("/api/status") { withController(call) { c -> call.respondJson(c.statusJson()) } }

                get("/api/settings") { withController(call) { c -> call.respondJson(c.settingsJson()) } }
                post("/api/settings") {
                    withController(call) { c ->
                        val patch = JSONObject(call.receiveText())
                        c.applySettingsPatch(patch)
                        call.respondJson(c.settingsJson())
                    }
                }

                post("/api/record") {
                    withController(call) { c ->
                        val body = JSONObject(call.receiveText())
                        c.setRecording(body.optBoolean("on", false))
                        call.respondJson(c.statusJson())
                    }
                }

                get("/api/slate") { withController(call) { c -> call.respondJson(c.slateJson()) } }
                post("/api/slate") {
                    withController(call) { c ->
                        val patch = JSONObject(call.receiveText())
                        c.updateSlatePatch(patch)
                        call.respondJson(c.slateJson())
                    }
                }

                get("/api/presets") { withController(call) { c -> call.respondJson(c.presetsJson()) } }
                post("/api/presets/apply") {
                    withController(call) { c ->
                        val body = JSONObject(call.receiveText())
                        c.applyPreset(body.optString("name"))
                        call.respondJson(c.presetsJson())
                    }
                }
                post("/api/presets/save") {
                    withController(call) { c ->
                        val body = JSONObject(call.receiveText())
                        c.savePreset(body.optString("name"))
                        call.respondJson(c.presetsJson())
                    }
                }
                post("/api/presets/delete") {
                    withController(call) { c ->
                        val body = JSONObject(call.receiveText())
                        c.deletePreset(body.optString("name"))
                        call.respondJson(c.presetsJson())
                    }
                }

                get("/api/sequences") { withController(call) { c -> call.respondJson(c.sequencesJson()) } }
                post("/api/sequences/load") {
                    withController(call) { c ->
                        val body = JSONObject(call.receiveText())
                        val name = body.optString("name").takeIf { it.isNotEmpty() }
                        c.loadSequence(name)
                        call.respondJson(c.sequencesJson())
                    }
                }
                post("/api/sequences/play") {
                    withController(call) { c ->
                        c.playSequence()
                        call.respondJson(c.statusJson())
                    }
                }
                post("/api/sequences/stop") {
                    withController(call) { c ->
                        c.stopSequence()
                        call.respondJson(c.statusJson())
                    }
                }
                post("/api/sequences/arm") {
                    withController(call) { c ->
                        val body = JSONObject(call.receiveText())
                        c.armSequence(body.optBoolean("armed", false))
                        call.respondJson(c.statusJson())
                    }
                }

                get("/api/clips") { withController(call) { c -> call.respondJson(c.clipsJson()) } }
                get("/api/clips/download") {
                    withController(call) { c ->
                        val name = call.request.queryParameters["name"]
                        val file = name?.let { c.resolveClip(it) }
                        if (file == null || !file.exists()) {
                            call.respond(HttpStatusCode.NotFound)
                        } else {
                            call.response.header(
                                HttpHeaders.ContentDisposition,
                                ContentDisposition.Attachment.withParameter(
                                    ContentDisposition.Parameters.FileName, file.name
                                ).toString()
                            )
                            call.respondFile(file)
                        }
                    }
                }
                get("/api/clips/sidecar") {
                    withController(call) { c ->
                        val name = call.request.queryParameters["name"]
                        val file = name?.let { c.resolveClip(it) }
                        val sidecar = file?.let { java.io.File(it.parentFile, it.nameWithoutExtension + ".json") }
                        if (sidecar == null || !sidecar.exists()) {
                            call.respond(HttpStatusCode.NotFound)
                        } else {
                            call.respondText(sidecar.readText(), ContentType.Application.Json)
                        }
                    }
                }
            }
        }.start(wait = false)
        Log.i(TAG, "Remote server started on port $PORT, pin=${auth.pin}")
        registerNsd()
    }

    fun stop() {
        unregisterNsd()
        engine?.stop(500, 1000)
        engine = null
        controller = null
    }

    /**
     * Advertises this camera as an OpenMotionFX Node under `_openmotionfx._tcp`
     * so a future Conductor can discover it via NSD/mDNS, the same way it would
     * discover any other Node. Best-effort: failure must never break the REST
     * server, which works fine without it.
     */
    private fun registerNsd() {
        runCatching {
            val nsdManager = context.getSystemService(Context.NSD_SERVICE) as? NsdManager
                ?: return
            val sanitizedModel = Build.MODEL.replace(' ', '-')
            val serviceInfo = NsdServiceInfo().apply {
                serviceName = "OpenCamera-$sanitizedModel"
                serviceType = NSD_SERVICE_TYPE
                port = PORT
                setAttribute("role", "camera")
                setAttribute("api", "rest")
                setAttribute("ver", "0")
                setAttribute("app", "opencamera")
            }
            val listener = object : NsdManager.RegistrationListener {
                override fun onServiceRegistered(info: NsdServiceInfo) {
                    Log.i(TAG, "NSD registered: ${info.serviceName}")
                }

                override fun onRegistrationFailed(info: NsdServiceInfo, errorCode: Int) {
                    Log.w(TAG, "NSD registration failed for ${info.serviceName}: code=$errorCode")
                }

                override fun onServiceUnregistered(info: NsdServiceInfo) {
                    Log.i(TAG, "NSD unregistered: ${info.serviceName}")
                }

                override fun onUnregistrationFailed(info: NsdServiceInfo, errorCode: Int) {
                    Log.w(TAG, "NSD unregistration failed for ${info.serviceName}: code=$errorCode")
                }
            }
            nsdRegistrationListener = listener
            nsdManager.registerService(serviceInfo, NsdManager.PROTOCOL_DNS_SD, listener)
        }.onFailure { e ->
            Log.w(TAG, "NSD registration threw, continuing without discovery", e)
        }
    }

    private fun unregisterNsd() {
        runCatching {
            val listener = nsdRegistrationListener ?: return
            val nsdManager = context.getSystemService(Context.NSD_SERVICE) as? NsdManager
                ?: return
            nsdManager.unregisterService(listener)
        }.onFailure { e ->
            Log.w(TAG, "NSD unregistration threw", e)
        }
        nsdRegistrationListener = null
    }

    /** Best-effort site-local IPv4 address for the "connect from your laptop" URL. */
    fun localUrl(): String {
        val addr = runCatching {
            val interfaces = NetworkInterface.getNetworkInterfaces()?.toList() ?: emptyList()
            val candidates = interfaces
                .filter { it.isUp && !it.isLoopback }
                .flatMap { it.inetAddresses.toList() }
                .filterIsInstance<Inet4Address>()
            candidates.firstOrNull { isSiteLocal(it) } ?: candidates.firstOrNull()
        }.getOrNull()
        val host = addr?.hostAddress ?: "<no-wifi>"
        return "http://$host:$PORT"
    }

    private fun isSiteLocal(addr: Inet4Address): Boolean {
        val b = addr.address
        val a0 = b[0].toInt() and 0xFF
        val a1 = b[1].toInt() and 0xFF
        return a0 == 192 && a1 == 168 || a0 == 10 || (a0 == 172 && a1 in 16..31)
    }

    private suspend fun serveIndex(call: ApplicationCall) {
        val bytes = context.assets.open("web/index.html").use { it.readBytes() }
        call.respondBytes(bytes, ContentType.Text.Html)
    }

    private suspend fun serveAsset(call: ApplicationCall, assetPath: String) {
        val bytes = runCatching { context.assets.open(assetPath).use { it.readBytes() } }.getOrNull()
        if (bytes == null) {
            call.respond(HttpStatusCode.NotFound)
        } else {
            call.respondBytes(bytes, ContentType("font", "ttf"))
        }
    }

    private suspend fun handlePair(call: ApplicationCall) {
        val body = runCatching { JSONObject(call.receiveText()) }.getOrNull()
        val candidatePin = body?.optString("pin")
        val token = candidatePin?.let { auth.pair(it) }
        if (token == null) {
            call.respond(HttpStatusCode.Unauthorized)
        } else {
            call.respondJson(JSONObject().put("token", token))
        }
    }

    private fun tokenFrom(call: ApplicationCall): String? {
        val header = call.request.headers[HttpHeaders.Authorization]
        val bearer = header?.removePrefix("Bearer ")?.trim()?.takeIf { it.isNotEmpty() }
        return bearer ?: call.request.queryParameters["t"]
    }

    /** Runs [block] with the live controller if the request carries a valid session token. */
    private suspend inline fun withController(call: ApplicationCall, block: suspend (RemoteController) -> Unit) {
        val token = tokenFrom(call)
        val c = controller
        if (!auth.isValid(token) || c == null) {
            call.respond(HttpStatusCode.Unauthorized)
            return
        }
        block(c)
    }

    private suspend fun ApplicationCall.respondJson(json: JSONObject) {
        this.respondText(json.toString(), ContentType.Application.Json)
    }
}
