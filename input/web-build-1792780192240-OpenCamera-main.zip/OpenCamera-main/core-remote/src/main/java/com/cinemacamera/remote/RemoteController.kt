package com.cinemacamera.remote

import java.io.File
import org.json.JSONObject

/**
 * Seam between the embedded HTTP server ([RemoteServer]) and the app's control
 * surface (implemented by MainViewModel in the :app module). Kept as a plain
 * interface so :core-remote never depends on :app.
 */
interface RemoteController {
    fun statusJson(): JSONObject
    fun settingsJson(): JSONObject
    /** Suspends until the patch has actually been applied, so a following [settingsJson] echo is truthful. */
    suspend fun applySettingsPatch(patch: JSONObject)
    /** Suspends until recording has reached [on] (or a short timeout), so a following [statusJson] echo is truthful. */
    suspend fun setRecording(on: Boolean)
    fun slateJson(): JSONObject
    fun updateSlatePatch(patch: JSONObject)
    fun presetsJson(): JSONObject
    /** Suspends until the preset's settings have been applied. */
    suspend fun applyPreset(name: String)
    fun savePreset(name: String)
    fun deletePreset(name: String)
    fun sequencesJson(): JSONObject
    fun loadSequence(name: String?)
    fun playSequence()
    fun stopSequence()
    fun armSequence(armed: Boolean)
    fun clipsJson(): JSONObject
    fun resolveClip(name: String): File?
}
