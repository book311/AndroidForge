package com.cinemacamera.motion

import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Handler
import android.os.HandlerThread
import com.cinemacamera.domain.MotionCapture
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.withContext
import java.io.BufferedWriter
import java.io.File
import java.io.FileWriter
import java.util.Locale
import javax.inject.Inject
import kotlin.math.abs

/**
 * Captures raw gyroscope + accelerometer samples on a dedicated [HandlerThread]
 * and exports them as a Gyroflow .gcsv file on [stopSession].
 */
class GcsvMotionCapture @Inject constructor(
    @ApplicationContext private val context: Context
) : MotionCapture, SensorEventListener {

    private val sensorManager: SensorManager by lazy {
        context.getSystemService(Context.SENSOR_SERVICE) as SensorManager
    }

    private val _sampleCount = MutableStateFlow(0L)
    override val sampleCount: StateFlow<Long> = _sampleCount

    private var handlerThread: HandlerThread? = null

    private var gyroTs = ArrayList<Long>(INITIAL_CAPACITY)
    private var gyroX = ArrayList<Float>(INITIAL_CAPACITY)
    private var gyroY = ArrayList<Float>(INITIAL_CAPACITY)
    private var gyroZ = ArrayList<Float>(INITIAL_CAPACITY)

    private var accelTs = ArrayList<Long>(INITIAL_CAPACITY)
    private var accelX = ArrayList<Float>(INITIAL_CAPACITY)
    private var accelY = ArrayList<Float>(INITIAL_CAPACITY)
    private var accelZ = ArrayList<Float>(INITIAL_CAPACITY)

    private var totalSamples = 0L

    @Volatile
    private var frameAnchorNs: Long? = null

    @Volatile
    private var sessionActive = false

    private var pendingGcsvFile: File? = null

    @Volatile
    private var timecodeStart: String? = null

    override fun startSession(gcsvFile: File) {
        if (sessionActive) return

        gyroTs = ArrayList(INITIAL_CAPACITY)
        gyroX = ArrayList(INITIAL_CAPACITY)
        gyroY = ArrayList(INITIAL_CAPACITY)
        gyroZ = ArrayList(INITIAL_CAPACITY)
        accelTs = ArrayList(INITIAL_CAPACITY)
        accelX = ArrayList(INITIAL_CAPACITY)
        accelY = ArrayList(INITIAL_CAPACITY)
        accelZ = ArrayList(INITIAL_CAPACITY)
        totalSamples = 0L
        _sampleCount.value = 0L
        frameAnchorNs = null
        pendingGcsvFile = gcsvFile
        timecodeStart = null

        val thread = HandlerThread("GcsvMotionCapture").apply { start() }
        handlerThread = thread
        val handler = Handler(thread.looper)

        val gyro = sensorManager.getDefaultSensor(Sensor.TYPE_GYROSCOPE)
        val accel = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
        gyro?.let { sensorManager.registerListener(this, it, SensorManager.SENSOR_DELAY_FASTEST, handler) }
        accel?.let { sensorManager.registerListener(this, it, SensorManager.SENSOR_DELAY_FASTEST, handler) }

        sessionActive = true
    }

    override fun setFrameAnchor(frameTimestampNs: Long) {
        frameAnchorNs = frameTimestampNs
    }

    override fun setTimecodeStart(timecode: String?) {
        timecodeStart = timecode
    }

    override fun onSensorChanged(event: SensorEvent) {
        when (event.sensor.type) {
            Sensor.TYPE_GYROSCOPE -> {
                gyroTs.add(event.timestamp)
                gyroX.add(event.values[0])
                gyroY.add(event.values[1])
                gyroZ.add(event.values[2])
            }

            Sensor.TYPE_ACCELEROMETER -> {
                accelTs.add(event.timestamp)
                accelX.add(event.values[0])
                accelY.add(event.values[1])
                accelZ.add(event.values[2])
            }

            else -> return
        }
        totalSamples++
        if (totalSamples % 100 == 0L) {
            _sampleCount.value = totalSamples
        }
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {
        // no-op
    }

    override suspend fun stopSession(): Long {
        if (!sessionActive) return 0

        sensorManager.unregisterListener(this)
        val thread = handlerThread
        handlerThread = null
        thread?.quitSafely()
        thread?.join()

        sessionActive = false
        _sampleCount.value = totalSamples

        val gcsvFile = pendingGcsvFile ?: return 0
        pendingGcsvFile = null

        val localGyroTs = gyroTs
        val localGyroX = gyroX
        val localGyroY = gyroY
        val localGyroZ = gyroZ
        val localAccelTs = accelTs
        val localAccelX = accelX
        val localAccelY = accelY
        val localAccelZ = accelZ
        val anchor = frameAnchorNs ?: (localGyroTs.firstOrNull() ?: 0L)
        val tcStart = timecodeStart

        return withContext(Dispatchers.IO) {
            var rowCount = 0L
            gcsvFile.parentFile?.mkdirs()
            BufferedWriter(FileWriter(gcsvFile)).use { writer ->
                writer.write("GYROFLOW IMU LOG\n")
                writer.write("version,1.3\n")
                writer.write("id,cinemacamera\n")
                writer.write("orientation,xyz\n")
                writer.write("tscale,0.000001\n")
                writer.write("gscale,1.0\n")
                writer.write("ascale,1.0\n")
                if (tcStart != null) writer.write("tc_start,$tcStart\n")
                writer.write("t,gx,gy,gz,ax,ay,az\n")

                var aIdx = 0
                for (i in localGyroTs.indices) {
                    val gTs = localGyroTs[i]
                    if (localAccelTs.isNotEmpty()) {
                        while (aIdx + 1 < localAccelTs.size &&
                            abs(localAccelTs[aIdx + 1] - gTs) <= abs(localAccelTs[aIdx] - gTs)
                        ) {
                            aIdx++
                        }
                    }
                    val tUs = (gTs - anchor) / 1000L
                    val gx = localGyroX[i]
                    val gy = localGyroY[i]
                    val gz = localGyroZ[i]
                    val ax: Float
                    val ay: Float
                    val az: Float
                    if (localAccelTs.isNotEmpty()) {
                        ax = localAccelX[aIdx] / GRAVITY_MPS2
                        ay = localAccelY[aIdx] / GRAVITY_MPS2
                        az = localAccelZ[aIdx] / GRAVITY_MPS2
                    } else {
                        ax = 0f
                        ay = 0f
                        az = 0f
                    }
                    writer.write(
                        String.format(
                            Locale.US,
                            "%d,%.6f,%.6f,%.6f,%.6f,%.6f,%.6f\n",
                            tUs, gx, gy, gz, ax, ay, az
                        )
                    )
                    rowCount++
                }
            }
            rowCount
        }
    }

    companion object {
        private const val INITIAL_CAPACITY = 200_000
        private const val GRAVITY_MPS2 = 9.80665f
    }
}
