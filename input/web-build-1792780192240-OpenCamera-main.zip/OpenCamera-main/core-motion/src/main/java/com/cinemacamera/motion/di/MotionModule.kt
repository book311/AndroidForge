package com.cinemacamera.motion.di

import com.cinemacamera.domain.MotionCapture
import com.cinemacamera.motion.GcsvMotionCapture
import dagger.Binds
import dagger.Module
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
abstract class MotionModule {

    @Binds
    @Singleton
    abstract fun bindMotionCapture(impl: GcsvMotionCapture): MotionCapture
}
