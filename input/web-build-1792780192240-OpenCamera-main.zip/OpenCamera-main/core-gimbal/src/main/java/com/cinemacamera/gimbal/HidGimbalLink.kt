package com.cinemacamera.gimbal

import android.Manifest
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.os.SystemClock
import android.view.KeyEvent
import androidx.core.content.ContextCompat
import com.cinemacamera.domain.GimbalLink
import com.cinemacamera.domain.GimbalState
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import javax.inject.Inject

/**
 * DJI MSDK v5 has no Osmo Mobile support, so the OM6 is driven purely as a
 * Bluetooth-remote (HID) accessory: the physical record button arrives as a
 * hardware key event routed in from the Activity, and connection state is
 * inferred from ACL broadcasts for the bonded device.
 */
class HidGimbalLink @Inject constructor(
    @ApplicationContext private val context: Context
) : GimbalLink {

    private val _state = MutableStateFlow(GimbalState())
    override val state: StateFlow<GimbalState> = _state

    private val _recordTrigger = MutableSharedFlow<Unit>(extraBufferCapacity = 1)
    override val recordTrigger: SharedFlow<Unit> = _recordTrigger

    private var trackedDevice: BluetoothDevice? = null
    private var receiver: BroadcastReceiver? = null
    private var lastTriggerElapsedMs = 0L

    private fun hasBluetoothConnectPermission(): Boolean =
        ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.BLUETOOTH_CONNECT
        ) == PackageManager.PERMISSION_GRANTED

    override fun start() {
        if (!hasBluetoothConnectPermission()) return

        try {
            val bluetoothManager =
                context.getSystemService(Context.BLUETOOTH_SERVICE) as? BluetoothManager
            val adapter: BluetoothAdapter? = bluetoothManager?.adapter
            val bonded = adapter?.bondedDevices ?: emptySet()
            val match = bonded.firstOrNull { device ->
                val name = device.name ?: return@firstOrNull false
                NAME_HINTS.any { hint -> name.contains(hint, ignoreCase = true) }
            }
            if (match != null) {
                trackedDevice = match
                _state.value = GimbalState(
                    connected = false,
                    deviceName = match.name,
                    transport = TRANSPORT
                )
            }
        } catch (e: SecurityException) {
            // Permission revoked between the check and use; leave state as-is.
        }

        val filter = IntentFilter().apply {
            addAction(BluetoothDevice.ACTION_ACL_CONNECTED)
            addAction(BluetoothDevice.ACTION_ACL_DISCONNECTED)
        }
        val newReceiver = object : BroadcastReceiver() {
            override fun onReceive(ctx: Context, intent: Intent) {
                val tracked = trackedDevice ?: return
                val device: BluetoothDevice? =
                    intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE, BluetoothDevice::class.java)
                if (device == null || device.address != tracked.address) return

                val connected = intent.action == BluetoothDevice.ACTION_ACL_CONNECTED
                val currentName = try {
                    tracked.name ?: _state.value.deviceName
                } catch (e: SecurityException) {
                    _state.value.deviceName
                }
                _state.value = _state.value.copy(
                    connected = connected,
                    deviceName = currentName,
                    transport = TRANSPORT
                )
            }
        }
        try {
            ContextCompat.registerReceiver(
                context,
                newReceiver,
                filter,
                ContextCompat.RECEIVER_NOT_EXPORTED
            )
            receiver = newReceiver
        } catch (e: SecurityException) {
            // Registration denied; gimbal state updates will simply not arrive.
        }
    }

    override fun stop() {
        val r = receiver
        receiver = null
        if (r != null) {
            try {
                context.unregisterReceiver(r)
            } catch (e: IllegalArgumentException) {
                // Not registered; nothing to do.
            } catch (e: SecurityException) {
                // Ignore.
            }
        }
    }

    override fun onKeyEvent(keyCode: Int, isDown: Boolean): Boolean {
        if (!isDown) return false
        val matches = keyCode == KeyEvent.KEYCODE_VOLUME_UP ||
            keyCode == KeyEvent.KEYCODE_VOLUME_DOWN ||
            keyCode == KeyEvent.KEYCODE_CAMERA ||
            keyCode == KeyEvent.KEYCODE_MEDIA_RECORD
        if (!matches) return false

        val now = SystemClock.elapsedRealtime()
        if (now - lastTriggerElapsedMs >= DEBOUNCE_MS) {
            lastTriggerElapsedMs = now
            _recordTrigger.tryEmit(Unit)
        }
        return true
    }

    companion object {
        private const val TRANSPORT = "BT-HID"
        private const val DEBOUNCE_MS = 400L
        private val NAME_HINTS = listOf("OM", "Osmo", "DJI")
    }
}
