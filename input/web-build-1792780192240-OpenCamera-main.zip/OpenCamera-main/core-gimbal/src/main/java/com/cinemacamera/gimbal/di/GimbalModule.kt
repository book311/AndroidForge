package com.cinemacamera.gimbal.di

import com.cinemacamera.domain.GimbalLink
import com.cinemacamera.gimbal.HidGimbalLink
import dagger.Binds
import dagger.Module
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
abstract class GimbalModule {

    @Binds
    @Singleton
    abstract fun bindGimbalLink(impl: HidGimbalLink): GimbalLink
}
