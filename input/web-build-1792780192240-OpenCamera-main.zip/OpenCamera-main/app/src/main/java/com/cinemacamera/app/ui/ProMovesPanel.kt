package com.cinemacamera.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.cinemacamera.app.MainViewModel
import com.cinemacamera.domain.AutoTrack
import com.cinemacamera.domain.AutoTrackKind
import com.cinemacamera.domain.Keyframe
import com.cinemacamera.domain.Sequence
import com.cinemacamera.domain.SequenceTransport

/** MOVE deck tab — focus pulls, ramps, and the sequence builder. */
@Composable
fun MovesDeck(viewModel: MainViewModel) {
    val sensors by viewModel.engine.sensors.collectAsState()
    val settings by viewModel.engine.settings.collectAsState()
    val focusA by viewModel.focusA.collectAsState()
    val focusB by viewModel.focusB.collectAsState()
    val selectedSensor = sensors.find { it.id == settings.sensorId } ?: sensors.firstOrNull()
    val moves = viewModel.proMoves

    // --- FOCUS PULL --------------------------------------------------------
    SectionLabel("Focus pull")
    Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        ActionButton(text = "SET A", onClick = { viewModel.markFocusA() })
        MonoText(focusA?.let { "%.2f".format(it) } ?: "—", modifier = Modifier.padding(start = 8.dp), color = TextDim)
        ActionButton(text = "SET B", onClick = { viewModel.markFocusB() }, modifier = Modifier.padding(start = 16.dp))
        MonoText(focusB?.let { "%.2f".format(it) } ?: "—", modifier = Modifier.padding(start = 8.dp), color = TextDim)
    }
    LabeledSlider(
        label = "DURATION ${"%.1f".format(moves.pullDurationS)}s",
        value = moves.pullDurationS, valueRange = 0.5f..10.0f,
        onValueChange = { moves.pullDurationS = it }
    )
    ActionButton(
        text = "RUN PULL", enabled = focusA != null && focusB != null,
        onClick = { viewModel.runFocusPull((moves.pullDurationS * 1000).toLong()) },
        modifier = Modifier.fillMaxWidth()
    )

    // --- DOLLY ZOOM --------------------------------------------------------
    SectionLabel("Dolly zoom")
    LabeledSlider(
        label = "FROM ${"%.2f".format(moves.zoomFrom)}x", value = moves.zoomFrom,
        valueRange = 1.0f..4.0f, onValueChange = { moves.zoomFrom = it }
    )
    LabeledSlider(
        label = "TO ${"%.2f".format(moves.zoomTo)}x", value = moves.zoomTo,
        valueRange = 1.0f..4.0f, onValueChange = { moves.zoomTo = it }
    )
    LabeledSlider(
        label = "DURATION ${"%.1f".format(moves.zoomDurationS)}s", value = moves.zoomDurationS,
        valueRange = 0.5f..10.0f, onValueChange = { moves.zoomDurationS = it }
    )
    ActionButton(
        text = "RUN",
        onClick = { viewModel.runZoomRamp(moves.zoomFrom, moves.zoomTo, (moves.zoomDurationS * 1000).toLong()) },
        modifier = Modifier.fillMaxWidth()
    )

    // --- EXPOSURE RAMP -----------------------------------------------------
    SectionLabel("Exposure ramp")
    val isoRange = (selectedSensor?.isoMin?.toFloat() ?: 100f)..(selectedSensor?.isoMax?.toFloat() ?: 3200f)
    val clampedIso = moves.targetIso.coerceIn(isoRange)
    LabeledSlider(
        label = "ISO ${clampedIso.toInt()}", value = clampedIso,
        valueRange = isoRange, onValueChange = { moves.targetIso = it }
    )
    SectionLabel("Shutter angle")
    val angles = listOf(90f, 144f, 172.8f, 180f, 270f, 360f)
    ChipRow(
        items = angles.map { "${if (it == it.toInt().toFloat()) it.toInt().toString() else it}°" },
        selectedIndex = angles.indexOfFirst { it == moves.targetAngle },
        onSelect = { i -> moves.targetAngle = angles[i] }
    )
    LabeledSlider(
        label = "DURATION ${"%.1f".format(moves.rampDurationS)}s", value = moves.rampDurationS,
        valueRange = 0.5f..10.0f, onValueChange = { moves.rampDurationS = it }
    )
    ActionButton(
        text = "RUN",
        onClick = {
            val angleToNs = (1_000_000_000.0 * moves.targetAngle / 360.0 / settings.fps).toLong()
            viewModel.runExposureRamp(clampedIso.toInt(), angleToNs, (moves.rampDurationS * 1000).toLong())
        },
        modifier = Modifier.fillMaxWidth()
    )

    Spacer(modifier = Modifier.height(12.dp))
    ActionButton(
        text = "CANCEL MOVES", onClick = { viewModel.cancelRamps() },
        modifier = Modifier.fillMaxWidth(), accent = CriticalRed
    )

    // --- SEQUENCE ----------------------------------------------------------
    SectionLabel("Sequence")
    val sequences by viewModel.sequences.collectAsState()
    val activeSequence by viewModel.activeSequence.collectAsState()
    val transport by viewModel.sequenceTransport.collectAsState()
    val positionMs by viewModel.sequencePositionMs.collectAsState()
    val armed by viewModel.sequenceArmed.collectAsState()

    ChipRow(
        items = sequences.map { it.name },
        selectedIndex = sequences.indexOfFirst { it.name == activeSequence?.name },
        onSelect = { i -> viewModel.loadSequence(sequences[i]) },
    )
    val running = transport == SequenceTransport.RUNNING
    Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        ActionButton(
            text = if (running) "STOP" else "PLAY",
            enabled = activeSequence != null,
            // A running sequence is genuinely live → green.
            accent = if (running) LiveGreen else TextPrimary,
            onClick = { if (running) viewModel.stopSequence() else viewModel.playSequence() },
        )
        MonoText(
            text = "%.1fs / %.1fs".format(positionMs / 1000f, (activeSequence?.durationMs ?: 0L) / 1000f),
            modifier = Modifier.padding(start = 12.dp), color = TextDim,
        )
    }
    SwitchRow(label = "Arm on rec", checked = armed, onCheckedChange = { viewModel.armSequence(it) })

    // --- BUILD SEQUENCE ----------------------------------------------------
    SectionLabel("Build sequence")
    val trackNames = listOf("FOCUS", "EXPOSURE", "ZOOM")
    ChipRow(
        items = trackNames, selectedIndex = moves.selectedBuildTrack,
        onSelect = { moves.selectedBuildTrack = it },
    )
    LabeledSlider(
        label = "DURATION ${"%.1f".format(moves.seqDurationS)}s", value = moves.seqDurationS,
        valueRange = 0.5f..30.0f, onValueChange = { moves.seqDurationS = it },
    )
    Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        ActionButton(text = "SET A @0s", onClick = {
            val snap = viewModel.captureKeyframeSnapshot()
            when (moves.selectedBuildTrack) {
                0 -> moves.seqFocusA = snap.focusDiopters
                1 -> { moves.isoA = snap.iso; moves.shutterA = snap.shutterNs }
                2 -> moves.zoomA = snap.zoomRatio
            }
        })
        ActionButton(
            text = "SET B @END", modifier = Modifier.padding(start = 12.dp),
            onClick = {
                val snap = viewModel.captureKeyframeSnapshot()
                when (moves.selectedBuildTrack) {
                    0 -> moves.seqFocusB = snap.focusDiopters
                    1 -> { moves.isoB = snap.iso; moves.shutterB = snap.shutterNs }
                    2 -> moves.zoomB = snap.zoomRatio
                }
            },
        )
    }
    MonoText(
        text = when (moves.selectedBuildTrack) {
            0 -> "A=${moves.seqFocusA?.let { "%.2f".format(it) } ?: "—"}  B=${moves.seqFocusB?.let { "%.2f".format(it) } ?: "—"}"
            1 -> "A=${moves.isoA ?: "—"}/${moves.shutterA ?: "—"}ns  B=${moves.isoB ?: "—"}/${moves.shutterB ?: "—"}ns"
            else -> "A=${moves.zoomA?.let { "%.2f".format(it) } ?: "—"}x  B=${moves.zoomB?.let { "%.2f".format(it) } ?: "—"}x"
        },
        modifier = Modifier.padding(top = 4.dp), color = TextDim, size = 11,
    )
    Spacer(modifier = Modifier.height(6.dp))
    GlassField(value = moves.seqName, onValueChange = { moves.seqName = it })
    Spacer(modifier = Modifier.height(6.dp))
    ActionButton(
        text = "SAVE", enabled = moves.seqName.isNotBlank(),
        onClick = {
            val durationMs = (moves.seqDurationS * 1000).toLong()
            val tracks = buildList {
                if (moves.seqFocusA != null && moves.seqFocusB != null) add(
                    AutoTrack(AutoTrackKind.FOCUS, listOf(
                        Keyframe(0L, moves.seqFocusA!!.toDouble()), Keyframe(durationMs, moves.seqFocusB!!.toDouble()),
                    )))
                if (moves.isoA != null && moves.isoB != null) add(
                    AutoTrack(AutoTrackKind.ISO, listOf(
                        Keyframe(0L, moves.isoA!!.toDouble()), Keyframe(durationMs, moves.isoB!!.toDouble()),
                    )))
                if (moves.shutterA != null && moves.shutterB != null) add(
                    AutoTrack(AutoTrackKind.SHUTTER_NS, listOf(
                        Keyframe(0L, moves.shutterA!!.toDouble()), Keyframe(durationMs, moves.shutterB!!.toDouble()),
                    )))
                if (moves.zoomA != null && moves.zoomB != null) add(
                    AutoTrack(AutoTrackKind.ZOOM, listOf(
                        Keyframe(0L, moves.zoomA!!.toDouble()), Keyframe(durationMs, moves.zoomB!!.toDouble()),
                    )))
            }
            if (tracks.isNotEmpty()) viewModel.saveSequence(Sequence(moves.seqName.trim(), durationMs, tracks))
        },
        modifier = Modifier.fillMaxWidth(),
    )
    Spacer(modifier = Modifier.height(12.dp))
}

@Composable
private fun ActionButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    accent: Color = TextPrimary,
) {
    val shape = RoundedCornerShape(999.dp)
    val color = if (enabled) accent else TextFaint
    val fill = if (enabled && accent == LiveGreen) LiveGreen.copy(alpha = 0.16f) else GlassFill
    Box(
        modifier = modifier
            .padding(vertical = 4.dp)
            .height(38.dp)
            .clip(shape)
            .background(fill)
            .border(width = 1.dp, color = color.copy(alpha = 0.7f), shape = shape)
            .then(if (enabled) Modifier.clickable(onClick = onClick) else Modifier)
            .padding(horizontal = 16.dp),
        contentAlignment = Alignment.Center
    ) {
        LabelText(text, color = color, size = 12, weight = androidx.compose.ui.text.font.FontWeight.Medium)
    }
}
