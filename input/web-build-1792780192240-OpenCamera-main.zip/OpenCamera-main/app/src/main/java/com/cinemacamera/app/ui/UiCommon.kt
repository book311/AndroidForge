package com.cinemacamera.app.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay

// Shared control primitives, all speaking the Theme.kt design language.
// Persistent selections use white emphasis; green is reserved for live
// state and lives on the HUD (scope rail / record), not in these controls.

enum class ActivePanel { NONE, LENS, MOVE, CLIPS }

/** Manrope chrome label. Kept as the historical name used across panels. */
@Composable
fun OverlayText(text: String, modifier: Modifier = Modifier, color: Color = TextPrimary) {
    LabelText(text = text, modifier = modifier, color = color, size = 12)
}

@Composable
fun SectionLabel(text: String, modifier: Modifier = Modifier) {
    LabelText(
        text = text.uppercase(),
        color = TextDim,
        size = 11,
        weight = androidx.compose.ui.text.font.FontWeight.SemiBold,
        modifier = modifier.padding(top = 14.dp, bottom = 6.dp),
    )
}

/**
 * A glass pill chip. A persistent [selected] choice is shown with white
 * emphasis (fill + border + bright text); unselected chips are quiet glass.
 * For LIVE toggles (scopes, record) use the HUD's own green chip instead.
 */
@Composable
fun Chip(
    text: String,
    selected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val shape = RoundedCornerShape(999.dp)
    val fill = if (selected) SelectedFill else GlassFill
    val borderColor = if (selected) SelectedBorder else GlassBorder
    val textColor = if (selected) TextPrimary else TextDim
    Box(
        modifier = modifier
            .height(30.dp)
            .clip(shape)
            .background(fill)
            .border(width = 1.dp, color = borderColor, shape = shape)
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp),
        contentAlignment = Alignment.Center
    ) {
        LabelText(text = text, color = textColor, size = 11, weight = androidx.compose.ui.text.font.FontWeight.Medium)
    }
}

@Composable
fun ChipRow(
    items: List<String>,
    selectedIndex: Int,
    onSelect: (Int) -> Unit,
    modifier: Modifier = Modifier,
) {
    Row(modifier = modifier, verticalAlignment = Alignment.CenterVertically) {
        items.forEachIndexed { i, label ->
            if (i > 0) Spacer(modifier = Modifier.width(6.dp))
            Chip(text = label, selected = i == selectedIndex, onClick = { onSelect(i) })
        }
    }
}

@Composable
fun SwitchRow(
    label: String,
    checked: Boolean,
    modifier: Modifier = Modifier,
    onCheckedChange: (Boolean) -> Unit,
) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .height(40.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        OverlayText(label, color = if (checked) TextPrimary else TextDim)
        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange,
            colors = SwitchDefaults.colors(
                checkedThumbColor = Viewfinder,
                checkedTrackColor = TextPrimary,
                checkedBorderColor = TextPrimary,
                uncheckedThumbColor = TextDim,
                uncheckedTrackColor = Color.Transparent,
                uncheckedBorderColor = GlassBorder,
            )
        )
    }
}

@Composable
fun LabeledSlider(
    label: String,
    value: Float,
    onValueChange: (Float) -> Unit,
    valueRange: ClosedFloatingPointRange<Float>,
    modifier: Modifier = Modifier,
    steps: Int = 0,
    onValueChangeFinished: (() -> Unit)? = null,
) {
    Column(modifier = modifier.fillMaxWidth()) {
        OverlayText(label)
        Slider(
            value = value,
            onValueChange = onValueChange,
            valueRange = valueRange,
            steps = steps,
            onValueChangeFinished = onValueChangeFinished,
            colors = SliderDefaults.colors(
                thumbColor = TextPrimary,
                activeTrackColor = TextPrimary,
                inactiveTrackColor = Color.White.copy(alpha = 0.14f),
                activeTickColor = Viewfinder,
                inactiveTickColor = TextFaint,
            )
        )
    }
}

/** Labeled single-line text input in a glass box (slate fields, names). */
@Composable
fun LabeledTextField(
    label: String,
    value: String,
    onValueChange: (String) -> Unit,
    modifier: Modifier = Modifier,
    numeric: Boolean = false,
) {
    Column(modifier = modifier.fillMaxWidth()) {
        OverlayText(label, color = TextDim)
        Spacer(modifier = Modifier.height(4.dp))
        GlassField(value = value, onValueChange = onValueChange, numeric = numeric)
    }
}

/** The bare glass-bordered text box, reused by LabeledTextField and panels. */
@Composable
fun GlassField(
    value: String,
    onValueChange: (String) -> Unit,
    modifier: Modifier = Modifier,
    numeric: Boolean = false,
) {
    val shape = RoundedCornerShape(8.dp)
    Box(
        modifier = modifier
            .fillMaxWidth()
            .height(38.dp)
            .clip(shape)
            .background(GlassFill)
            .border(width = 1.dp, color = GlassBorder, shape = shape)
            .padding(horizontal = 10.dp),
        contentAlignment = Alignment.CenterStart
    ) {
        BasicTextField(
            value = value,
            onValueChange = onValueChange,
            singleLine = true,
            textStyle = TextStyle(
                color = TextPrimary,
                fontSize = 13.sp,
                fontFamily = JetBrainsMono,
            ),
            keyboardOptions = if (numeric) {
                KeyboardOptions(keyboardType = KeyboardType.Number)
            } else {
                KeyboardOptions.Default
            },
            cursorBrush = SolidColor(TextPrimary),
            modifier = Modifier.fillMaxWidth()
        )
    }
}

/**
 * Two thin audio bars for [levels] = [left, right] peak, each in [0, 1].
 * The fill is the live green→amber→red gradient scaled to the level.
 */
@Composable
fun VuMeter(levels: FloatArray, modifier: Modifier = Modifier) {
    Column(modifier = modifier) {
        VuBar(peakSample = levels.getOrElse(0) { 0f }, modifier = Modifier.fillMaxWidth())
        Spacer(modifier = Modifier.height(3.dp))
        VuBar(peakSample = levels.getOrElse(1) { 0f }, modifier = Modifier.fillMaxWidth())
    }
}

/** One VU bar: an instant level fill plus a peak-hold marker that decays. */
@Composable
private fun VuBar(peakSample: Float, modifier: Modifier = Modifier) {
    var barLevel by remember { mutableFloatStateOf(0f) }
    var peakHold by remember { mutableFloatStateOf(0f) }

    LaunchedEffect(peakSample) {
        if (peakSample > barLevel) barLevel = peakSample.coerceIn(0f, 1f)
        if (peakSample > peakHold) peakHold = peakSample.coerceIn(0f, 1f)
    }
    LaunchedEffect(Unit) {
        while (true) {
            delay(16)
            barLevel = (barLevel - 0.05f).coerceAtLeast(0f)
            peakHold = (peakHold - 0.016f).coerceAtLeast(0f)
        }
    }

    Canvas(modifier = modifier.height(4.dp)) {
        // track
        drawRoundRect(
            color = Color.White.copy(alpha = 0.08f),
            size = size,
            cornerRadius = androidx.compose.ui.geometry.CornerRadius(size.height / 2f),
        )
        val levelWidth = size.width * barLevel
        if (levelWidth > 0f) {
            drawRoundRect(
                brush = AudioLevelBrush,
                size = Size(levelWidth, size.height),
                cornerRadius = androidx.compose.ui.geometry.CornerRadius(size.height / 2f),
            )
        }
        val peakX = (size.width * peakHold).coerceIn(0f, size.width)
        drawLine(
            color = TextPrimary,
            start = Offset(peakX, 0f),
            end = Offset(peakX, size.height),
            strokeWidth = 2f,
        )
    }
}
