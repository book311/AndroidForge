package com.cinemacamera.app.ui

import android.content.Context
import android.database.Cursor
import android.provider.OpenableColumns
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.cinemacamera.app.MainViewModel
import com.cinemacamera.domain.LogProfile
import com.cinemacamera.domain.OutputMode
import com.cinemacamera.domain.SensorInfo
import com.cinemacamera.domain.VideoCodec
import kotlin.math.max
import kotlin.math.roundToInt

/**
 * LENS deck tab — the single "camera home". Shooting controls first, then
 * metadata (SLATE), looks (PRESETS) and the remote pairing (DIRECTOR).
 * Emits content directly into the deck's scrolling column.
 */
@Composable
fun LensDeck(viewModel: MainViewModel) {
    val sensors by viewModel.engine.sensors.collectAsState()
    val settings by viewModel.engine.settings.collectAsState()
    val scopes by viewModel.scopeConfig.collectAsState()
    val selectedSensor: SensorInfo? = sensors.find { it.id == settings.sensorId } ?: sensors.firstOrNull()

    // --- SENSOR ------------------------------------------------------------
    SectionLabel("Sensor")
    sensors.forEach { s ->
        val isSelected = s.id == settings.sensorId
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .height(36.dp)
                .clip(RoundedCornerShape(8.dp))
                .background(if (isSelected) SelectedFill else androidx.compose.ui.graphics.Color.Transparent)
                .clickable { viewModel.updateSettings { it.copy(sensorId = s.id, rawWidth = 0, rawHeight = 0) } }
                .padding(horizontal = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            OverlayText(
                text = s.label,
                color = if (isSelected) TextPrimary else TextDim,
                modifier = Modifier.padding(end = 6.dp)
            )
            if (s.hidden) LabelText("hidden", color = WarnAmber, size = 10)
        }
    }

    // --- RESOLUTION --------------------------------------------------------
    SectionLabel("Resolution — open gate")
    LabelText("full sensor is always recorded", color = TextFaint, size = 11)
    Spacer(modifier = Modifier.height(6.dp))
    if (selectedSensor != null) {
        FlowChips(
            labels = selectedSensor.rawSizes.map { it.toString() },
            isSelected = { i ->
                val r = selectedSensor.rawSizes[i]
                r.width == settings.rawWidth && r.height == settings.rawHeight
            },
            onSelect = { i ->
                val r = selectedSensor.rawSizes[i]
                viewModel.updateSettings { it.copy(rawWidth = r.width, rawHeight = r.height) }
            }
        )

        SectionLabel("FPS")
        FlowChips(
            labels = selectedSensor.fpsOptions.map { "$it" },
            isSelected = { i -> selectedSensor.fpsOptions[i] == settings.fps },
            onSelect = { i -> viewModel.updateSettings { it.copy(fps = selectedSensor.fpsOptions[i]) } }
        )
    }

    // --- LOG ---------------------------------------------------------------
    SectionLabel("Log")
    val logLabels = listOf("CINE FLAT", "CINE STD", "REC709", "ACEScct")
    val logValues = listOf(LogProfile.CINE_FLAT, LogProfile.CINE_STD, LogProfile.REC709, LogProfile.ACES_CCT)
    ChipRow(
        items = logLabels,
        selectedIndex = logValues.indexOf(settings.logProfile),
        onSelect = { i -> viewModel.updateSettings { it.copy(logProfile = logValues[i]) } }
    )

    // --- COLOR -------------------------------------------------------------
    SectionLabel("Color")
    SwitchRow(
        label = "ACES IDT",
        checked = settings.acesIdt,
        onCheckedChange = { v -> viewModel.updateSettings { it.copy(acesIdt = v) } }
    )
    val lutNames by viewModel.lutNames.collectAsState()
    val lutLabels = listOf("OFF") + lutNames
    FlowChips(
        labels = lutLabels,
        isSelected = { i ->
            if (i == 0) settings.previewLutName == null else lutNames[i - 1] == settings.previewLutName
        },
        onSelect = { i -> viewModel.selectLut(if (i == 0) null else lutNames[i - 1]) }
    )
    val context = LocalContext.current
    val importLutLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        uri?.let { viewModel.importLut(it, queryDisplayName(context, it) ?: "LUT") }
    }
    Spacer(modifier = Modifier.height(6.dp))
    Chip(text = "IMPORT LUT", selected = false, onClick = { importLutLauncher.launch(arrayOf("*/*")) })

    // --- GUIDES ------------------------------------------------------------
    SectionLabel("Guides")
    val guideLabels = listOf("OFF", "16:9", "2.39:1", "1:1", "9:16")
    val guideValues = listOf(0f, 1.7778f, 2.39f, 1f, 0.5625f)
    FlowChips(
        labels = guideLabels,
        isSelected = { i -> guideValues[i] == settings.guideAspect },
        onSelect = { i -> viewModel.updateSettings { it.copy(guideAspect = guideValues[i]) } }
    )

    // --- EXPOSURE ----------------------------------------------------------
    SectionLabel("Exposure")
    SwitchRow(
        label = "Auto",
        checked = settings.exposure.auto,
        onCheckedChange = { auto -> viewModel.updateSettings { it.copy(exposure = it.exposure.copy(auto = auto)) } }
    )
    if (!settings.exposure.auto && selectedSensor != null) {
        LabeledSlider(
            label = "ISO ${settings.exposure.iso}",
            value = settings.exposure.iso.toFloat(),
            valueRange = selectedSensor.isoMin.toFloat()..selectedSensor.isoMax.toFloat(),
            onValueChange = { v ->
                val snapped = (v / 50f).roundToInt() * 50
                viewModel.updateSettings { it.copy(exposure = it.exposure.copy(auto = false, iso = snapped)) }
            }
        )
        SectionLabel("Shutter")
        val angles = listOf(90f, 144f, 172.8f, 180f, 270f, 360f)
        ChipRow(
            items = angles.map { "${if (it == it.toInt().toFloat()) it.toInt().toString() else it}°" },
            selectedIndex = angles.indexOfFirst { it == settings.exposure.shutterAngle },
            onSelect = { i ->
                viewModel.updateSettings {
                    it.copy(exposure = it.exposure.copy(auto = false, shutterAngle = angles[i], shutterNs = 0L))
                }
            }
        )
        val effNs = settings.exposure.effectiveShutterNs(settings.fps)
        if (effNs > 0) {
            val denom = 1_000_000_000.0 / effNs
            val ms = effNs / 1_000_000.0
            Spacer(modifier = Modifier.height(4.dp))
            MonoText("1/${"%.0f".format(denom)} · ${"%.1f".format(ms)}ms", color = TextDim, size = 11)
        }
    }

    // --- FOCUS -------------------------------------------------------------
    SectionLabel("Focus")
    SwitchRow(
        label = "AF",
        checked = settings.focusDiopters < 0f,
        onCheckedChange = { af -> viewModel.updateSettings { it.copy(focusDiopters = if (af) -1f else 0f) } }
    )
    if (settings.focusDiopters >= 0f && selectedSensor != null) {
        val maxD = max(selectedSensor.minFocusDiopters, 10f)
        val distText = if (settings.focusDiopters <= 0.001f) "∞" else "${"%.2f".format(1f / settings.focusDiopters)}m"
        LabeledSlider(
            label = "${"%.2f".format(settings.focusDiopters)} diopters · $distText",
            value = settings.focusDiopters,
            valueRange = 0f..maxD,
            onValueChange = { v -> viewModel.updateSettings { it.copy(focusDiopters = v) } }
        )
    }

    // --- PROCESSING --------------------------------------------------------
    SectionLabel("Processing — Process Zero default")
    val p = settings.processing
    SwitchRow("Denoise", p.noiseReduction) { v -> viewModel.updateSettings { it.copy(processing = it.processing.copy(noiseReduction = v)) } }
    SwitchRow("Sharpen", p.edgeEnhancement) { v -> viewModel.updateSettings { it.copy(processing = it.processing.copy(edgeEnhancement = v)) } }
    SwitchRow("Lens shading", p.lensShading) { v -> viewModel.updateSettings { it.copy(processing = it.processing.copy(lensShading = v)) } }
    SwitchRow("Hot pixel", p.hotPixel) { v -> viewModel.updateSettings { it.copy(processing = it.processing.copy(hotPixel = v)) } }
    SwitchRow("Identity tonemap", p.forceIdentityTonemap) { v -> viewModel.updateSettings { it.copy(processing = it.processing.copy(forceIdentityTonemap = v)) } }
    SwitchRow("Stabilization", p.videoStabilization) { v -> viewModel.updateSettings { it.copy(processing = it.processing.copy(videoStabilization = v)) } }

    // --- AUDIO -------------------------------------------------------------
    SectionLabel("Audio")
    SwitchRow(
        label = "Record audio",
        checked = settings.audioEnabled,
        onCheckedChange = { v -> viewModel.updateSettings { it.copy(audioEnabled = v) } }
    )

    // --- RECORDING ---------------------------------------------------------
    SectionLabel("Recording")
    SectionLabel("Output")
    val outputModes = listOf(OutputMode.VIDEO, OutputMode.CINEMA_DNG)
    ChipRow(
        items = listOf("Video", "CinemaDNG"),
        selectedIndex = outputModes.indexOf(settings.outputMode),
        onSelect = { i -> viewModel.updateSettings { it.copy(outputMode = outputModes[i]) } }
    )
    SwitchRow("Full-res encode", settings.encodeFullRes) { v -> viewModel.updateSettings { it.copy(encodeFullRes = v) } }
    SectionLabel("Codec")
    val codecs = VideoCodec.values()
    ChipRow(
        items = codecs.map { it.label },
        selectedIndex = codecs.indexOf(settings.codec),
        onSelect = { i -> viewModel.updateSettings { it.copy(codec = codecs[i]) } }
    )
    SectionLabel("Bitrate")
    val bitrates = listOf(60, 120, 200, 300)
    ChipRow(
        items = bitrates.map { "$it" },
        selectedIndex = bitrates.indexOf(settings.bitrateMbps),
        onSelect = { i -> viewModel.updateSettings { it.copy(bitrateMbps = bitrates[i]) } }
    )

    // --- ZEBRA (only when engaged) -----------------------------------------
    if (scopes.zebras) {
        SectionLabel("Zebra level")
        LabeledSlider(
            label = "${scopes.zebraHighIre.roundToInt()} IRE",
            value = scopes.zebraHighIre,
            valueRange = 70f..100f,
            onValueChange = { v -> viewModel.updateScopes { it.copy(zebraHighIre = v) } }
        )
    }

    // --- SLATE -------------------------------------------------------------
    val slate by viewModel.slateInfo.collectAsState()
    SectionLabel("Slate")
    Row(modifier = Modifier.fillMaxWidth()) {
        LabeledTextField(
            label = "ROLL", value = slate.roll,
            onValueChange = { v -> viewModel.updateSlate { it.copy(roll = v) } },
            modifier = Modifier.weight(1f)
        )
        Spacer(modifier = Modifier.width(8.dp))
        LabeledTextField(
            label = "SCENE", value = slate.scene,
            onValueChange = { v -> viewModel.updateSlate { it.copy(scene = v) } },
            modifier = Modifier.weight(1f)
        )
        Spacer(modifier = Modifier.width(8.dp))
        LabeledTextField(
            label = "TAKE", value = slate.take.toString(),
            onValueChange = { v ->
                val n = v.toIntOrNull()
                if (v.isEmpty() || n != null) viewModel.updateSlate { it.copy(take = n ?: 1) }
            },
            numeric = true, modifier = Modifier.weight(1f)
        )
    }
    Spacer(modifier = Modifier.height(6.dp))
    val nextSuffix = if (settings.outputMode == OutputMode.CINEMA_DNG) "/ (CinemaDNG)" else ".mp4"
    MonoText("next: ${slate.fileStem()}$nextSuffix", color = TextFaint, size = 11)

    // --- PRESETS (folded in from the old KIT tab) --------------------------
    PresetsSection(viewModel)

    // --- DIRECTOR (remote pairing) -----------------------------------------
    SectionLabel("Director — laptop remote")
    val remotePin by viewModel.remotePin.collectAsState()
    MonoText(viewModel.remoteUrl, color = TextDim, size = 12)
    Spacer(modifier = Modifier.height(4.dp))
    Row(verticalAlignment = Alignment.CenterVertically) {
        LabelText("PIN", color = TextFaint, size = 11)
        Spacer(modifier = Modifier.width(8.dp))
        MonoText(remotePin, color = TextPrimary, size = 18, weight = androidx.compose.ui.text.font.FontWeight.Medium)
    }
    Spacer(modifier = Modifier.height(8.dp))
    Chip(text = "NEW PIN", selected = false, onClick = { viewModel.regenerateRemotePin() })
}

/** Best-effort display name for a SAF-picked document Uri, for the imported LUT's file name. */
private fun queryDisplayName(context: Context, uri: android.net.Uri): String? {
    var cursor: Cursor? = null
    return try {
        cursor = context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)
        if (cursor != null && cursor.moveToFirst()) {
            val idx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            if (idx >= 0) cursor.getString(idx) else null
        } else null
    } catch (e: Exception) {
        null
    } finally {
        cursor?.close()
    }
}

/** A chip row that wraps to a new line when it doesn't fit ~300dp width. */
@Composable
internal fun FlowChips(
    labels: List<String>,
    isSelected: (Int) -> Boolean,
    onSelect: (Int) -> Unit,
) {
    val rows = mutableListOf<MutableList<Int>>()
    var currentLen = 0
    var currentRow = mutableListOf<Int>()
    labels.forEachIndexed { i, label ->
        val cost = label.length + 3
        if (currentLen + cost > 34 && currentRow.isNotEmpty()) {
            rows.add(currentRow)
            currentRow = mutableListOf()
            currentLen = 0
        }
        currentRow.add(i)
        currentLen += cost
    }
    if (currentRow.isNotEmpty()) rows.add(currentRow)

    Column {
        rows.forEach { row ->
            Row(modifier = Modifier.padding(bottom = 6.dp)) {
                row.forEach { i ->
                    Chip(
                        text = labels[i],
                        selected = isSelected(i),
                        onClick = { onSelect(i) },
                        modifier = Modifier.padding(end = 6.dp)
                    )
                }
            }
        }
    }
}
