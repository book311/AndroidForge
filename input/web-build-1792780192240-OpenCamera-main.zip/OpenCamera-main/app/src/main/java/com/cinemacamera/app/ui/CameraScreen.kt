package com.cinemacamera.app.ui

import android.view.SurfaceHolder
import android.view.SurfaceView
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import com.cinemacamera.app.MainViewModel
import com.cinemacamera.domain.Timecode

@Composable
fun CameraScreen(viewModel: MainViewModel) {
    MaterialTheme(colorScheme = darkColorScheme(background = Viewfinder, surface = Viewfinder)) {
        val engineState by viewModel.engine.state.collectAsState()
        val stats by viewModel.engine.stats.collectAsState()
        val uiMessage by viewModel.uiMessage.collectAsState()
        val isRecording by viewModel.isRecording.collectAsState()
        val scopeConfig by viewModel.scopeConfig.collectAsState()
        val waveform by viewModel.waveform.collectAsState()
        val settings by viewModel.engine.settings.collectAsState()
        val deviceHealth by viewModel.deviceHealth.collectAsState()
        val audioLevels by viewModel.engine.audioLevels.collectAsState()

        var chromeVisible by remember { mutableStateOf(true) }
        var deckOpen by remember { mutableStateOf(false) }
        var deckTab by remember { mutableStateOf(ActivePanel.LENS) }

        // Free-running timecode: always shown in the glance strip, live while recording.
        var timecode by remember { mutableStateOf<Timecode?>(null) }
        LaunchedEffect(Unit) {
            while (true) {
                timecode = runCatching { viewModel.currentTimecode() }.getOrNull()
                kotlinx.coroutines.delay(1000)
            }
        }

        Box(modifier = Modifier.fillMaxSize().background(Viewfinder)) {

            // --- VIEWFINDER --------------------------------------------------
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .clickable(
                        indication = null,
                        interactionSource = remember { MutableInteractionSource() }
                    ) { chromeVisible = !chromeVisible },
                contentAlignment = Alignment.Center
            ) {
                val aspectModifier = if (engineState.rawWidth > 0 && engineState.rawHeight > 0) {
                    Modifier.aspectRatio(engineState.rawWidth.toFloat() / engineState.rawHeight.toFloat())
                } else {
                    Modifier.fillMaxSize()
                }
                Box(modifier = aspectModifier.background(Color.Black)) {
                    AndroidView(
                        modifier = Modifier.fillMaxSize(),
                        factory = { context ->
                            SurfaceView(context).apply {
                                holder.addCallback(object : SurfaceHolder.Callback {
                                    override fun surfaceCreated(holder: SurfaceHolder) {
                                        viewModel.onPreviewSurfaceAvailable(holder.surface)
                                    }
                                    override fun surfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) {}
                                    override fun surfaceDestroyed(holder: SurfaceHolder) {
                                        viewModel.onPreviewSurfaceDestroyed()
                                    }
                                })
                            }
                        }
                    )
                    FramingGuideOverlay(guideAspect = settings.guideAspect, modifier = Modifier.fillMaxSize())
                }
            }

            // --- WAVEFORM SCOPE (engaged via rail; sits above the MENU pill) --
            val wf = waveform
            if (scopeConfig.waveform && wf != null) {
                WaveformOverlay(
                    data = wf,
                    modifier = Modifier
                        .align(Alignment.BottomStart)
                        .padding(start = 12.dp, bottom = 64.dp)
                )
            }

            // --- ZONE 1: GLANCE STRIP + audio (top-left chrome) ---------------
            AnimatedVisibility(
                visible = chromeVisible,
                enter = fadeIn(),
                exit = fadeOut(),
                modifier = Modifier.align(Alignment.TopStart).padding(12.dp)
            ) {
                Column {
                    GlanceStrip(
                        isRecording = isRecording,
                        timecode = timecode,
                        deviceHealth = deviceHealth,
                    )
                    if (isRecording) {
                        Spacer(Modifier.height(8.dp))
                        VuMeter(levels = audioLevels, modifier = Modifier.width(150.dp))
                        if (stats.framesDropped > 0) {
                            Spacer(Modifier.height(6.dp))
                            MonoText("DROP ${stats.framesDropped}", color = WarnAmber, size = 11)
                        }
                    }
                }
            }

            // --- ZONE 3: SCOPE RAIL (top-right chrome) ------------------------
            AnimatedVisibility(
                visible = chromeVisible,
                enter = fadeIn(),
                exit = fadeOut(),
                modifier = Modifier.align(Alignment.TopEnd).padding(12.dp)
            ) {
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    RailToggle("FC", scopeConfig.falseColor) { viewModel.updateScopes { it.copy(falseColor = !it.falseColor) } }
                    RailToggle("ZBR", scopeConfig.zebras) { viewModel.updateScopes { it.copy(zebras = !it.zebras) } }
                    RailToggle("PK", scopeConfig.focusPeaking) { viewModel.updateScopes { it.copy(focusPeaking = !it.focusPeaking) } }
                    RailToggle("WFM", scopeConfig.waveform) { viewModel.updateScopes { it.copy(waveform = !it.waveform) } }
                }
            }

            // --- TRANSIENT MESSAGE (feedback toast) ---------------------------
            if (uiMessage != null && chromeVisible) {
                Box(
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .padding(bottom = if (deckOpen) 218.dp else 20.dp)
                        .glassPill()
                        .padding(horizontal = 14.dp, vertical = 8.dp)
                ) {
                    LabelText(uiMessage!!, color = TextPrimary, size = 12)
                }
            }

            // --- THE DECK: MENU pill (closed) or docked sheet (open) ----------
            AnimatedVisibility(
                visible = chromeVisible && !deckOpen,
                enter = fadeIn(),
                exit = fadeOut(),
                modifier = Modifier.align(Alignment.BottomStart).padding(12.dp)
            ) {
                MenuPill(onClick = { deckOpen = true })
            }

            AnimatedVisibility(
                visible = deckOpen,
                enter = slideInVertically { it },
                exit = slideOutVertically { it },
                modifier = Modifier.align(Alignment.BottomCenter)
            ) {
                Deck(
                    viewModel = viewModel,
                    tab = deckTab,
                    onTab = { deckTab = it },
                    onClose = { deckOpen = false },
                )
            }

            // --- ZONE 4: RECORD BUTTON (right edge, centered) -----------------
            // Drawn last so it is never hidden — not by the chrome toggle, and
            // not by the open deck either.
            RecordButton(
                isRecording = isRecording,
                onClick = { viewModel.toggleRecording() },
                modifier = Modifier.align(Alignment.CenterEnd).padding(end = 16.dp),
            )
        }
    }
}

// =====================================================================
// ZONE 1 — Glance strip
// =====================================================================

@Composable
private fun GlanceStrip(
    isRecording: Boolean,
    timecode: Timecode?,
    deviceHealth: com.cinemacamera.app.DeviceHealth,
) {
    Row(
        modifier = Modifier.glassPill().padding(horizontal = 14.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        // Recording dot: green only while live, otherwise dim.
        Box(
            modifier = Modifier
                .size(9.dp)
                .clip(CircleShape)
                .background(if (isRecording) LiveGreen else TextFaint)
        )
        Spacer(Modifier.width(9.dp))
        MonoText(
            text = timecode?.toString() ?: "--:--:--:--",
            color = TextPrimary,
            size = 14,
            weight = androidx.compose.ui.text.font.FontWeight.Medium,
        )

        // Far end: battery / storage / thermal — grey unless past a threshold.
        Spacer(Modifier.width(22.dp))
        val battColor = when {
            deviceHealth.batteryPct in 0..9 -> CriticalRed
            deviceHealth.batteryPct in 0..19 -> WarnAmber
            else -> TextDim
        }
        MonoText(
            text = if (deviceHealth.batteryPct >= 0) "${deviceHealth.batteryPct}%" else "--",
            color = battColor, size = 12,
        )
        Spacer(Modifier.width(12.dp))
        val storColor = when {
            deviceHealth.freeStorageGb in 0f..0.999f -> CriticalRed
            deviceHealth.freeStorageGb in 0f..4.999f -> WarnAmber
            else -> TextDim
        }
        MonoText(
            text = if (deviceHealth.freeStorageGb >= 0f) "%.1fGB".format(deviceHealth.freeStorageGb) else "--",
            color = storColor, size = 12,
        )
        // Thermal only appears when it actually matters.
        val thermColor = when (deviceHealth.thermalStatus) {
            "CRIT" -> CriticalRed
            "HOT" -> WarnAmber
            else -> null
        }
        if (thermColor != null) {
            Spacer(Modifier.width(12.dp))
            MonoText(text = deviceHealth.thermalStatus, color = thermColor, size = 12)
        }
    }
}

// =====================================================================
// ZONE 3 — Scope rail toggle (green when engaged)
// =====================================================================

@Composable
private fun RailToggle(text: String, engaged: Boolean, onClick: () -> Unit) {
    val shape = RoundedCornerShape(999.dp)
    val fill = if (engaged) LiveGreen.copy(alpha = 0.16f) else GlassFill
    val borderColor = if (engaged) LiveGreen else GlassBorder
    val textColor = if (engaged) LiveGreen else TextDim
    Box(
        modifier = Modifier
            .height(34.dp)
            .clip(shape)
            .background(fill)
            .border(width = 1.dp, color = borderColor, shape = shape)
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp),
        contentAlignment = Alignment.Center
    ) {
        LabelText(text = text, color = textColor, size = 12, weight = androidx.compose.ui.text.font.FontWeight.SemiBold)
    }
}

// =====================================================================
// ZONE 4 — Record button (red; always visible)
// =====================================================================

@Composable
private fun RecordButton(isRecording: Boolean, onClick: () -> Unit, modifier: Modifier = Modifier) {
    Box(
        modifier = modifier
            .size(66.dp)
            .clip(CircleShape)
            .background(Color.Black.copy(alpha = 0.35f))
            .border(width = 3.dp, color = CriticalRed, shape = CircleShape)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        val innerShape = if (isRecording) RoundedCornerShape(6.dp) else CircleShape
        val innerSize = if (isRecording) 26.dp else 50.dp
        Box(
            modifier = Modifier
                .size(innerSize)
                .clip(innerShape)
                .background(CriticalRed)
        )
    }
}

// =====================================================================
// THE DECK
// =====================================================================

@Composable
private fun MenuPill(onClick: () -> Unit) {
    Row(
        modifier = Modifier
            .glassPill()
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        LabelText("MENU", color = TextPrimary, size = 13, weight = androidx.compose.ui.text.font.FontWeight.SemiBold)
        Spacer(Modifier.width(8.dp))
        Chevron(pointingUp = true, color = TextDim)
    }
}

@Composable
private fun Deck(
    viewModel: MainViewModel,
    tab: ActivePanel,
    onTab: (ActivePanel) -> Unit,
    onClose: () -> Unit,
) {
    val shape = RoundedCornerShape(topStart = 18.dp, topEnd = 18.dp)
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .height(210.dp)
            .clip(shape)
            .background(DeckFill)
            .border(width = 1.dp, color = DeckBorder, shape = shape)
    ) {
        // Close chevron centered on the top edge.
        Box(
            modifier = Modifier.fillMaxWidth().height(22.dp),
            contentAlignment = Alignment.Center,
        ) {
            Box(
                modifier = Modifier
                    .width(48.dp)
                    .fillMaxHeight()
                    .clickable(onClick = onClose),
                contentAlignment = Alignment.Center,
            ) {
                Chevron(pointingUp = false, color = TextDim)
            }
        }

        Row(modifier = Modifier.fillMaxWidth().fillMaxHeight()) {
            // Tab rail down the left edge.
            Column(
                modifier = Modifier.width(80.dp).fillMaxHeight().padding(start = 10.dp, top = 2.dp),
                horizontalAlignment = Alignment.Start,
            ) {
                DeckTab("MOVE", tab == ActivePanel.MOVE) { onTab(ActivePanel.MOVE) }
                DeckTab("LENS", tab == ActivePanel.LENS) { onTab(ActivePanel.LENS) }
                DeckTab("CLIPS", tab == ActivePanel.CLIPS) { onTab(ActivePanel.CLIPS) }
            }

            // Content for the active tab, scrolls within the deck.
            Column(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxHeight()
                    .padding(start = 12.dp, end = 16.dp)
                    .verticalScroll(rememberScrollState()),
            ) {
                when (tab) {
                    ActivePanel.MOVE -> MovesDeck(viewModel)
                    ActivePanel.LENS -> LensDeck(viewModel)
                    ActivePanel.CLIPS -> ClipsDeck(viewModel)
                    ActivePanel.NONE -> {}
                }
                Spacer(Modifier.height(12.dp))
            }
        }
    }
}

@Composable
private fun DeckTab(text: String, selected: Boolean, onClick: () -> Unit) {
    val shape = RoundedCornerShape(8.dp)
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(34.dp)
            .padding(top = 3.dp, bottom = 3.dp, end = 6.dp)
            .clip(shape)
            .background(if (selected) SelectedFill else Color.Transparent)
            .clickable(onClick = onClick)
            .padding(horizontal = 8.dp),
        contentAlignment = Alignment.CenterStart,
    ) {
        LabelText(
            text = text,
            color = if (selected) TextPrimary else TextDim,
            size = 12,
            weight = if (selected) androidx.compose.ui.text.font.FontWeight.SemiBold else androidx.compose.ui.text.font.FontWeight.Medium,
        )
    }
}

/** A small chevron drawn with two strokes; points up (open) or down (close). */
@Composable
private fun Chevron(pointingUp: Boolean, color: Color) {
    androidx.compose.foundation.Canvas(modifier = Modifier.size(width = 16.dp, height = 10.dp)) {
        val w = size.width
        val h = size.height
        val stroke = 2.dp.toPx()
        if (pointingUp) {
            drawLine(color, Offset(0f, h), Offset(w / 2f, 0f), stroke, StrokeCap.Round)
            drawLine(color, Offset(w / 2f, 0f), Offset(w, h), stroke, StrokeCap.Round)
        } else {
            drawLine(color, Offset(0f, 0f), Offset(w / 2f, h), stroke, StrokeCap.Round)
            drawLine(color, Offset(w / 2f, h), Offset(w, 0f), stroke, StrokeCap.Round)
        }
    }
}
