package com.cinemacamera.app

import android.content.Context
import com.cinemacamera.domain.CaptureSettings
import com.cinemacamera.domain.ExposureSettings
import com.cinemacamera.domain.LogProfile
import com.cinemacamera.domain.OutputMode
import com.cinemacamera.domain.Preset
import com.cinemacamera.domain.ProcessingToggles
import com.cinemacamera.domain.VideoCodec
import dagger.hilt.android.qualifiers.ApplicationContext
import java.io.File
import javax.inject.Inject
import javax.inject.Singleton
import org.json.JSONObject

/** Saved "kits" (e.g. "Night: ISO 800, 180° shutter, 24fps") as JSON files. */
@Singleton
class PresetsRepository @Inject constructor(
    @ApplicationContext context: Context,
) {
    private val dir = File(context.filesDir, "presets").apply { mkdirs() }

    fun list(): List<Preset> =
        dir.listFiles { f -> f.extension == "json" }
            ?.mapNotNull { runCatching { read(it) }.getOrNull() }
            ?.sortedBy { it.name.lowercase() }
            ?: emptyList()

    fun save(preset: Preset) {
        File(dir, fileName(preset.name)).writeText(write(preset).toString(2))
    }

    fun delete(name: String) {
        File(dir, fileName(name)).delete()
    }

    private fun fileName(name: String) =
        name.replace(Regex("[^A-Za-z0-9-_ ]"), "_") + ".json"

    private fun write(p: Preset): JSONObject {
        val s = p.settings
        return JSONObject().apply {
            put("name", p.name)
            put("sensorId", s.sensorId ?: JSONObject.NULL)
            put("rawWidth", s.rawWidth)
            put("rawHeight", s.rawHeight)
            put("fps", s.fps)
            put("guideAspect", s.guideAspect.toDouble())
            put("autoExposure", s.exposure.auto)
            put("iso", s.exposure.iso)
            put("shutterNs", s.exposure.shutterNs)
            put("shutterAngle", s.exposure.shutterAngle.toDouble())
            put("focusDiopters", s.focusDiopters.toDouble())
            put("logProfile", s.logProfile.name)
            put("encodeFullRes", s.encodeFullRes)
            put("bitrateMbps", s.bitrateMbps)
            put("codec", s.codec.name)
            put("outputMode", s.outputMode.name)
            put("acesIdt", s.acesIdt)
            put("previewLutName", s.previewLutName ?: JSONObject.NULL)
            val t = s.processing
            put("noiseReduction", t.noiseReduction)
            put("edgeEnhancement", t.edgeEnhancement)
            put("lensShading", t.lensShading)
            put("hotPixel", t.hotPixel)
            put("aberrationCorrection", t.aberrationCorrection)
            put("distortionCorrection", t.distortionCorrection)
            put("forceIdentityTonemap", t.forceIdentityTonemap)
            put("videoStabilization", t.videoStabilization)
        }
    }

    private fun read(f: File): Preset {
        val o = JSONObject(f.readText())
        return Preset(
            name = o.getString("name"),
            settings = CaptureSettings(
                sensorId = if (o.isNull("sensorId")) null else o.getString("sensorId"),
                rawWidth = o.optInt("rawWidth"),
                rawHeight = o.optInt("rawHeight"),
                fps = o.optInt("fps", 30),
                guideAspect = o.optDouble("guideAspect", 0.0).toFloat(),
                exposure = ExposureSettings(
                    auto = o.optBoolean("autoExposure", true),
                    iso = o.optInt("iso", 400),
                    shutterNs = o.optLong("shutterNs", 0L),
                    shutterAngle = o.optDouble("shutterAngle", 180.0).toFloat(),
                ),
                focusDiopters = o.optDouble("focusDiopters", -1.0).toFloat(),
                processing = ProcessingToggles(
                    noiseReduction = o.optBoolean("noiseReduction", false),
                    edgeEnhancement = o.optBoolean("edgeEnhancement", false),
                    lensShading = o.optBoolean("lensShading", false),
                    hotPixel = o.optBoolean("hotPixel", false),
                    aberrationCorrection = o.optBoolean("aberrationCorrection", false),
                    distortionCorrection = o.optBoolean("distortionCorrection", false),
                    forceIdentityTonemap = o.optBoolean("forceIdentityTonemap", true),
                    videoStabilization = o.optBoolean("videoStabilization", false),
                ),
                logProfile = runCatching { LogProfile.valueOf(o.optString("logProfile")) }
                    .getOrDefault(LogProfile.CINE_FLAT),
                encodeFullRes = o.optBoolean("encodeFullRes", false),
                bitrateMbps = o.optInt("bitrateMbps", 120),
                codec = runCatching { VideoCodec.valueOf(o.optString("codec")) }.getOrDefault(VideoCodec.HEVC),
                outputMode = runCatching { OutputMode.valueOf(o.optString("outputMode")) }
                    .getOrDefault(OutputMode.VIDEO),
                acesIdt = o.optBoolean("acesIdt", true),
                previewLutName = if (o.isNull("previewLutName")) null
                    else o.optString("previewLutName").takeIf { it.isNotEmpty() },
            ),
        )
    }
}
