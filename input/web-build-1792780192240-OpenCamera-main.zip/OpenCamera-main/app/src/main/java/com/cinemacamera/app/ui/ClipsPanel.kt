package com.cinemacamera.app.ui

import android.content.Intent
import android.media.MediaMetadataRetriever
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.content.FileProvider
import com.cinemacamera.app.MainViewModel
import java.io.File
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private data class ClipItem(
    val videoFile: File,
    val gcsvFile: File,
    val sizeMb: Double,
    val durationMs: Long,
    /** IMU sample count from the .gcsv (lines minus header), or null if no .gcsv exists. */
    val gcsvSamples: Int?,
)

/** A CinemaDNG take: a folder of `<stem>_NNNNNN.dng` frames + gcsv + json sidecar. */
private data class DngClipItem(
    val dir: File,
    val frameCount: Int,
    val sizeGb: Double,
)

/** CLIPS deck tab — recorded takes with open/export/delete. */
@Composable
fun ClipsDeck(viewModel: MainViewModel) {
    val context = LocalContext.current
    var clips by remember { mutableStateOf<List<ClipItem>>(emptyList()) }
    var dngClips by remember { mutableStateOf<List<DngClipItem>>(emptyList()) }
    var refreshToken by remember { mutableIntStateOf(0) }

    LaunchedEffect(refreshToken) {
        withContext(Dispatchers.IO) {
            val dir = viewModel.clipsDirectory()
            clips = loadClips(dir)
            dngClips = loadDngClips(dir)
        }
    }

    SectionLabel("Recorded takes")
    if (clips.isEmpty() && dngClips.isEmpty()) {
        LabelText("no clips yet", color = TextFaint, size = 11)
    }
    clips.forEach { clip ->
        ClipRow(
            clip = clip,
            onExport = { viewModel.exportClipToGallery(clip.videoFile) },
            onOpen = {
                runCatching {
                    val authority = "${context.packageName}.fileprovider"
                    val uri = FileProvider.getUriForFile(context, authority, clip.videoFile)
                    val intent = Intent(Intent.ACTION_VIEW).apply {
                        setDataAndType(uri, "video/mp4")
                        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    }
                    context.startActivity(intent)
                }
            },
            onDelete = {
                viewModel.deleteClip(clip.videoFile)
                refreshToken++
            },
        )
    }
    dngClips.forEach { clip ->
        DngClipRow(
            clip = clip,
            onDelete = {
                viewModel.deleteDngClip(clip.dir)
                refreshToken++
            },
        )
    }
}

private fun loadClips(dir: File): List<ClipItem> {
    if (!dir.exists()) return emptyList()
    return dir.listFiles { f -> f.isFile && f.extension.equals("mp4", ignoreCase = true) }
        ?.sortedByDescending { it.lastModified() }
        ?.map { video ->
            val gcsv = File(dir, video.nameWithoutExtension + ".gcsv")
            val sizeMb = video.length() / (1024.0 * 1024.0)
            val durationMs = runCatching {
                MediaMetadataRetriever().use { retriever ->
                    retriever.setDataSource(video.absolutePath)
                    retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull()
                }
            }.getOrNull() ?: 0L
            val gcsvSamples = if (gcsv.exists()) {
                runCatching { (gcsv.readLines().size - 1).coerceAtLeast(0) }.getOrNull()
            } else null
            ClipItem(video, gcsv, sizeMb, durationMs, gcsvSamples)
        }
        ?: emptyList()
}

/** A directory under clips/ counts as a CinemaDNG take iff it contains at least one .dng file. */
private fun loadDngClips(dir: File): List<DngClipItem> {
    if (!dir.exists()) return emptyList()
    return dir.listFiles { f -> f.isDirectory }
        ?.mapNotNull { d ->
            val frames = d.listFiles { f -> f.extension.equals("dng", ignoreCase = true) } ?: emptyArray()
            if (frames.isEmpty()) return@mapNotNull null
            val sizeGb = (d.listFiles()?.sumOf { it.length() } ?: 0L) / (1024.0 * 1024.0 * 1024.0)
            DngClipItem(d, frames.size, sizeGb)
        }
        ?.sortedByDescending { it.dir.lastModified() }
        ?: emptyList()
}

/** Per-row EXPORT button lifecycle: idle → copying → done (or back to idle on failure). */
private enum class ExportState { IDLE, EXPORTING, DONE }

@Composable
private fun ClipRow(
    clip: ClipItem,
    onOpen: () -> Unit,
    onExport: suspend () -> Boolean,
    onDelete: () -> Unit,
) {
    var confirming by remember(clip.videoFile.path) { mutableStateOf(false) }
    var exportState by remember(clip.videoFile.path) { mutableStateOf(ExportState.IDLE) }
    val scope = rememberCoroutineScope()

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(8.dp))
            .clickable(onClick = onOpen)
            .padding(vertical = 8.dp, horizontal = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(modifier = Modifier.weight(1f)) {
            MonoText(clip.videoFile.name, color = TextPrimary, size = 12)
            val gcsvText = clip.gcsvSamples?.let { "$it imu" } ?: "no gcsv"
            MonoText(
                "%.1f MB · %.1fs · %s".format(clip.sizeMb, clip.durationMs / 1000f, gcsvText),
                color = TextDim, size = 10,
            )
        }
        val exportColor = if (exportState == ExportState.EXPORTING) TextDim else TextPrimary
        PillButton(
            text = when (exportState) {
                ExportState.IDLE -> "EXPORT"
                ExportState.EXPORTING -> "EXPORTING"
                ExportState.DONE -> "DONE"
            },
            color = exportColor,
            enabled = exportState == ExportState.IDLE,
            onClick = {
                exportState = ExportState.EXPORTING
                scope.launch { exportState = if (onExport()) ExportState.DONE else ExportState.IDLE }
            },
        )
        Spacer(modifier = Modifier.width(6.dp))
        PillButton(
            text = if (confirming) "CONFIRM?" else "DELETE",
            color = CriticalRed,
            onClick = { if (confirming) onDelete() else confirming = true },
        )
    }
}

/** CinemaDNG take row: no EXPORT (folder download isn't supported), DELETE removes the whole folder. */
@Composable
private fun DngClipRow(clip: DngClipItem, onDelete: () -> Unit) {
    var confirming by remember(clip.dir.path) { mutableStateOf(false) }

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(8.dp))
            .padding(vertical = 8.dp, horizontal = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(modifier = Modifier.weight(1f)) {
            MonoText(clip.dir.name, color = TextPrimary, size = 12)
            MonoText(
                "%d frames · %.2f GB · DNG".format(clip.frameCount, clip.sizeGb),
                color = TextDim, size = 10,
            )
        }
        PillButton(text = "EXPORT", color = TextFaint, enabled = false, onClick = {})
        Spacer(modifier = Modifier.width(6.dp))
        PillButton(
            text = if (confirming) "CONFIRM?" else "DELETE",
            color = CriticalRed,
            onClick = { if (confirming) onDelete() else confirming = true },
        )
    }
}

@Composable
private fun PillButton(text: String, color: androidx.compose.ui.graphics.Color, enabled: Boolean = true, onClick: () -> Unit) {
    val shape = RoundedCornerShape(999.dp)
    val c = if (enabled) color else TextFaint
    Box(
        modifier = Modifier
            .height(32.dp)
            .clip(shape)
            .border(width = 1.dp, color = c.copy(alpha = 0.7f), shape = shape)
            .then(if (enabled) Modifier.clickable(onClick = onClick) else Modifier)
            .padding(horizontal = 12.dp),
        contentAlignment = Alignment.Center,
    ) {
        LabelText(text, color = c, size = 11)
    }
}
