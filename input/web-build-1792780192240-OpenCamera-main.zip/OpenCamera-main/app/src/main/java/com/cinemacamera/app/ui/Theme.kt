@file:OptIn(androidx.compose.ui.text.ExperimentalTextApi::class)

package com.cinemacamera.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontVariation
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.cinemacamera.R

// =====================================================================
// Design language — "Viewfinder HUD: glass rail + docked deck"
//
// Rules that this file enforces so the rest of the app can't drift:
//   • Base is near-black; surfaces are smoked glass (translucent scrim +
//     hairline light border), never flat opaque panels.
//   • GREEN (#3DDC97) marks anything LIVE / engaged ONLY — the recording
//     dot, an engaged scope, a running sequence. It is never decorative,
//     so persistent *selections* use white emphasis instead (Selected*).
//   • AMBER (#E8B339) = warning, RED (#E5484D) = critical. Reserved for
//     thermal / battery / storage thresholds and the record state.
//   • Manrope for every label / UI chrome; JetBrains Mono STRICTLY for
//     numeric telemetry (timecode, resolution, counts, sizes). The
//     LabelText / MonoText primitives below are the only way to draw text
//     so the two families never get mixed inside one string.
// =====================================================================

// --- Palette ----------------------------------------------------------

/** Near-black viewfinder base. */
val Viewfinder = Color(0xFF0B0C0B)

/** Live / engaged. The only "positive" colour in the system. */
val LiveGreen = Color(0xFF3DDC97)

/** Warning threshold (thermal HOT, low battery, low storage). */
val WarnAmber = Color(0xFFE8B339)

/** Critical state (record, thermal CRIT, empty battery/storage). */
val CriticalRed = Color(0xFFE5484D)

/** Primary readable text over the viewfinder. */
val TextPrimary = Color(0xFFF2F3F1)

/** Secondary / neutral telemetry — the default, uncoloured state. */
val TextDim = Color(0xFF8A8D8A)

/** Faint captions / hints. */
val TextFaint = Color(0xFF5C5F5C)

// Glass surfaces. A dark scrim (for legibility over live video) plus a
// hairline light border reads as smoked glass without a real backdrop
// blur, which isn't available over a SurfaceView.
val GlassFill = Color.Black.copy(alpha = 0.42f)
val GlassBorder = Color.White.copy(alpha = 0.10f)

/** The docked deck carries dense content, so it sits on a heavier scrim. */
val DeckFill = Color(0xFF0B0C0B).copy(alpha = 0.90f)
val DeckBorder = Color.White.copy(alpha = 0.08f)

// Selection emphasis — persistent choices are shown with light, not colour,
// so green keeps meaning "live".
val SelectedFill = Color.White.copy(alpha = 0.13f)
val SelectedBorder = Color.White.copy(alpha = 0.34f)

// --- Type -------------------------------------------------------------

val Manrope = FontFamily(
    Font(R.font.manrope_variable, weight = FontWeight.Normal, variationSettings = FontVariation.Settings(FontVariation.weight(400))),
    Font(R.font.manrope_variable, weight = FontWeight.Medium, variationSettings = FontVariation.Settings(FontVariation.weight(500))),
    Font(R.font.manrope_variable, weight = FontWeight.SemiBold, variationSettings = FontVariation.Settings(FontVariation.weight(600))),
    Font(R.font.manrope_variable, weight = FontWeight.Bold, variationSettings = FontVariation.Settings(FontVariation.weight(700))),
)

val JetBrainsMono = FontFamily(
    Font(R.font.jetbrains_mono_variable, weight = FontWeight.Normal, variationSettings = FontVariation.Settings(FontVariation.weight(400))),
    Font(R.font.jetbrains_mono_variable, weight = FontWeight.Medium, variationSettings = FontVariation.Settings(FontVariation.weight(500))),
    Font(R.font.jetbrains_mono_variable, weight = FontWeight.Bold, variationSettings = FontVariation.Settings(FontVariation.weight(700))),
)

/**
 * Manrope text — for labels and all UI chrome. Slight positive letter
 * spacing gives the small caps-style labels a technical, legible feel.
 */
@Composable
fun LabelText(
    text: String,
    modifier: Modifier = Modifier,
    color: Color = TextPrimary,
    size: Int = 12,
    weight: FontWeight = FontWeight.Medium,
) {
    Text(
        text = text,
        color = color,
        fontSize = size.sp,
        fontFamily = Manrope,
        fontWeight = weight,
        letterSpacing = 0.3.sp,
        modifier = modifier,
    )
}

/**
 * JetBrains Mono text — STRICTLY numeric telemetry (timecode, resolution,
 * frame counts, file sizes, positions). Tabular, so digits don't jitter.
 */
@Composable
fun MonoText(
    text: String,
    modifier: Modifier = Modifier,
    color: Color = TextPrimary,
    size: Int = 12,
    weight: FontWeight = FontWeight.Normal,
) {
    Text(
        text = text,
        color = color,
        fontSize = size.sp,
        fontFamily = JetBrainsMono,
        fontWeight = weight,
        modifier = modifier,
    )
}

// --- Glass modifiers --------------------------------------------------

/** A floating glass surface: scrim fill + hairline border, clipped to [shape]. */
fun Modifier.glass(shape: Shape): Modifier =
    this.clip(shape)
        .background(GlassFill)
        .border(width = 1.dp, color = GlassBorder, shape = shape)

/** A glass pill (fully rounded), the default chrome container. */
fun Modifier.glassPill(radius: Dp = 999.dp): Modifier = glass(RoundedCornerShape(radius))

/** The record → green→amber→red level gradient used by the audio bars. */
val AudioLevelBrush: Brush = Brush.horizontalGradient(
    0.0f to LiveGreen,
    0.7f to WarnAmber,
    1.0f to CriticalRed,
)
