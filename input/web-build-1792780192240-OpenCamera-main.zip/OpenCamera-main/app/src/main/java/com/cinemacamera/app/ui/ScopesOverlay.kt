package com.cinemacamera.app.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.dp
import com.cinemacamera.domain.WaveformData

/**
 * White crop-guide lines marking a centered [guideAspect] (w/h) crop within
 * the full open-gate frame, plus a slight darkening of the area outside it.
 */
@Composable
fun FramingGuideOverlay(guideAspect: Float, modifier: Modifier = Modifier) {
    if (guideAspect <= 0f) return
    Canvas(modifier = modifier) {
        val frameW = size.width
        val frameH = size.height
        val frameAspect = frameW / frameH

        var guideW = frameW
        var guideH = frameH
        if (guideAspect > frameAspect) {
            // Guide is wider than the frame: match width, shrink height.
            guideH = frameW / guideAspect
        } else {
            guideW = frameH * guideAspect
        }
        val left = (frameW - guideW) / 2f
        val top = (frameH - guideH) / 2f

        // Darken outside the guide.
        val scrim = Color.Black.copy(alpha = 0.45f)
        if (top > 0f) {
            drawRect(color = scrim, topLeft = Offset(0f, 0f), size = androidx.compose.ui.geometry.Size(frameW, top))
            drawRect(
                color = scrim,
                topLeft = Offset(0f, top + guideH),
                size = androidx.compose.ui.geometry.Size(frameW, frameH - top - guideH)
            )
        }
        if (left > 0f) {
            drawRect(color = scrim, topLeft = Offset(0f, top), size = androidx.compose.ui.geometry.Size(left, guideH))
            drawRect(
                color = scrim,
                topLeft = Offset(left + guideW, top),
                size = androidx.compose.ui.geometry.Size(frameW - left - guideW, guideH)
            )
        }

        drawRect(
            color = Color.White,
            topLeft = Offset(left, top),
            size = androidx.compose.ui.geometry.Size(guideW, guideH),
            style = Stroke(width = 1.dp.toPx())
        )
    }
}

/** Bottom-left luminance waveform scope, drawn from the latest [WaveformData]. */
@Composable
fun WaveformOverlay(data: WaveformData, modifier: Modifier = Modifier) {
    Box(
        modifier = modifier
            .size(width = 260.dp, height = 140.dp)
            .background(Color.Black.copy(alpha = 0.6f))
    ) {
        val points = remember(data) {
            val packed = ArrayList<Triple<Int, Int, Int>>()
            for (row in 0 until data.rows) {
                for (col in 0 until data.cols) {
                    val v = data.bins[row * data.cols + col].toInt() and 0xFF
                    if (v > 0) packed.add(Triple(row, col, v))
                }
            }
            packed
        }

        Canvas(modifier = Modifier.size(width = 260.dp, height = 140.dp)) {
            val w = size.width
            val h = size.height
            val colWidth = w / data.cols
            val rowHeight = h / data.rows

            points.forEach { (row, col, value) ->
                val alpha = value / 255f
                val x = col * colWidth
                // row 0 = 0 IRE = bottom of the scope.
                val y = h - (row + 1) * rowHeight
                drawRect(
                    color = Color(0f, 1f, 0f, alpha),
                    topLeft = Offset(x, y),
                    size = androidx.compose.ui.geometry.Size(colWidth + 0.5f, rowHeight + 0.5f)
                )
            }

            val gridColor = Color.White.copy(alpha = 0.3f)
            listOf(0.25f, 0.5f, 0.75f).forEach { frac ->
                val y = h * (1f - frac)
                drawLine(
                    color = gridColor,
                    start = Offset(0f, y),
                    end = Offset(w, y),
                    strokeWidth = 1f
                )
            }
        }
    }
}
