package com.cinemacamera.app

import android.content.Context
import android.net.Uri
import dagger.hilt.android.qualifiers.ApplicationContext
import java.io.File
import javax.inject.Inject
import javax.inject.Singleton

/** Parsed 3D LUT ready for [com.cinemacamera.camera.NativePipeline.setLut]. */
data class LutData(val size: Int, val data: FloatArray)

/** Installed .cube LUTs under filesDir/luts, imported via SAF from the LENS panel. */
@Singleton
class LutRepository @Inject constructor(
    @ApplicationContext private val context: Context,
) {
    private val dir = File(context.filesDir, "luts").apply { mkdirs() }

    fun list(): List<String> =
        dir.listFiles { f -> f.extension.equals("cube", ignoreCase = true) }
            ?.map { it.nameWithoutExtension }
            ?.sortedBy { it.lowercase() }
            ?: emptyList()

    /** Copies the SAF-picked file into filesDir/luts. Returns the installed name. */
    fun importFrom(uri: Uri, displayName: String): String {
        val safeName = displayName.substringBeforeLast('.')
            .ifBlank { "LUT" }
            .replace(Regex("[^A-Za-z0-9-_ ]"), "_")
        val dest = File(dir, "$safeName.cube")
        val input = context.contentResolver.openInputStream(uri)
            ?: error("Could not open $uri")
        input.use { i -> dest.outputStream().use { o -> i.copyTo(o) } }
        return safeName
    }

    fun delete(name: String) {
        File(dir, "$name.cube").delete()
    }

    fun load(name: String): LutData = parse(File(dir, "$name.cube").readLines())

    /** Parses a .cube file: LUT_3D_SIZE, optional DOMAIN_MIN/MAX, R-fastest-varying data rows. */
    private fun parse(lines: List<String>): LutData {
        var size = -1
        var domainMin = floatArrayOf(0f, 0f, 0f)
        var domainMax = floatArrayOf(1f, 1f, 1f)
        val values = ArrayList<Float>()
        for (raw in lines) {
            val line = raw.substringBefore('#').trim()
            if (line.isEmpty()) continue
            val upper = line.uppercase()
            when {
                upper.startsWith("LUT_1D_SIZE") ->
                    throw IllegalArgumentException("1D LUTs are not supported")
                upper.startsWith("LUT_3D_SIZE") ->
                    size = line.substringAfter(' ').trim().toInt()
                upper.startsWith("DOMAIN_MIN") ->
                    domainMin = line.split(Regex("\\s+")).drop(1).map { it.toFloat() }.toFloatArray()
                upper.startsWith("DOMAIN_MAX") ->
                    domainMax = line.split(Regex("\\s+")).drop(1).map { it.toFloat() }.toFloatArray()
                upper.startsWith("TITLE") -> {}
                else -> {
                    val parts = line.split(Regex("\\s+")).mapNotNull { it.toFloatOrNull() }
                    if (parts.size == 3) values.addAll(parts)
                }
            }
        }
        require(size > 0) { "Missing LUT_3D_SIZE" }
        val expected = size * size * size * 3
        require(values.size == expected) { "Expected $expected values, got ${values.size}" }

        val range = FloatArray(3) { c -> (domainMax[c] - domainMin[c]).takeIf { it != 0f } ?: 1f }
        val out = FloatArray(values.size)
        for (i in values.indices) {
            val c = i % 3
            out[i] = ((values[i] - domainMin[c]) / range[c]).coerceIn(0f, 1f)
        }
        return LutData(size, out)
    }
}
