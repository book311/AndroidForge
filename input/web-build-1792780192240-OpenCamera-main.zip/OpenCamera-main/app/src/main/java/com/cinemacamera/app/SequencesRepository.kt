package com.cinemacamera.app

import android.content.Context
import com.cinemacamera.domain.AutoTrack
import com.cinemacamera.domain.AutoTrackKind
import com.cinemacamera.domain.Easing
import com.cinemacamera.domain.Keyframe
import com.cinemacamera.domain.Sequence
import dagger.hilt.android.qualifiers.ApplicationContext
import java.io.File
import javax.inject.Inject
import javax.inject.Singleton
import org.json.JSONArray
import org.json.JSONObject

/**
 * Saved automation [Sequence]s as one JSON file per item — same on-disk shape
 * (schemaVersion, tracks/keyframes) a future browser timeline editor edits.
 */
@Singleton
class SequencesRepository @Inject constructor(
    @ApplicationContext context: Context,
) {
    private val dir = File(context.filesDir, "sequences").apply { mkdirs() }

    fun list(): List<Sequence> =
        dir.listFiles { f -> f.extension == "json" }
            ?.mapNotNull { runCatching { read(it) }.getOrNull() }
            ?.sortedBy { it.name.lowercase() }
            ?: emptyList()

    fun save(seq: Sequence) {
        File(dir, fileName(seq.name)).writeText(write(seq).toString(2))
    }

    fun delete(name: String) {
        File(dir, fileName(name)).delete()
    }

    private fun fileName(name: String) =
        name.replace(Regex("[^A-Za-z0-9-_ ]"), "_") + ".json"

    private fun write(seq: Sequence): JSONObject = JSONObject().apply {
        put("name", seq.name)
        put("durationMs", seq.durationMs)
        put("schemaVersion", seq.schemaVersion)
        put("tracks", JSONArray().apply {
            seq.tracks.forEach { track ->
                put(JSONObject().apply {
                    put("kind", track.kind.name)
                    put("keyframes", JSONArray().apply {
                        track.keyframes.forEach { kf ->
                            put(JSONObject().apply {
                                put("t", kf.timeMs)
                                put("v", kf.value)
                                put("e", kf.easing.name)
                            })
                        }
                    })
                })
            }
        })
    }

    private fun read(f: File): Sequence {
        val o = JSONObject(f.readText())
        val tracksArr = o.optJSONArray("tracks") ?: JSONArray()
        val tracks = (0 until tracksArr.length()).map { i ->
            val t = tracksArr.getJSONObject(i)
            val kfArr = t.optJSONArray("keyframes") ?: JSONArray()
            val keyframes = (0 until kfArr.length()).map { j ->
                val k = kfArr.getJSONObject(j)
                Keyframe(
                    timeMs = k.getLong("t"),
                    value = k.getDouble("v"),
                    easing = runCatching { Easing.valueOf(k.optString("e")) }.getOrDefault(Easing.SMOOTH),
                )
            }.sortedBy { it.timeMs }
            AutoTrack(kind = AutoTrackKind.valueOf(t.getString("kind")), keyframes = keyframes)
        }
        return Sequence(
            name = o.getString("name"),
            durationMs = o.optLong("durationMs", 5000L),
            tracks = tracks,
            schemaVersion = o.optInt("schemaVersion", 1),
        )
    }
}
