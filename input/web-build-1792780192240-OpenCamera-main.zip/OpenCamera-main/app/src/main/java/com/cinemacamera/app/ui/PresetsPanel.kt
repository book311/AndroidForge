package com.cinemacamera.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.unit.dp
import com.cinemacamera.app.MainViewModel
import com.cinemacamera.domain.Preset

/** PRESETS section, rendered inside the LENS deck tab (was the KIT panel). */
@Composable
fun PresetsSection(viewModel: MainViewModel) {
    val presets by viewModel.presets.collectAsState()
    var newName by remember { mutableStateOf("") }

    SectionLabel("Presets")
    Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Box(modifier = Modifier.weight(1f)) {
            GlassField(value = newName, onValueChange = { newName = it })
        }
        Spacer(modifier = Modifier.width(8.dp))
        Chip(
            text = "SAVE",
            selected = newName.isNotBlank(),
            onClick = {
                if (newName.isNotBlank()) {
                    viewModel.savePreset(newName)
                    newName = ""
                }
            }
        )
    }

    Spacer(modifier = Modifier.height(8.dp))
    if (presets.isEmpty()) {
        LabelText("no presets saved", color = TextFaint, size = 11)
    }
    presets.forEach { preset ->
        PresetRow(
            preset = preset,
            onApply = { viewModel.applyPreset(preset) },
            onDelete = { viewModel.deletePreset(preset.name) }
        )
    }
}

@Composable
private fun PresetRow(preset: Preset, onApply: () -> Unit, onDelete: () -> Unit) {
    val s = preset.settings
    val summary = "${s.fps}fps · ISO ${s.exposure.iso} · ${s.logProfile.name}"
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(8.dp))
            .clickable(onClick = onApply)
            .padding(vertical = 8.dp, horizontal = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f)) {
            LabelText(preset.name, color = TextPrimary, size = 12)
            MonoText(summary, color = TextDim, size = 10)
        }
        Box(
            modifier = Modifier
                .height(32.dp)
                .clip(RoundedCornerShape(999.dp))
                .border(width = 1.dp, color = CriticalRed.copy(alpha = 0.7f), shape = RoundedCornerShape(999.dp))
                .clickable(onClick = onDelete)
                .padding(horizontal = 12.dp),
            contentAlignment = Alignment.Center
        ) {
            LabelText("DEL", color = CriticalRed, size = 11)
        }
    }
}
