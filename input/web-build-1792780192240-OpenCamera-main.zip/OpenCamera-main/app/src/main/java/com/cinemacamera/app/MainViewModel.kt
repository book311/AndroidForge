package com.cinemacamera.app

import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.os.BatteryManager
import android.os.PowerManager
import android.os.StatFs
import android.provider.MediaStore
import android.util.Log
import android.view.Surface
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.cinemacamera.camera.NativePipeline
import com.cinemacamera.domain.CameraEngine
import com.cinemacamera.domain.CaptureSettings
import com.cinemacamera.domain.EnginePhase
import com.cinemacamera.domain.GimbalLink
import com.cinemacamera.domain.MotionCapture
import com.cinemacamera.domain.OutputMode
import com.cinemacamera.domain.Preset
import com.cinemacamera.domain.ProbeReport
import com.cinemacamera.domain.RecordingResult
import com.cinemacamera.domain.RecordingTarget
import com.cinemacamera.domain.ScopeConfig
import com.cinemacamera.domain.Sequence
import com.cinemacamera.domain.SequenceTransport
import com.cinemacamera.domain.SlateInfo
import com.cinemacamera.domain.Timecode
import com.cinemacamera.domain.TimecodeSource
import com.cinemacamera.domain.WaveformData
import com.cinemacamera.remote.RemoteController
import com.cinemacamera.remote.RemoteJson
import com.cinemacamera.remote.RemoteServer
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.android.qualifiers.ApplicationContext
import java.io.File
import java.text.SimpleDateFormat
import java.time.Instant
import java.util.Date
import java.util.Locale
import javax.inject.Inject
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import org.json.JSONArray
import org.json.JSONObject

/**
 * Ramp/builder params from [com.cinemacamera.app.ui.ProMovesPanel], hoisted here so
 * they survive the panel being closed and reopened (was lost `remember` state).
 */
class ProMovesUiState {
    var pullDurationS by mutableFloatStateOf(3.5f)

    var zoomFrom by mutableFloatStateOf(1.0f)
    var zoomTo by mutableFloatStateOf(2.0f)
    var zoomDurationS by mutableFloatStateOf(3.5f)

    var targetIso by mutableFloatStateOf(100f)
    var targetAngle by mutableFloatStateOf(180f)
    var rampDurationS by mutableFloatStateOf(3.5f)

    var seqName by mutableStateOf("")
    var seqDurationS by mutableFloatStateOf(5f)
    var selectedBuildTrack by mutableIntStateOf(0)
    var seqFocusA by mutableStateOf<Float?>(null)
    var seqFocusB by mutableStateOf<Float?>(null)
    var isoA by mutableStateOf<Int?>(null)
    var isoB by mutableStateOf<Int?>(null)
    var shutterA by mutableStateOf<Long?>(null)
    var shutterB by mutableStateOf<Long?>(null)
    var zoomA by mutableStateOf<Float?>(null)
    var zoomB by mutableStateOf<Float?>(null)
}

/** Battery/thermal/storage snapshot for the status HUD, refreshed every 5s. */
data class DeviceHealth(
    val batteryPct: Int = -1,
    val thermalStatus: String = "OK",
    val freeStorageGb: Float = -1f,
)

@HiltViewModel
class MainViewModel @Inject constructor(
    val engine: CameraEngine,
    val motion: MotionCapture,
    val gimbal: GimbalLink,
    private val presetsRepo: PresetsRepository,
    private val lutRepo: LutRepository,
    private val sequencesRepo: SequencesRepository,
    private val settingsStore: SettingsStore,
    private val timecodeSource: TimecodeSource,
    private val remoteServer: RemoteServer,
    @ApplicationContext private val context: Context,
) : ViewModel(), RemoteController {

    val probeReport = MutableStateFlow<ProbeReport?>(null)
    val uiMessage = MutableStateFlow<String?>(null)

    val isRecording: StateFlow<Boolean> = engine.state
        .map { it.phase == EnginePhase.RECORDING }
        .stateIn(viewModelScope, SharingStarted.Eagerly, false)

    // --- Pro state -------------------------------------------------------
    val scopeConfig = MutableStateFlow(ScopeConfig())
    val waveform = MutableStateFlow<WaveformData?>(null)
    val presets = MutableStateFlow<List<Preset>>(emptyList())
    val lutNames = MutableStateFlow<List<String>>(emptyList())
    val sequences = MutableStateFlow<List<Sequence>>(emptyList())

    /** A/B focus marks for programmable pulls (diopters). */
    val focusA = MutableStateFlow<Float?>(null)
    val focusB = MutableStateFlow<Float?>(null)

    /** Hoisted MOVE panel state: survives the panel closing/reopening. */
    val proMoves = ProMovesUiState()

    /** Battery/thermal/storage HUD snapshot, polled every 5s. */
    val deviceHealth = MutableStateFlow(DeviceHealth())

    /** Timecode captured at the start of the current/last take, null when never recorded. */
    val recordingStartTimecode = MutableStateFlow<Timecode?>(null)

    /** Roll/Scene/Take slate, restored from [settingsStore] on startup and persisted on every edit. */
    val slateInfo = MutableStateFlow(settingsStore.loadSlate() ?: SlateInfo())

    // --- V10a: Laptop Director remote control -----------------------------

    /** `http://<lan-ip>:8080`, best-effort; shown in the in-app REMOTE panel. */
    val remoteUrl: String get() = remoteServer.localUrl()

    /** Current pairing PIN; a StateFlow so the panel recomposes on [regenerateRemotePin]. */
    val remotePin = MutableStateFlow(remoteServer.pin)

    fun regenerateRemotePin() {
        remotePin.value = remoteServer.regeneratePin()
    }

    private var permissionsGranted = false
    private var streamStarted = false
    private var waveformJob: Job? = null

    /** Context captured at record-start, consumed at record-stop to write the JSON sidecar. */
    private data class ActiveTake(
        val slate: SlateInfo,
        val outputMode: OutputMode,
        /** The .mp4 file (VIDEO) or the take's own folder (CINEMA_DNG). */
        val videoFile: File,
        val gcsvFile: File,
        val jsonFile: File,
        val createdAt: String,
        val timecodeStart: String,
        val fps: Int,
        val width: Int,
        val height: Int,
        val logProfile: String,
        val focalLengthMm: Float,
        val sensorWidthMm: Float,
        val sensorHeightMm: Float,
        val focusDiopters: Float,
        val exposure: com.cinemacamera.domain.ExposureSettings,
    )

    private var activeTake: ActiveTake? = null

    init {
        viewModelScope.launch {
            gimbal.recordTrigger.collect { toggleRecording() }
        }
        presets.value = presetsRepo.list()
        lutNames.value = lutRepo.list()
        sequences.value = sequencesRepo.list()
        viewModelScope.launch {
            engine.settings.map { it.previewLutName }.distinctUntilChanged().collect { applyLut(it) }
        }
        viewModelScope.launch {
            while (true) {
                deviceHealth.value = readDeviceHealth()
                delay(5_000)
            }
        }
    }

    private fun clipsDir(): File = File(context.getExternalFilesDir(null), "clips")

    private fun readDeviceHealth(): DeviceHealth {
        val batteryPct = runCatching {
            val bm = context.getSystemService(Context.BATTERY_SERVICE) as? BatteryManager
            bm?.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY) ?: -1
        }.getOrDefault(-1)

        val thermalStatus = runCatching {
            val pm = context.getSystemService(Context.POWER_SERVICE) as? PowerManager
            when (pm?.currentThermalStatus) {
                PowerManager.THERMAL_STATUS_NONE,
                PowerManager.THERMAL_STATUS_LIGHT -> "OK"
                PowerManager.THERMAL_STATUS_MODERATE -> "WARM"
                PowerManager.THERMAL_STATUS_SEVERE -> "HOT"
                PowerManager.THERMAL_STATUS_CRITICAL,
                PowerManager.THERMAL_STATUS_EMERGENCY,
                PowerManager.THERMAL_STATUS_SHUTDOWN -> "CRIT"
                else -> "OK"
            }
        }.getOrDefault("OK")

        val freeStorageGb = runCatching {
            val dir = clipsDir().apply { mkdirs() }
            StatFs(dir.absolutePath).availableBytes / (1024f * 1024f * 1024f)
        }.getOrDefault(-1f)

        return DeviceHealth(batteryPct, thermalStatus, freeStorageGb)
    }

    /** Once-only: kicks off HW probing, gimbal link, and the RAW stream. */
    fun onPermissionsGranted(micGranted: Boolean = true) {
        if (permissionsGranted) return
        permissionsGranted = true
        viewModelScope.launch {
            probeReport.value = engine.initialize()
            // Restore persisted CaptureSettings (if any) over engine.initialize()'s
            // freshly-probed defaults, before the stream starts.
            val saved = withContext(Dispatchers.IO) { settingsStore.load() }
            if (saved != null) {
                engine.applySettings(saved)
            }
            if (!micGranted) {
                // Fall back to video-only; the native side never even sees a
                // request to open the mic.
                applyAndPersist(engine.settings.value.copy(audioEnabled = false))
                uiMessage.value = "Microphone permission denied — recording video only"
            }
            gimbal.start()
            if (!streamStarted) {
                streamStarted = true
                // The stream no longer needs a HAL preview surface; the GL
                // viewfinder attaches/detaches independently.
                engine.startStream(null)
                remoteServer.start(this@MainViewModel)
            }
        }
    }

    fun onPreviewSurfaceAvailable(surface: Surface) = engine.setPreviewSurface(surface)

    fun onPreviewSurfaceDestroyed() = engine.setPreviewSurface(null)

    // --- Settings --------------------------------------------------------

    fun updateSettings(transform: (CaptureSettings) -> CaptureSettings) {
        viewModelScope.launch { applyAndPersist(transform(engine.settings.value)) }
    }

    /** Single funnel: pushes [new] to the engine, then persists the settings that
     * actually landed (the engine may clamp/adjust, e.g. invalid raw sizes). */
    private suspend fun applyAndPersist(new: CaptureSettings) {
        engine.applySettings(new)
        withContext(Dispatchers.IO) { settingsStore.save(engine.settings.value) }
    }

    /** Edits Roll/Scene/Take and persists immediately (mirrors [applyAndPersist]). */
    fun updateSlate(transform: (SlateInfo) -> SlateInfo) {
        val next = transform(slateInfo.value)
        slateInfo.value = next
        settingsStore.saveSlate(next)
    }

    fun updateScopes(transform: (ScopeConfig) -> ScopeConfig) {
        val next = transform(scopeConfig.value)
        scopeConfig.value = next
        engine.setScopeConfig(next)
        if (next.waveform) startWaveformPolling() else stopWaveformPolling()
    }

    private fun startWaveformPolling() {
        if (waveformJob?.isActive == true) return
        waveformJob = viewModelScope.launch {
            while (true) {
                engine.getWaveform()?.let { waveform.value = it }
                delay(100)
            }
        }
    }

    private fun stopWaveformPolling() {
        waveformJob?.cancel()
        waveformJob = null
        waveform.value = null
    }

    // --- Presets ---------------------------------------------------------

    override fun savePreset(name: String) {
        if (name.isBlank()) return
        presetsRepo.save(Preset(name.trim(), engine.settings.value))
        presets.value = presetsRepo.list()
        uiMessage.value = "Preset \"${name.trim()}\" saved"
    }

    fun applyPreset(preset: Preset) {
        viewModelScope.launch {
            applyAndPersist(preset.settings)
            uiMessage.value = "Preset \"${preset.name}\" applied"
        }
    }

    override fun deletePreset(name: String) {
        presetsRepo.delete(name)
        presets.value = presetsRepo.list()
    }

    // --- V4: LUT preview ---------------------------------------------------

    fun selectLut(name: String?) {
        updateSettings { it.copy(previewLutName = name) }
    }

    fun importLut(uri: Uri, displayName: String) {
        viewModelScope.launch(Dispatchers.IO) {
            val result = runCatching { lutRepo.importFrom(uri, displayName) }
            withContext(Dispatchers.Main) {
                result.onSuccess { name ->
                    lutNames.value = lutRepo.list()
                    uiMessage.value = "Imported LUT \"$name\""
                }.onFailure { e ->
                    uiMessage.value = "LUT import failed: ${e.message}"
                }
            }
        }
    }

    private fun applyLut(name: String?) {
        viewModelScope.launch(Dispatchers.Default) {
            if (name == null) {
                NativePipeline.clearLut()
                return@launch
            }
            val lut = runCatching { lutRepo.load(name) }.getOrNull()
            if (lut == null) {
                withContext(Dispatchers.Main) { uiMessage.value = "Failed to load LUT \"$name\"" }
                NativePipeline.clearLut()
                return@launch
            }
            NativePipeline.setLut(lut.data, lut.size)
        }
    }

    // --- V3: focus pulls & ramps ------------------------------------------

    fun markFocusA() { focusA.value = currentFocusOrZero() }
    fun markFocusB() { focusB.value = currentFocusOrZero() }

    private fun currentFocusOrZero(): Float {
        val f = engine.settings.value.focusDiopters
        return if (f >= 0f) f else 0f
    }

    fun runFocusPull(durationMs: Long) {
        val a = focusA.value ?: return
        val b = focusB.value ?: return
        engine.startFocusPull(a, b, durationMs)
        uiMessage.value = "Focus pull ${"%.2f".format(a)} → ${"%.2f".format(b)} over ${durationMs / 1000f}s"
    }

    fun runExposureRamp(toIso: Int, toShutterNs: Long, durationMs: Long) =
        engine.startExposureRamp(toIso, toShutterNs, durationMs)

    fun runZoomRamp(from: Float, to: Float, durationMs: Long) =
        engine.startZoomRamp(from, to, durationMs)

    fun cancelRamps() = engine.cancelRamps()

    // --- Step 2: multi-track sequences ------------------------------------

    val activeSequence: StateFlow<Sequence?> = engine.activeSequence
    val sequenceTransport: StateFlow<SequenceTransport> = engine.sequenceTransport
    val sequencePositionMs: StateFlow<Long> = engine.sequencePositionMs
    val sequenceArmed: StateFlow<Boolean> = engine.sequenceArmed

    /** Current focus/iso/shutter/zoom, for "add keyframe at current values" builders. */
    data class KeyframeSnapshot(val focusDiopters: Float, val iso: Int, val shutterNs: Long, val zoomRatio: Float)

    fun captureKeyframeSnapshot(): KeyframeSnapshot {
        val s = engine.settings.value
        return KeyframeSnapshot(
            focusDiopters = if (s.focusDiopters >= 0f) s.focusDiopters else 0f,
            iso = s.exposure.iso,
            shutterNs = s.exposure.effectiveShutterNs(s.fps),
            zoomRatio = engine.currentZoomRatio(),
        )
    }

    fun saveSequence(seq: Sequence) {
        if (seq.name.isBlank()) return
        sequencesRepo.save(seq)
        sequences.value = sequencesRepo.list()
        uiMessage.value = "Sequence \"${seq.name}\" saved"
    }

    fun deleteSequence(name: String) {
        sequencesRepo.delete(name)
        sequences.value = sequencesRepo.list()
    }

    fun loadSequence(seq: Sequence?) = engine.loadSequence(seq)

    override fun playSequence() = engine.playSequence()

    override fun stopSequence() = engine.stopSequence()

    override fun armSequence(armed: Boolean) = engine.armSequence(armed)

    // --- Recording ---------------------------------------------------------

    /** Timecode of the running take, recomputed on demand for the HUD (time-of-day advances live). */
    fun currentTimecode(): Timecode = timecodeSource.currentTimecode(engine.settings.value.fps)

    fun toggleRecording() {
        if (isRecording.value) {
            viewModelScope.launch {
                val active = activeTake
                if (active?.outputMode == OutputMode.CINEMA_DNG) {
                    val frames = engine.stopDngRecording()
                    val imuSamples = motion.stopSession()
                    val warn = if (imuSamples == 0L && frames > 0) " — WARNING: no IMU sync data" else ""
                    val tc = recordingStartTimecode.value?.let { " · TC $it" } ?: ""
                    uiMessage.value = "${active.videoFile.name}: $frames DNG frames, $imuSamples IMU samples$warn$tc"
                    withContext(Dispatchers.IO) { writeDngSidecar(active, frames, imuSamples) }
                    updateSlate { it.copy(take = it.take + 1) }
                    activeTake = null
                } else {
                    val res = engine.stopRecording()
                    val imuSamples = motion.stopSession()
                    if (res == null) {
                        uiMessage.value = "Stop failed: not recording"
                        return@launch
                    }
                    val take = res.videoFile.nameWithoutExtension
                    val warn = if (imuSamples == 0L && res.frameCount > 0) " — WARNING: no IMU sync data" else ""
                    val tc = recordingStartTimecode.value?.let { " · TC $it" } ?: ""
                    uiMessage.value = "$take: ${res.frameCount} frames, $imuSamples IMU samples$warn$tc"

                    // Write the slate sidecar and auto-increment the take number, but
                    // only for a take we actually started ourselves (defensive: engine
                    // could in theory report a stop we didn't initiate).
                    active?.let { a ->
                        withContext(Dispatchers.IO) { writeSlateSidecar(a, res, imuSamples) }
                        updateSlate { it.copy(take = it.take + 1) }
                    }
                    activeTake = null
                }
            }
        } else {
            viewModelScope.launch {
                val clipsDir = clipsDir()
                clipsDir.mkdirs()
                val slate = slateInfo.value
                val settingsNow = engine.settings.value
                val stateNow = engine.state.value
                val startTc = timecodeSource.currentTimecode(settingsNow.fps)
                recordingStartTimecode.value = startTc
                val sensorNow = engine.sensors.value.find { it.id == settingsNow.sensorId }
                    ?: engine.sensors.value.firstOrNull()

                if (settingsNow.outputMode == OutputMode.CINEMA_DNG) {
                    var stem = slate.fileStem()
                    if (File(clipsDir, stem).exists()) {
                        // Defensive: don't clobber an existing take with the same slate.
                        val timestamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
                        stem = "${stem}_$timestamp"
                    }
                    val dngDir = File(clipsDir, stem)
                    dngDir.mkdirs()
                    val gcsvFile = File(dngDir, "$stem.gcsv")
                    val jsonFile = File(dngDir, "$stem.json")

                    activeTake = ActiveTake(
                        slate = slate,
                        outputMode = OutputMode.CINEMA_DNG,
                        videoFile = dngDir,
                        gcsvFile = gcsvFile,
                        jsonFile = jsonFile,
                        createdAt = Instant.now().toString(),
                        timecodeStart = startTc.toString(),
                        fps = settingsNow.fps,
                        width = stateNow.rawWidth,
                        height = stateNow.rawHeight,
                        logProfile = settingsNow.logProfile.name,
                        focalLengthMm = sensorNow?.focalLengthMm ?: 0f,
                        sensorWidthMm = sensorNow?.sensorWidthMm ?: 0f,
                        sensorHeightMm = sensorNow?.sensorHeightMm ?: 0f,
                        focusDiopters = settingsNow.focusDiopters,
                        exposure = settingsNow.exposure,
                    )

                    motion.startSession(gcsvFile)
                    motion.setTimecodeStart(startTc.toString())
                    val ok = engine.startDngRecording(dngDir, stem)
                    if (!ok) {
                        uiMessage.value = "DNG recording start failed"
                        activeTake = null
                        return@launch
                    }
                } else {
                    var stem = slate.fileStem()
                    if (File(clipsDir, "$stem.mp4").exists() || File(clipsDir, "$stem.gcsv").exists()) {
                        // Defensive: don't clobber an existing take with the same slate.
                        val timestamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
                        stem = "${stem}_$timestamp"
                    }
                    val videoFile = File(clipsDir, "$stem.mp4")
                    val gcsvFile = File(clipsDir, "$stem.gcsv")
                    val jsonFile = File(clipsDir, "$stem.json")

                    activeTake = ActiveTake(
                        slate = slate,
                        outputMode = OutputMode.VIDEO,
                        videoFile = videoFile,
                        gcsvFile = gcsvFile,
                        jsonFile = jsonFile,
                        createdAt = Instant.now().toString(),
                        timecodeStart = startTc.toString(),
                        fps = settingsNow.fps,
                        width = stateNow.rawWidth,
                        height = stateNow.rawHeight,
                        logProfile = settingsNow.logProfile.name,
                        focalLengthMm = sensorNow?.focalLengthMm ?: 0f,
                        sensorWidthMm = sensorNow?.sensorWidthMm ?: 0f,
                        sensorHeightMm = sensorNow?.sensorHeightMm ?: 0f,
                        focusDiopters = settingsNow.focusDiopters,
                        exposure = settingsNow.exposure,
                    )

                    motion.startSession(gcsvFile)
                    motion.setTimecodeStart(startTc.toString())
                    engine.startRecording(RecordingTarget(videoFile, gcsvFile))
                }

                launch {
                    var waitedMs = 0L
                    while (waitedMs < 3_000L) {
                        val ts = engine.firstRecordedFrameTimestampNs()
                        if (ts != 0L) {
                            motion.setFrameAnchor(ts)
                            break
                        }
                        delay(50)
                        waitedMs += 50
                    }
                }
            }
        }
    }

    /** Writes `<stem>.json` next to the clip: slate + basic clip info captured at record-stop. */
    private fun writeSlateSidecar(active: ActiveTake, res: RecordingResult, imuSamples: Long) {
        runCatching {
            val json = JSONObject().apply {
                put("roll", active.slate.roll)
                put("scene", active.slate.scene)
                put("take", active.slate.take)
                put("fileName", active.videoFile.name)
                put("outputMode", active.outputMode.name)
                put("timecodeStart", active.timecodeStart)
                put("createdAt", active.createdAt)
                put("fps", active.fps)
                put("resolution", "${active.width}x${active.height}")
                put("logProfile", active.logProfile)
                put("durationMs", res.durationMs)
                put("frameCount", res.frameCount)
                put("imuSampleCount", imuSamples)
                put("camera", buildCameraJson(active))
            }
            active.jsonFile.writeText(json.toString(2))
        }.onFailure { e ->
            Log.w("MainViewModel", "Failed to write slate sidecar for ${active.videoFile.name}", e)
        }
    }

    /** Writes `<stem>.json` into the take's DNG folder: same slate metadata, frames instead of frameCount. */
    private fun writeDngSidecar(active: ActiveTake, framesWritten: Long, imuSamples: Long) {
        runCatching {
            val json = JSONObject().apply {
                put("roll", active.slate.roll)
                put("scene", active.slate.scene)
                put("take", active.slate.take)
                put("fileName", active.videoFile.name)
                put("outputMode", OutputMode.CINEMA_DNG.name)
                put("timecodeStart", active.timecodeStart)
                put("createdAt", active.createdAt)
                put("fps", active.fps)
                put("resolution", "${active.width}x${active.height}")
                put("logProfile", active.logProfile)
                put("frames", framesWritten)
                put("imuSampleCount", imuSamples)
                put("camera", buildCameraJson(active))
            }
            active.jsonFile.writeText(json.toString(2))
        }.onFailure { e ->
            Log.w("MainViewModel", "Failed to write DNG sidecar for ${active.videoFile.name}", e)
        }
    }

    /**
     * OpenMotionFX `.omfx` camera.json-compatible metadata block, nested into the
     * per-take sidecar so a take can later be matched up with a move file. Field
     * names match OpenMotionFX's camera.json exactly (see docs/MOTION_CONTROL.md).
     */
    private fun buildCameraJson(active: ActiveTake): JSONObject = JSONObject().apply {
        put("focalLengthMm", active.focalLengthMm)
        put(
            "sensorSizeMm",
            org.json.JSONArray().put(active.sensorWidthMm).put(active.sensorHeightMm)
        )
        val diopters = active.focusDiopters
        put("focusDistanceM", if (diopters > 0f) (1.0 / diopters) else JSONObject.NULL)
        put("iso", active.exposure.iso)
        put("shutterS", active.exposure.effectiveShutterNs(active.fps) / 1_000_000_000.0)
        put("principalPoint", JSONObject.NULL)
    }

    // --- Media browser (CLIPS panel) ----------------------------------------

    /** Directory recorded clips (mp4 + gcsv) land in. Exposed for the CLIPS panel. */
    fun clipsDirectory(): File = clipsDir()

    /**
     * Stream-copies a clip into the public gallery (Movies/CinemaCamera) via a
     * proper MediaStore insert (IS_PENDING handshake). The original stays put.
     * Returns true on success; also surfaces the result via [uiMessage].
     */
    suspend fun exportClipToGallery(videoFile: File): Boolean = withContext(Dispatchers.IO) {
        val resolver = context.contentResolver
        val result = runCatching {
            val values = ContentValues().apply {
                put(MediaStore.Video.Media.DISPLAY_NAME, videoFile.name)
                put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
                put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/CinemaCamera")
                put(MediaStore.Video.Media.IS_PENDING, 1)
            }
            val uri = resolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values)
                ?: error("MediaStore insert returned null")
            try {
                resolver.openOutputStream(uri)?.use { out ->
                    videoFile.inputStream().use { it.copyTo(out) }
                } ?: error("openOutputStream returned null")
                resolver.update(uri, ContentValues().apply { put(MediaStore.Video.Media.IS_PENDING, 0) }, null, null)
            } catch (e: Exception) {
                resolver.delete(uri, null, null) // don't leave a pending ghost entry
                throw e
            }
        }
        withContext(Dispatchers.Main) {
            result.onSuccess {
                uiMessage.value = "Exported ${videoFile.name} to Movies/CinemaCamera"
            }.onFailure { e ->
                Log.w("MainViewModel", "Export failed for ${videoFile.name}", e)
                uiMessage.value = "Export failed: ${e.message}"
            }
        }
        result.isSuccess
    }

    /** Deletes a take's mp4 + gcsv + json sidecar (if present) and refreshes the clips listing. */
    fun deleteClip(videoFile: File) {
        videoFile.delete()
        File(videoFile.parentFile, videoFile.nameWithoutExtension + ".gcsv").delete()
        File(videoFile.parentFile, videoFile.nameWithoutExtension + ".json").delete()
        uiMessage.value = "Deleted ${videoFile.nameWithoutExtension}"
    }

    /** Deletes a CinemaDNG take's whole folder (all .dng frames + gcsv + json sidecar). */
    fun deleteDngClip(dir: File) {
        dir.deleteRecursively()
        uiMessage.value = "Deleted ${dir.name}"
    }

    /** Delegates hardware key events to the gimbal link's HID record trigger. */
    fun onKeyEvent(keyCode: Int, isDown: Boolean): Boolean = gimbal.onKeyEvent(keyCode, isDown)

    override fun onCleared() {
        engine.close()
        gimbal.stop()
        remoteServer.stop()
    }

    // --- RemoteController (V10a: Laptop Director) ---------------------------

    override fun statusJson(): JSONObject {
        val stats = engine.stats.value
        val health = deviceHealth.value
        val slate = slateInfo.value
        return JSONObject().apply {
            put("phase", engine.state.value.phase.name)
            put("recording", isRecording.value)
            put("fps", stats.fps.toDouble())
            put("framesDropped", stats.framesDropped)
            put("framesEncoded", stats.framesEncoded)
            put("battery", health.batteryPct)
            put("thermal", health.thermalStatus)
            put("freeGb", health.freeStorageGb.toDouble())
            put("timecode", currentTimecode().toString())
            put("roll", slate.roll)
            put("scene", slate.scene)
            put("take", slate.take)
            put("transport", sequenceTransport.value.name)
            put("sequencePositionMs", sequencePositionMs.value)
            put("activeSequence", activeSequence.value?.name ?: JSONObject.NULL)
            put("armed", sequenceArmed.value)
        }
    }

    override fun settingsJson(): JSONObject = RemoteJson.settingsToJson(engine.settings.value)

    override suspend fun applySettingsPatch(patch: JSONObject) {
        // Apply directly (not the fire-and-forget updateSettings) so this suspends
        // until engine.settings reflects the patch — the route's settingsJson echo is then truthful.
        applyAndPersist(RemoteJson.applySettingsPatch(engine.settings.value, patch))
    }

    override suspend fun setRecording(on: Boolean) {
        if (isRecording.value == on) return
        toggleRecording()
        // Wait for the async start/stop to actually flip the recording flag so the echo is correct.
        withTimeoutOrNull(4_000) { isRecording.first { it == on } }
    }

    override fun slateJson(): JSONObject = RemoteJson.slateToJson(slateInfo.value)

    override fun updateSlatePatch(patch: JSONObject) {
        updateSlate { RemoteJson.applySlatePatch(it, patch) }
    }

    override fun presetsJson(): JSONObject = JSONObject().apply {
        put("presets", JSONArray().apply {
            presets.value.forEach { put(RemoteJson.presetToJson(it)) }
        })
    }

    override suspend fun applyPreset(name: String) {
        val preset = presets.value.find { it.name == name } ?: return
        applyAndPersist(preset.settings)
        uiMessage.value = "Preset \"${preset.name}\" applied"
    }

    override fun sequencesJson(): JSONObject = JSONObject().apply {
        put("sequences", JSONArray().apply {
            sequences.value.forEach { put(RemoteJson.sequenceToJson(it)) }
        })
    }

    override fun loadSequence(name: String?) {
        val seq = name?.let { n -> sequences.value.find { it.name == n } }
        loadSequence(seq)
    }

    override fun clipsJson(): JSONObject {
        val dir = clipsDir()
        val videoFiles = dir.listFiles { f -> f.isFile && f.extension == "mp4" }?.toList() ?: emptyList()
        val dngDirs = dir.listFiles { f -> f.isDirectory && f.listFiles { c -> c.extension.equals("dng", true) }?.isNotEmpty() == true }
            ?.toList() ?: emptyList()

        val videoEntries = videoFiles.map { f ->
            val gcsv = File(dir, f.nameWithoutExtension + ".gcsv")
            val sidecar = File(dir, f.nameWithoutExtension + ".json")
            f.lastModified() to JSONObject().apply {
                put("name", f.name)
                put("type", "video")
                put("sizeBytes", f.length())
                put("hasGcsv", gcsv.exists())
                put(
                    "sidecar",
                    if (sidecar.exists()) {
                        runCatching { JSONObject(sidecar.readText()) }.getOrNull() ?: JSONObject.NULL
                    } else {
                        JSONObject.NULL
                    }
                )
            }
        }
        val dngEntries = dngDirs.map { d ->
            val frameCount = d.listFiles { f -> f.extension.equals("dng", true) }?.size ?: 0
            val sizeBytes = d.listFiles()?.sumOf { it.length() } ?: 0L
            val gcsv = File(d, d.name + ".gcsv")
            val sidecar = File(d, d.name + ".json")
            d.lastModified() to JSONObject().apply {
                put("name", d.name)
                put("type", "dng")
                put("frameCount", frameCount)
                put("sizeBytes", sizeBytes)
                put("hasGcsv", gcsv.exists())
                put(
                    "sidecar",
                    if (sidecar.exists()) {
                        runCatching { JSONObject(sidecar.readText()) }.getOrNull() ?: JSONObject.NULL
                    } else {
                        JSONObject.NULL
                    }
                )
            }
        }
        val sorted = (videoEntries + dngEntries).sortedByDescending { it.first }.map { it.second }
        return JSONObject().apply {
            put("clips", JSONArray().apply { sorted.forEach { put(it) } })
        }
    }

    override fun resolveClip(name: String): File? {
        if (name.isBlank() || name.contains('/') || name.contains('\\') || name.contains("..")) return null
        if (!name.endsWith(".mp4")) return null
        val dir = clipsDir()
        val file = File(dir, name)
        if (file.parentFile?.canonicalFile != dir.canonicalFile) return null
        return if (file.exists()) file else null
    }
}
