package com.cinemacamera.app

import android.content.Context
import com.cinemacamera.domain.CaptureSettings
import com.cinemacamera.domain.ExposureSettings
import com.cinemacamera.domain.LogProfile
import com.cinemacamera.domain.OutputMode
import com.cinemacamera.domain.ProcessingToggles
import com.cinemacamera.domain.SlateInfo
import com.cinemacamera.domain.VideoCodec
import dagger.hilt.android.qualifiers.ApplicationContext
import java.io.File
import javax.inject.Inject
import javax.inject.Singleton
import org.json.JSONObject

/**
 * Persists [CaptureSettings] across app restarts as a single JSON file — same
 * hand-rolled org.json style as [SequencesRepository]/[LutRepository], so
 * dependencies don't change. Only user-facing capture settings are stored;
 * transient/runtime state (ramp overrides, sequence transport, record state)
 * never round-trips here.
 */
@Singleton
class SettingsStore @Inject constructor(
    @ApplicationContext context: Context,
) {
    private val file = File(context.filesDir, "settings.json")

    /** Both [CaptureSettings] and [SlateInfo] share this one file; each save
     * merges its own keys on top of whatever is already there so neither
     * overwrites the other's fields. */
    private fun readRawJson(): JSONObject =
        if (file.exists()) runCatching { JSONObject(file.readText()) }.getOrDefault(JSONObject()) else JSONObject()

    fun save(settings: CaptureSettings) {
        val merged = readRawJson()
        val s = write(settings)
        s.keys().forEach { key -> merged.put(key, s.get(key)) }
        file.writeText(merged.toString(2))
    }

    /** Returns null if no settings were ever saved, or the file fails to parse. */
    fun load(): CaptureSettings? {
        if (!file.exists()) return null
        return runCatching { read(JSONObject(file.readText())) }.getOrNull()
    }

    fun saveSlate(slate: SlateInfo) {
        val merged = readRawJson()
        merged.put("slateRoll", slate.roll)
        merged.put("slateScene", slate.scene)
        merged.put("slateTake", slate.take)
        file.writeText(merged.toString(2))
    }

    /** Returns null if no slate was ever saved, or the file fails to parse. */
    fun loadSlate(): SlateInfo? {
        if (!file.exists()) return null
        val defaults = SlateInfo()
        return runCatching {
            val o = JSONObject(file.readText())
            SlateInfo(
                roll = o.optString("slateRoll", defaults.roll).ifBlank { defaults.roll },
                scene = o.optString("slateScene", defaults.scene).ifBlank { defaults.scene },
                take = o.optInt("slateTake", defaults.take),
            )
        }.getOrNull()
    }

    private fun write(s: CaptureSettings): JSONObject = JSONObject().apply {
        put("sensorId", s.sensorId ?: JSONObject.NULL)
        put("rawWidth", s.rawWidth)
        put("rawHeight", s.rawHeight)
        put("fps", s.fps)
        put("guideAspect", s.guideAspect.toDouble())
        put("exposure", JSONObject().apply {
            put("auto", s.exposure.auto)
            put("iso", s.exposure.iso)
            put("shutterNs", s.exposure.shutterNs)
            put("shutterAngle", s.exposure.shutterAngle.toDouble())
        })
        put("focusDiopters", s.focusDiopters.toDouble())
        put("processing", JSONObject().apply {
            put("noiseReduction", s.processing.noiseReduction)
            put("edgeEnhancement", s.processing.edgeEnhancement)
            put("lensShading", s.processing.lensShading)
            put("hotPixel", s.processing.hotPixel)
            put("aberrationCorrection", s.processing.aberrationCorrection)
            put("distortionCorrection", s.processing.distortionCorrection)
            put("forceIdentityTonemap", s.processing.forceIdentityTonemap)
            put("videoStabilization", s.processing.videoStabilization)
        })
        put("logProfile", s.logProfile.name)
        put("encodeFullRes", s.encodeFullRes)
        put("bitrateMbps", s.bitrateMbps)
        put("codec", s.codec.name)
        put("outputMode", s.outputMode.name)
        put("acesIdt", s.acesIdt)
        put("previewLutName", s.previewLutName ?: JSONObject.NULL)
        put("audioEnabled", s.audioEnabled)
    }

    private fun read(o: JSONObject): CaptureSettings {
        val defaults = CaptureSettings()
        val exp = o.optJSONObject("exposure")
        val proc = o.optJSONObject("processing")
        return CaptureSettings(
            sensorId = if (o.isNull("sensorId")) null else o.optString("sensorId").ifBlank { null },
            rawWidth = o.optInt("rawWidth", defaults.rawWidth),
            rawHeight = o.optInt("rawHeight", defaults.rawHeight),
            fps = o.optInt("fps", defaults.fps),
            guideAspect = o.optDouble("guideAspect", defaults.guideAspect.toDouble()).toFloat(),
            exposure = ExposureSettings(
                auto = exp?.optBoolean("auto", defaults.exposure.auto) ?: defaults.exposure.auto,
                iso = exp?.optInt("iso", defaults.exposure.iso) ?: defaults.exposure.iso,
                shutterNs = exp?.optLong("shutterNs", defaults.exposure.shutterNs) ?: defaults.exposure.shutterNs,
                shutterAngle = exp?.optDouble("shutterAngle", defaults.exposure.shutterAngle.toDouble())
                    ?.toFloat() ?: defaults.exposure.shutterAngle,
            ),
            focusDiopters = o.optDouble("focusDiopters", defaults.focusDiopters.toDouble()).toFloat(),
            processing = ProcessingToggles(
                noiseReduction = proc?.optBoolean("noiseReduction", defaults.processing.noiseReduction)
                    ?: defaults.processing.noiseReduction,
                edgeEnhancement = proc?.optBoolean("edgeEnhancement", defaults.processing.edgeEnhancement)
                    ?: defaults.processing.edgeEnhancement,
                lensShading = proc?.optBoolean("lensShading", defaults.processing.lensShading)
                    ?: defaults.processing.lensShading,
                hotPixel = proc?.optBoolean("hotPixel", defaults.processing.hotPixel)
                    ?: defaults.processing.hotPixel,
                aberrationCorrection = proc?.optBoolean("aberrationCorrection", defaults.processing.aberrationCorrection)
                    ?: defaults.processing.aberrationCorrection,
                distortionCorrection = proc?.optBoolean("distortionCorrection", defaults.processing.distortionCorrection)
                    ?: defaults.processing.distortionCorrection,
                forceIdentityTonemap = proc?.optBoolean("forceIdentityTonemap", defaults.processing.forceIdentityTonemap)
                    ?: defaults.processing.forceIdentityTonemap,
                videoStabilization = proc?.optBoolean("videoStabilization", defaults.processing.videoStabilization)
                    ?: defaults.processing.videoStabilization,
            ),
            logProfile = runCatching { LogProfile.valueOf(o.optString("logProfile")) }
                .getOrDefault(defaults.logProfile),
            encodeFullRes = o.optBoolean("encodeFullRes", defaults.encodeFullRes),
            bitrateMbps = o.optInt("bitrateMbps", defaults.bitrateMbps),
            codec = runCatching { VideoCodec.valueOf(o.optString("codec")) }.getOrDefault(defaults.codec),
            outputMode = runCatching { OutputMode.valueOf(o.optString("outputMode")) }
                .getOrDefault(defaults.outputMode),
            acesIdt = o.optBoolean("acesIdt", defaults.acesIdt),
            previewLutName = if (o.isNull("previewLutName")) null else o.optString("previewLutName").ifBlank { null },
            audioEnabled = o.optBoolean("audioEnabled", defaults.audioEnabled),
        )
    }
}
