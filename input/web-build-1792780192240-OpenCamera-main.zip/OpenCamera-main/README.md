# CinemaCamera

An open-source RAW cinema camera app for Android, built for serious filmmaking on a phone.
Reference device: **Vivo X200 Pro** (works on any device exposing RAW_SENSOR via Camera2; a
prober auto-selects the best RAW-capable sensor, including hidden physical camera ids).

## What it does

- **RAW pipeline**: RAW_SENSOR frames debayered on-GPU (GLES3) in C++ — zero vendor processing.
- **Constant frame rate**: manual exposure + frame-duration locking for true CFR (no VFR desync).
- **Flat-log HEVC recording** (up to 4096×3072 open gate) + **Gyroflow `.gcsv`** IMU export.
- **Cinema UI**: clean-screen, false color, waveform, zebras, focus peaking, framing guides, presets.
- **Programmed moves**: focus pulls, exposure ramps, zoom ramps — plus a keyframe timeline (see docs).
- **Laptop remote**: browser-based controller with secure pairing, full API, and a timeline editor
  for programmable focus pulls that play back when you hit record.

See [Roadmap.md](Roadmap.md) and [docs/MASTER_PLAN.md](docs/MASTER_PLAN.md) for the feature roadmap
and current status.

## Building

No wrapper is committed; use Gradle 8.9+, JDK 17, Android SDK 35, NDK 27.2, CMake 3.22.

```
gradle :app:installDebug
```

Launch: `adb shell am start -n com.cinemacamera/com.cinemacamera.app.MainActivity`

Only `arm64-v8a` is built (the native pipeline targets real devices).

## Modules

| Module | Purpose |
|---|---|
| `app` | Compose UI, ViewModel, presets, remote-control server |
| `core-domain` | Pure contracts & models (`CameraEngine`, `CaptureSettings`, …) |
| `core-camera` | Camera2 engine + NDK C++ GL debayer/encoder pipeline |
| `core-motion` | High-rate IMU capture → Gyroflow `.gcsv` |
| `core-gimbal` | Gimbal link (DJI Osmo Mobile as HID remote; pluggable drivers) |

## Modding

The app is deliberately mod-friendly: every subsystem is behind a small interface bound via Hilt,
looks/scopes are single-shader modes, presets are plain JSON, and the remote API is open.
Read [docs/MODDING.md](docs/MODDING.md) for extension points and [docs/ARCHITECTURE.md](docs/ARCHITECTURE.md)
for how it all fits together.

## License

MIT — see [LICENSE](LICENSE).
