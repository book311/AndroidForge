# Contributing

Contributions welcome — bug reports, device compatibility notes, and PRs.

## Ground rules

- Keep `core-domain` framework-light: contracts and data models only.
- New subsystems go behind an interface in `core-domain`, bound with Hilt in their own module.
- The native render thread owns all EGL/GL/encoder state; cross-thread work goes through the
  command queue in `native_pipeline.cpp` — never touch GL from JNI callers directly.
- `pushFrame` is hot-path (30fps RAW): no allocation, no locking beyond the ring buffer.
- Prefer live-applicable settings; only sensor-id/raw-size changes should restart the session.
- Test on a real arm64 device; the pipeline doesn't run on x86 emulators.

## Device compatibility reports

If you run this on a non-Vivo device, please open an issue with the `ProbeReport` output
(sensor ids, RAW sizes, CFA pattern, timestamp source) and whether CFR holds — quirk tables
live in `core-camera` and grow from these reports.

## Style

- Kotlin: idiomatic, coroutines/Flow, no blocking on main.
- C++20, RAII, `LOGI/LOGW/LOGE` macros for logging.
- Commit messages: short imperative subject, body explains the why.
