package com.cinemacamera.domain

import android.view.Surface
import java.io.File
import kotlinx.coroutines.flow.StateFlow

/**
 * Hardware-facing camera pipeline. Implementations own the Camera2 session,
 * the native ring buffer, GPU debayer and video encoder. No UI types leak in
 * besides the preview [Surface], which is optional: the RAW stream runs with
 * or without a preview attached.
 */
interface CameraEngine {
    val state: StateFlow<EngineState>
    val stats: StateFlow<StreamStats>

    /** All RAW-capable sensors found at [initialize], hidden ids included. */
    val sensors: StateFlow<List<SensorInfo>>

    /** The active capture configuration. */
    val settings: StateFlow<CaptureSettings>

    /** Interrogate the camera HAL and pick the best RAW-capable sensor. */
    suspend fun initialize(): ProbeReport

    /** Open the camera and start the continuous RAW_SENSOR stream. */
    suspend fun startStream(previewSurface: Surface?)

    suspend fun stopStream()

    /** Begin debayer + encode of the live RAW stream into [target].videoFile. */
    suspend fun startRecording(target: RecordingTarget)

    /** Stop encoding. Returns null if not recording. */
    suspend fun stopRecording(): RecordingResult?

    /**
     * Begin a CinemaDNG image sequence: one uncompressed DNG per RAW frame
     * written into [dir] as `<stem>_NNNNNN.dng`. Same IMU/timecode-anchor
     * contract as [startRecording] — [firstRecordedFrameTimestampNs] gets set
     * the same way, so the caller drives gcsv/IMU capture identically.
     */
    fun startDngRecording(dir: File, stem: String): Boolean

    /** Stop the DNG sequence, draining any still-queued frames. Returns frames written. */
    suspend fun stopDngRecording(): Long

    /** Sensor timestamp (ns, elapsedRealtime clock) of the first recorded frame; 0 if unknown. */
    fun firstRecordedFrameTimestampNs(): Long

    /**
     * Apply a new configuration. Sensor/size/fps changes restart the stream;
     * exposure, focus, log and processing toggles apply live.
     */
    suspend fun applySettings(new: CaptureSettings)

    /**
     * Attach/detach the viewfinder. The preview is rendered by the engine's
     * own GPU pipeline from the RAW stream (never a HAL YUV stream), so it
     * shows exactly what will be recorded — open gate, log or scope looks.
     */
    fun setPreviewSurface(surface: Surface?)

    /** Live-configure viewfinder scopes: false color, zebras, peaking, waveform. */
    fun setScopeConfig(config: ScopeConfig)

    /** Latest waveform, or null if none computed yet. Poll while displayed. */
    fun getWaveform(): WaveformData?

    /**
     * Peak audio level (0..1) per channel [L, R] since the last poll,
     * updated ~10Hz while recording with audio enabled; [0f, 0f] otherwise.
     */
    val audioLevels: StateFlow<FloatArray>

    /** A→B focus pull over [durationMs] with smooth easing. Diopters. */
    fun startFocusPull(fromDiopters: Float, toDiopters: Float, durationMs: Long)

    /** Stepless exposure ramp to the target ISO/shutter over [durationMs]. */
    fun startExposureRamp(toIso: Int, toShutterNs: Long, durationMs: Long)

    /** Digital dolly-zoom ramp (CONTROL_ZOOM_RATIO) over [durationMs]. */
    fun startZoomRamp(fromRatio: Float, toRatio: Float, durationMs: Long)

    /** Cancel any running focus/exposure/zoom ramp. */
    fun cancelRamps()

    /** Current CONTROL_ZOOM_RATIO override (live ramp/sequence value), 1x if none active. */
    fun currentZoomRatio(): Float

    // --- Step 2: multi-track keyframe automation --------------------------

    /** The sequence currently loaded into the engine, or null. */
    val activeSequence: StateFlow<Sequence?>

    val sequenceTransport: StateFlow<SequenceTransport>

    /** Playback position within [activeSequence], 0 when idle. */
    val sequencePositionMs: StateFlow<Long>

    /** Whether the loaded sequence should auto-play when recording starts. */
    val sequenceArmed: StateFlow<Boolean>

    /** Load (or, with null, unload) the sequence driven by playSequence(). */
    fun loadSequence(seq: Sequence?)

    /** Play [activeSequence] from t=0. Cancels any single ramp in progress. */
    fun playSequence()

    /** Stop sequence playback, leaving current dynamic values in place. */
    fun stopSequence()

    fun armSequence(armed: Boolean)

    fun close()
}
