package com.cinemacamera.domain

import java.io.File
import kotlinx.coroutines.flow.StateFlow

/**
 * IMU capture synchronized to the camera clock. Samples are timestamped with
 * SensorEvent.timestamp (elapsedRealtimeNanos) — the same clock domain as
 * Camera2 SENSOR_TIMESTAMP on devices reporting TIMESTAMP_SOURCE_REALTIME —
 * and exported as Gyroflow .gcsv with t relative to the anchor frame.
 */
interface MotionCapture {
    val sampleCount: StateFlow<Long>

    /** Start listening and buffering samples; gcsv written on [stopSession]. */
    fun startSession(gcsvFile: File)

    /**
     * Anchor t=0 to the sensor timestamp of the first recorded video frame.
     * Must be called once, as soon as the camera engine reports it.
     */
    fun setFrameAnchor(frameTimestampNs: Long)

    /**
     * Record the take's start timecode ("HH:MM:SS:FF") as an optional
     * `tc_start,<value>` header line in the exported .gcsv. Pass null to omit
     * it. Safe to call any time before [stopSession].
     */
    fun setTimecodeStart(timecode: String?)

    /** Flush the .gcsv to disk. Returns the number of IMU samples written. */
    suspend fun stopSession(): Long
}
