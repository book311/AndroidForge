package com.cinemacamera.domain

/** SMPTE-style non-drop timecode, "HH:MM:SS:FF". */
data class Timecode(val hours: Int, val minutes: Int, val seconds: Int, val frames: Int) {
    override fun toString(): String =
        "%02d:%02d:%02d:%02d".format(hours, minutes, seconds, frames)
}

/** Free-run counts from process/session start; time-of-day tracks the wall clock. */
enum class TimecodeMode { FREE_RUN, TIME_OF_DAY }

/**
 * Source of the current timecode, sampled at record start and (optionally)
 * while recording for the HUD. [fps] determines how the sub-second remainder
 * maps to a frame count. Implementations are not required to be
 * frame-accurate to the actual video encode cadence.
 */
interface TimecodeSource {
    fun currentTimecode(fps: Int): Timecode
}
