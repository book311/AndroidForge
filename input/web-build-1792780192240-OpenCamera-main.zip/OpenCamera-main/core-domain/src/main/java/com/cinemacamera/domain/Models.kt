package com.cinemacamera.domain

import java.io.File

enum class EnginePhase { IDLE, INITIALIZING, STREAMING, RECORDING, ERROR }

data class EngineState(
    val phase: EnginePhase = EnginePhase.IDLE,
    val message: String? = null,
    val cameraId: String? = null,
    val rawWidth: Int = 0,
    val rawHeight: Int = 0,
)

/** Live pipeline statistics, published at ~2 Hz by the camera engine. */
data class StreamStats(
    val fps: Float = 0f,
    val framesCaptured: Long = 0,
    val framesDropped: Long = 0,
    val framesEncoded: Long = 0,
    val lastSensorTimestampNs: Long = 0,
)

/**
 * Result of hardware interrogation at engine init. Everything the OEM
 * (BBK/vivo + MediaTek) exposes about the camera stack: logical ids, physical
 * ids backing each logical camera, ids reachable only by direct probe (hidden
 * from getCameraIdList), and vendor tags present on the selected camera.
 */
data class ProbeReport(
    val logicalIds: List<String> = emptyList(),
    val physicalIds: Map<String, List<String>> = emptyMap(),
    val hiddenIds: List<String> = emptyList(),
    val selectedCameraId: String = "",
    val selectedIsPhysical: Boolean = false,
    val hardwareLevel: String = "",
    val capabilities: List<String> = emptyList(),
    val rawSizes: List<String> = emptyList(),
    val fpsRanges: List<String> = emptyList(),
    val timestampSource: String = "",
    val vendorTags: List<String> = emptyList(),
    val notes: List<String> = emptyList(),
)

data class RecordingTarget(val videoFile: File, val gcsvFile: File)

data class RecordingResult(
    val videoFile: File,
    val gcsvFile: File,
    val frameCount: Long,
    val durationMs: Long,
    val imuSampleCount: Long,
)

data class GimbalState(
    val connected: Boolean = false,
    val deviceName: String? = null,
    val transport: String? = null,
)
