package com.cinemacamera.domain

import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow

/**
 * Link to the DJI Osmo Mobile 6. DJI's MSDK v5 targets drones only and has no
 * Osmo Mobile support, so V1 uses the gimbal's Bluetooth remote (HID) mode:
 * the physical record button arrives as hardware key events routed in by the
 * Activity, and connection state is tracked via bonded-device ACL broadcasts.
 */
interface GimbalLink {
    val state: StateFlow<GimbalState>

    /** Emits once per record-button press. */
    val recordTrigger: SharedFlow<Unit>

    fun start()
    fun stop()

    /**
     * Feed hardware key events from the Activity. Returns true if the event
     * was consumed as a gimbal record trigger.
     */
    fun onKeyEvent(keyCode: Int, isDown: Boolean): Boolean
}
