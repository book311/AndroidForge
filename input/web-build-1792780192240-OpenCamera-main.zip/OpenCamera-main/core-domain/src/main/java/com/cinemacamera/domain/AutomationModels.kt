package com.cinemacamera.domain

/** Track kinds drivable by a [Sequence]; extend here as new axes are automated. */
enum class AutoTrackKind { FOCUS, ISO, SHUTTER_NS, ZOOM }

/** Shapes the segment arriving AT a keyframe, coming from the previous one. */
enum class Easing { LINEAR, SMOOTH, EASE_IN, EASE_OUT, HOLD }

/**
 * A single automation point. [value] is in the track's native unit: FOCUS =
 * diopters, ISO = ISO units, SHUTTER_NS = nanoseconds, ZOOM = ratio.
 */
data class Keyframe(
    val timeMs: Long,
    val value: Double,
    val easing: Easing = Easing.SMOOTH,
)

/** One automated parameter track; [keyframes] must be sorted by [Keyframe.timeMs]. */
data class AutoTrack(
    val kind: AutoTrackKind,
    val keyframes: List<Keyframe>,
) {
    init {
        require(keyframes == keyframes.sortedBy { it.timeMs }) { "keyframes must be sorted by timeMs" }
    }
}

/**
 * A saved multi-track automation, schema-versioned since it's edited by an
 * external (browser) timeline tool as well as this app.
 */
data class Sequence(
    val name: String,
    val durationMs: Long,
    val tracks: List<AutoTrack>,
    val schemaVersion: Int = 1,
)

enum class SequenceTransport { IDLE, RUNNING }
