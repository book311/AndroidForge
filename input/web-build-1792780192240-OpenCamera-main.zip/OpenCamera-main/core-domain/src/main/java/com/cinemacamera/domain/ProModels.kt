package com.cinemacamera.domain

/** One selectable RAW-capable sensor, including BBK-hidden physical ids. */
data class SensorInfo(
    val id: String,
    val hidden: Boolean,
    val facing: String,
    val rawSizes: List<RawSize>,
    val fpsOptions: List<Int>,
    val isoMin: Int,
    val isoMax: Int,
    val exposureMinNs: Long,
    val exposureMaxNs: Long,
    val minFocusDiopters: Float,
    val hasManualSensor: Boolean,
    val cfaPattern: Int,
    val whiteLevel: Int,
    val blackLevel: Int,
    /** LENS_INFO_AVAILABLE_FOCAL_LENGTHS[0], mm. 0f if unavailable. */
    val focalLengthMm: Float = 0f,
    /** SENSOR_INFO_PHYSICAL_SIZE width, mm. 0f if unavailable. */
    val sensorWidthMm: Float = 0f,
    /** SENSOR_INFO_PHYSICAL_SIZE height, mm. 0f if unavailable. */
    val sensorHeightMm: Float = 0f,
) {
    val label: String
        get() = buildString {
            append(facing.lowercase().replaceFirstChar { it.uppercase() })
            append(" $id")
            if (hidden) append(" (hidden)")
            rawSizes.maxByOrNull { it.width.toLong() * it.height }?.let {
                append(" · ${(it.width.toLong() * it.height / 1_000_000)}MP")
            }
        }
}

data class RawSize(val width: Int, val height: Int) {
    override fun toString() = "${width}x$height"
}

/**
 * Log encodings applied in the debayer shader. Each is "differential": the
 * curve is parameterized by the selected sensor's usable range
 * (white - black), so different sensors get their own transfer function.
 */
enum class LogProfile { CINE_FLAT, CINE_STD, REC709, ACES_CCT }

/** Output video codec passed through to the native encoder as a MIME type. */
enum class VideoCodec(val mime: String, val label: String) {
    HEVC("video/hevc", "HEVC (H.265)"),
    AVC("video/avc", "H.264"),
}

/** Recording output: an encoded video file, or one uncompressed DNG per RAW frame. */
enum class OutputMode { VIDEO, CINEMA_DNG }

/** true = the HAL correction stage is enabled; all default OFF (Process Zero). */
data class ProcessingToggles(
    val noiseReduction: Boolean = false,
    val edgeEnhancement: Boolean = false,
    val lensShading: Boolean = false,
    val hotPixel: Boolean = false,
    val aberrationCorrection: Boolean = false,
    val distortionCorrection: Boolean = false,
    val forceIdentityTonemap: Boolean = true,
    val videoStabilization: Boolean = false,
)

data class ExposureSettings(
    val auto: Boolean = true,
    val iso: Int = 400,
    /** 0 = derive shutter from [shutterAngle] and fps; else explicit ns. */
    val shutterNs: Long = 0L,
    val shutterAngle: Float = 180f,
) {
    fun effectiveShutterNs(fps: Int): Long =
        if (shutterNs > 0) shutterNs
        else (1_000_000_000.0 * shutterAngle / 360.0 / fps).toLong()
}

data class CaptureSettings(
    /** null = engine picks the best RAW sensor. */
    val sensorId: String? = null,
    /** 0x0 = auto (largest binned RAW size). Open gate = full readout, always. */
    val rawWidth: Int = 0,
    val rawHeight: Int = 0,
    val fps: Int = 30,
    /** Framing-guide aspect (w/h) drawn over the open-gate frame; 0 = none. */
    val guideAspect: Float = 0f,
    val exposure: ExposureSettings = ExposureSettings(),
    /** < 0 = continuous AF; >= 0 = manual focus in diopters. */
    val focusDiopters: Float = -1f,
    val processing: ProcessingToggles = ProcessingToggles(),
    val logProfile: LogProfile = LogProfile.CINE_FLAT,
    /** Encode at full sensor resolution instead of half (2x2 debayer scale). */
    val encodeFullRes: Boolean = false,
    val bitrateMbps: Int = 120,
    /** Output video codec; native encoder falls back to HEVC if unavailable. */
    val codec: VideoCodec = VideoCodec.HEVC,
    /** VIDEO encodes to a single file; CINEMA_DNG writes one DNG per RAW frame. */
    val outputMode: OutputMode = OutputMode.VIDEO,
    /** Apply the sensor IDT (camera RGB -> ACES AP1) before the log curve. */
    val acesIdt: Boolean = true,
    /** Installed .cube LUT name to preview-grade the viewfinder; null = off. */
    val previewLutName: String? = null,
    /** Capture a synced AAC-LC audio track alongside the video. */
    val audioEnabled: Boolean = true,
)

data class ScopeConfig(
    val falseColor: Boolean = false,
    val zebras: Boolean = false,
    val zebraHighIre: Float = 95f,
    val focusPeaking: Boolean = false,
    val peakingGain: Float = 1f,
    val waveform: Boolean = false,
)

/** Column-luminance waveform, [cols] x [rows] intensity bins, row 0 = 0 IRE. */
class WaveformData(val cols: Int, val rows: Int, val bins: ByteArray, val seq: Long)

data class Preset(val name: String, val settings: CaptureSettings)

/**
 * Slate metadata for the current/next take: standard film slate fields
 * (Roll/Scene/Take), used to name output files and stamp the JSON sidecar.
 * Kept separate from [CaptureSettings] — this is per-shot metadata, not a
 * look/capture setting.
 */
data class SlateInfo(
    val roll: String = "A001",
    val scene: String = "1",
    val take: Int = 1,
) {
    /** Filesystem-safe `${roll}_S${scene}_T${take}` stem, e.g. "A001_S1_T001". */
    fun fileStem(): String {
        val safeRoll = roll.replace(Regex("[^A-Za-z0-9-]"), "").ifEmpty { "A001" }
        val safeScene = scene.replace(Regex("[^A-Za-z0-9-]"), "").ifEmpty { "1" }
        val safeTake = take.coerceAtLeast(1)
        return "${safeRoll}_S${safeScene}_T${"%03d".format(safeTake)}"
    }
}
