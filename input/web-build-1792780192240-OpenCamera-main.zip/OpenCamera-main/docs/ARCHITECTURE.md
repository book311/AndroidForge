# Architecture

Multi-module Android app: Hilt DI, Compose UI, Kotlin coroutines/Flow, NDK C++ (GLES3 + MediaCodec).

```
app ──► core-domain ◄── core-camera (Kotlin + C++ libcinemapipeline)
  │            ▲    ◄── core-motion
  │            └─── ◄── core-gimbal
  └── UI, ViewModel, presets, remote server
```

## core-domain — contracts only

`CameraEngine`, `MotionCapture`, `GimbalLink` interfaces plus data models
(`CaptureSettings`, `ExposureSettings`, `ProcessingToggles`, `ScopeConfig`, `Preset`,
`EngineState`, `ProbeReport`, …). No implementation logic. Everything else binds an
implementation to one of these via Hilt — that's the primary mod/extension mechanism.

## core-camera — the pipeline

**Kotlin side** (`Camera2Engine`, ~700 lines): owns the Camera2 session. `CameraProber`
enumerates logical/physical/hidden camera ids and ranks RAW-capable sensors. Settings flow:
UI → `applySettings(CaptureSettings)` → live re-request (`updateRepeating()`) or full restart
(only for sensor/raw-size changes). Manual exposure = AE off + explicit `SENSOR_FRAME_DURATION`
for locked CFR. Ramps mutate `dyn*` overrides merged into every request.

**JNI boundary** (`NativePipeline` object ↔ `native_pipeline.cpp`): `init`, `pushFrame`
(camera frame thread, hot path — RAW16 into a SPSC ring buffer), `setPreviewSurface`,
`setLook`, `getWaveform`, `startEncoder`/`stopEncoder`, `release`.

**Native render thread**: one persistent thread owns the EGL context (thread-bound!) with a
pbuffer + preview window + encoder window surfaces. Per frame: pop ring → upload one `R16UI`
texture → draw to encoder (PTS from sensor timestamps) → draw to preview (shed if ring > 2).
Cross-thread commands are queued and drained by `processCommands()` on the render thread —
never touch GL from a JNI caller thread.

**Shader** (`gl_debayer.cpp`): single fragment shader does debayer (4 CFA orders) + log curve +
scopes (false color, zebras, focus peaking) selected by uniforms. Waveform is CPU-computed from
raw pixels every 3rd frame (240×128 grid via `getWaveform`).

**Encoder** (`encoder.cpp`): NDK `AMediaCodec` HEVC surface-input + `AMediaMuxer` MP4.

**Vivo HAL quirk**: a RAW-only session drops readout to ~20fps; a dummy 1080p PRIVATE
ImageReader is *configured* (never targeted) in the session to hold 30.00fps CFR.

## core-motion

`GcsvMotionCapture`: gyro+accel at `SENSOR_DELAY_FASTEST` (~960Hz on X200 Pro) on a dedicated
HandlerThread. On stop, accel is nearest-neighbor matched to gyro timestamps and written as
Gyroflow `.gcsv v1.3`, `t` anchored to the first *recorded* frame's sensor timestamp
(requires `TIMESTAMP_SOURCE_REALTIME`).

## core-gimbal

`HidGimbalLink`: DJI Osmo Mobile handled as a Bluetooth HID remote (no DJI SDK — MSDK doesn't
support Osmo Mobile). Record button arrives as hardware key events
(`MainActivity.dispatchKeyEvent` → `onKeyEvent`), debounced, emitted on `recordTrigger`.

## app

`MainViewModel` is the single orchestrator: wires record toggle → clip + gcsv paths →
`startRecording` → polls first-frame timestamp → anchors IMU. Compose: `CameraScreen`
(SurfaceView viewfinder + status strip + right rail) routes to side panels — LENS
(`SettingsPanel`), MOVE (`ProMovesPanel`), KIT (`PresetsPanel`). Overlays: framing guides,
waveform. Presets are one JSON file each under `filesDir/presets`.

## Output

`Android/data/com.cinemacamera/files/clips/TAKE_*.mp4` (flat-log HEVC) + `TAKE_*.gcsv`.

## Threading rules (do not break)

1. `pushFrame` only from the camera frame thread; no allocation there.
2. All EGL/GL/encoder work on the native render thread only.
3. Encoder has priority over preview when the ring backs up.
