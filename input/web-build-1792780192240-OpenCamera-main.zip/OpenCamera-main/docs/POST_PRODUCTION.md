# Post-Production Guide

This app records either a log-encoded MP4 (VIDEO mode) or an uncompressed
CinemaDNG image sequence (CINEMA_DNG mode) straight off the sensor's open-gate
readout. This guide covers recommended in-app settings and how to bring
either format into DaVinci Resolve with correct color.

Everything here is grounded in what the pipeline actually does — see
`docs/ARCHITECTURE.md` for the full pipeline description. Read the
"What the file actually contains" section before you build a color-managed
project; it will save you a wrong-looking grade.

## What the recorded VIDEO file actually contains

The debayer shader (`core-camera/.../gl_debayer.cpp`) runs, per pixel, in this
order:

1. Debayer the raw Bayer cell to linear camera RGB (0–1, normalized by the
   sensor's black/white level).
2. Multiply by the white-balance gain (`uWbGain`).
3. Multiply by a 3×3 color matrix (`uColorMat`) — **identity unless "ACES
   IDT" is enabled**, in which case it's the sensor's camera-RGB → ACES AP1
   matrix (see below).
4. Apply the selected log transfer curve (`applyLog`).
5. Encode 8-bit HEVC/AVC into an MP4 container tagged Rec.709 (no HDR
   metadata, no gamma/primaries tags beyond the container default).

The in-app preview LUT (`previewLutName`) is **preview-only** — `drawEncoder()`
always calls `applyUniforms(..., allowLut=false)`, so nothing you dial in as a
viewfinder LUT is baked into the recorded file. What you grade is always the
raw log-encoded signal, not a "look."

There is no debayer, WB, or log curve involved in CinemaDNG mode — see the
CinemaDNG section below.

## Recommended output settings

### Codec: HEVC vs H.264
- **HEVC (H.265)** is the default (`VideoCodec.HEVC`) and the right choice for
  almost everyone: it's hardware-encoded on this SoC and gives meaningfully
  better quality per bit than AVC, which matters when you're pushing a log
  image through only 8 bits.
- Switch to **H.264 (AVC)** only for compatibility — older NLEs, hardware
  decoders, or devices that choke on HEVC. Expect visibly softer results at
  the same bitrate, especially in shadow detail, because you're spending the
  same bits on a less efficient codec.
- If the codec you pick isn't available on the device, the native encoder
  falls back to HEVC automatically.

### Bitrate
The in-app ladder is **60 / 120 / 200 / 300 Mbps** (`bitrateMbps`). Because
the signal is log (flatter, more midtone-dense than a "baked" Rec.709 image),
it compresses less efficiently than normal footage shot at the same
bitrate — bias upward versus what you'd use for a standard-picture clip:

| Use case | Suggested bitrate |
|---|---|
| Half-res encode, well-lit, non-critical | 60–120 Mbps |
| Full-res encode, or lower light / more noise | 200 Mbps |
| Full-res, `ACES_CCT` log, heavy grading planned | 300 Mbps |

Higher bitrate always helps a log image; there's no reason to go lower than
120 Mbps unless you're storage-constrained.

### Full-res vs half-res encode
`encodeFullRes` toggles between encoding at the sensor's full open-gate
resolution and encoding at half resolution (a 2×2 debayer scale done in the
same shader pass). Full res roughly quadruples the pixel throughput the GPU
and encoder have to sustain every frame.

- **Half-res**: lower thermal load, longer sustained recording, smaller
  files at a given bitrate-per-pixel — the sensible default for run-and-gun
  or long takes.
- **Full-res**: use when you need the extra resolution for reframing/punch-in
  or a larger delivery format, and you can tolerate shorter thermal headroom
  and larger files. If the encoder rejects full-res for the current
  resolution/fps combination, the app automatically falls back to half-res
  and posts a HUD message — check for that message if a take looks
  softer/smaller than expected.

### CinemaDNG vs log video
Pick **CinemaDNG** when you need maximum grading latitude and are prepared to
manage the storage and offload workload: it's the raw sensor readout with
zero white balance, log curve, or color matrix baked in — every decision
(white balance, exposure, color space) is made in post from the actual
sensor data and camera color matrix embedded in each DNG.

Pick **log video (HEVC/AVC)** for everything where turnaround time, storage,
or edit-proxy simplicity matters more than the last stop of grading latitude.
The log curves already protect a wide dynamic range; for most work this is
plenty.

**Storage budget for CinemaDNG:** each 4K DNG 1.4 frame is uncompressed
RAW16 CFA data, roughly **25 MB/frame**. At 4K24 that's on the order of
**~36 GB per minute** — budget storage and your offload workflow (fast
external SSD via USB, or immediate transfer off-device) accordingly. DNG mode
sustains 4K24; the HUD surfaces frame drops if the storage pipeline can't
keep up, so watch it during the take, not after.

## DaVinci Resolve setup — log VIDEO (MP4) clips

The MP4 container is tagged Rec.709 but the pixels inside are a log-encoded
signal, not a Rec.709 picture. You must tell Resolve the true encoding or
everything will look washed out and flat with no adjustment applied.

The log curve used depends on the in-app `logProfile` at record time — it's
stamped into each take's JSON sidecar (`logProfile` field) and burned into
the pixels, so check the sidecar if you're not sure what a clip was shot
with. There are four profiles (`LogProfile` enum):

- **`REC709`** — the standard Rec.709 camera OETF (4.5× toe below 0.018,
  `1.099·x^0.45 − 0.099` above). This is a normal Rec.709 gamma curve, not a
  log curve — treat these clips as standard Rec.709 footage. No CST/input
  transform needed; they'll look correct as shot.
- **`CINE_STD`** — a fixed `log2(x·255+1)/8` curve, independent of sensor
  range. This is a custom log curve with no standard-format equivalent in
  Resolve's built-in list; do not assign a stock camera log space to it.
- **`CINE_FLAT`** — a *differential* curve, `log2(x·range+1)/log2(range+1)`,
  parameterized per-sensor by the sensor's black/white level. Also custom,
  and its shape depends on which physical sensor recorded it.
- **`ACES_CCT`** — a piecewise curve matching the **ACEScct** transfer
  function exactly (same breakpoint and coefficients as SMPTE ACEScct). If
  **ACES IDT** was also enabled at capture (`acesIdt = true`, the default),
  the color matrix baked into the image is camera RGB → **ACES AP1
  primaries**, so this combination is genuinely ACEScct-encoded, AP1-primary
  ACES data — the closest thing to a standard color space this app produces.

### Option A — Resolve Color Management (RCM)
1. Project Settings → Color Management → set **Color Science** to
   **DaVinci YRGB Color Managed**.
2. Set **Timeline Color Space** to your working space (ACEScct/ACEScg if
   you shot `ACES_CCT` with IDT on, or DaVinci Wide Gamut/Intermediate
   otherwise).
3. For each clip, open the Color Page → Camera Raw / Clip Attributes (or
   right-click → Clip Attributes → Video Input) and set **Input Color
   Space**:
   - `ACES_CCT` + IDT on → assign **ACEScct** (or the closest AP1-primary log
     preset RCM offers). This is the one case where a stock preset is
     actually correct.
   - `REC709` → assign **Rec.709 Gamma 2.4** / **Rec.709** — it's already a
     display-referred-ish gamma curve, not a log space.
   - `CINE_FLAT` / `CINE_STD` → there is no matching stock preset. Do not
     force-fit one (it will introduce a wrong-shaped curve on top of an
     already-wrong one). Use Option B instead for these profiles.

### Option B — manual grade with a Color Space Transform (CST) node
Use this for `CINE_FLAT` and `CINE_STD`, or if you prefer explicit control
over `ACES_CCT` too:
1. Leave Color Management on **DaVinci YRGB** (not color-managed) so Resolve
   doesn't apply an automatic transform.
2. On the first node of your grade, add a **Color Space Transform**:
   - Input Color Space: **Rec.709** primaries with a **Gamma → Linear**
     matching the profile:
     - `ACES_CCT` (no IDT): input gamma = ACEScct. The primaries were never
       transformed — they are the sensor's native camera RGB, which has no
       named preset. Rec.709 is the pragmatic approximation; expect to trim
       saturation/hue by eye (or just shoot with IDT on, which is why it's
       the default).
     - `ACES_CCT` (IDT on): input gamma = ACEScct, input primaries = **AP1**
       (ACES) — this is the accurate case; use the ACES preset if CST offers
       AP1 primaries directly, or route through an ACES IDT/CCT preset.
     - `REC709`: no CST needed — treat as a normal Rec.709 gamma clip.
     - `CINE_FLAT` / `CINE_STD`: no exact preset exists. Use a manual **Log**
       curve in the CST, or normalize by eye: pull up a waveform, set your
       first node to bring black/white points to a reasonable Rec.709 range,
       then grade from there. Because `CINE_FLAT`'s curve shape depends on
       the recording sensor's black/white level (baked in at capture, not
       recoverable from the file), a byte-exact inverse isn't available in
       Resolve — treat it as "flat log, normalize and grade," the same way
       you'd approach an undocumented third-party log profile.
   - Output Color Space: your working/display space (Rec.709, DaVinci Wide
     Gamut, or ACEScct/ACEScg if you're building an ACES pipeline).
3. Grade downstream of the CST node as usual.

## DaVinci Resolve setup — CinemaDNG sequences

Each take is a folder of individual DNG frames:
`clips/<ROLL>_S<SCENE>_T<TAKE>/` (e.g. `clips/A001_S1_T001/`), one uncompressed
DNG 1.4 file per frame, alongside the take's `.gcsv` and `.json` sidecars (no
audio track — CinemaDNG mode does not record audio).

1. **Media Pool → Import Media**, select the take folder — Resolve will
   detect the numbered DNG sequence and import it as a single clip.
2. Right-click the clip → **Clip Attributes** to confirm frame rate matches
   what you shot (cross-check against the take's JSON sidecar `fps` field if
   unsure).
3. Open the **Color Page → Camera Raw** panel:
   - **Decode Using**: choose **Camera Metadata**. The DNG tags carry the
     camera's actual color matrix (`ColorMatrix1`), the as-shot white balance
     (`AsShotNeutral`), and black/white level from the sensor — decoding via
     camera metadata uses these rather than a generic guess.
   - **Decode Quality / Color Science**: pick **DaVinci YRGB** for a
     conventional grade, or **ACES** if you're building an ACES pipeline —
     either works since the DNG carries a real camera matrix, not a
     already-applied color transform.
   - **Clip vs Project** decode: use **Project** if every take in the
     timeline should share one raw-decode setting (consistent look across a
     scene); use **Clip** to decode each take independently (e.g. mixed
     lighting across takes).
4. In the **RAW tab**, set white balance (there's no baked-in WB — CinemaDNG
   is the sensor's native readout) and exposure. Because nothing is
   pre-graded, small WB/exposure misses here are fully recoverable, unlike
   the log video path.
5. From here, grade normally; the DNG's full sensor range is available to
   you (no log curve or IDT already applied).

## Timecode, audio, and sync

- **Embedded timecode**: video takes carry a start timecode in the take's
  JSON sidecar (`timecodeStart`, SMPTE-style `HH:MM:SS:FF`) captured at
  record-start. If Resolve doesn't read it directly off the MP4, use the
  sidecar value to manually set the clip's start timecode in Clip Attributes.
- **JSON sidecar** (`<take>.json`, written next to the clip on stop): `roll`,
  `scene`, `take`, `fileName`, `timecodeStart`, `createdAt`, `fps`,
  `resolution`, `logProfile`, `durationMs`, `frameCount`,
  `imuSampleCount`. Useful for scripting a batch color-space assignment
  (group clips by `logProfile`) or for slating/organizing bins by
  roll/scene/take.
- **Audio**: when `audioEnabled` is on (default), the MP4 has an AAC-LC
  track recorded in sync with video — no separate audio file or manual sync
  needed for VIDEO-mode takes. CinemaDNG mode has no audio track at all;
  if you need sound with a DNG take, record it externally and sync using the
  embedded timecode or a clap/slate.
- **GCSV gyro data**: each take also writes a `.gcsv` file — this is a
  genuine **Gyroflow** IMU log (`GYROFLOW IMU LOG`, `version,1.3`), containing
  gyro (and matched accelerometer) samples anchored to the take's first
  recorded frame, plus the take's start timecode (`tc_start`). Load the video
  (or DNG sequence) and its matching `.gcsv` into **Gyroflow** to generate a
  stabilized export or a Gyroflow-format lens/stabilization data track for
  Resolve's Fusion/Gyroflow-compatible tools.

## Appendix / FAQ

**File naming.** Clips are named from the slate: `<Roll>_S<Scene>_T<Take>`,
e.g. `A001_S1_T001` (roll auto-formats to remove unsafe characters, take is
always zero-padded to 3 digits). VIDEO mode produces `A001_S1_T001.mp4` +
`A001_S1_T001.gcsv` + `A001_S1_T001.json` side by side. CinemaDNG mode
produces a folder `A001_S1_T001/` containing the numbered DNG frames plus the
same `.gcsv`/`.json` sidecars. If a same-named take already exists, the app
appends a timestamp suffix rather than overwriting.

**Where files live on the phone.** App-private storage:
`Android/data/com.cinemacamera/files/clips/`. This is not the public
gallery — you won't find takes in a normal Photos app browse. The app can
also copy a finished MP4 into the public `Movies/CinemaCamera` gallery folder
via the in-app export action, if you want a copy MediaStore-visible apps can
see.

**Pulling footage off the device.**
- **USB**: with USB debugging or MTP file access enabled, browse to
  `Android/data/com.cinemacamera/files/clips/` (Android 11+ restricts direct
  Files-app access to this path for non-owner apps; `adb` is the reliable
  route — see below).
- **adb**: `adb pull "/sdcard/Android/data/com.cinemacamera/files/clips" .`
  pulls the whole clips directory over USB or Wi-Fi ADB.
- **Web "Director" panel**: the app runs an on-device REST/web server
  exposing a `/api/clips/download` endpoint (and `/api/clips/sidecar` for
  the JSON metadata) — open the Director web UI on another device on the
  same network to browse and download takes without touching a cable.

**Storage throughput.** CinemaDNG's ~25 MB/frame at 4K24 (~36 GB/min) will
outrun slower storage. If you see dropped frames in the HUD during a
CinemaDNG take, it's a storage-write bottleneck, not a decode/debayer issue —
use the phone's fastest available internal storage and offload takes
promptly; don't let the clips directory fill up mid-shoot.
