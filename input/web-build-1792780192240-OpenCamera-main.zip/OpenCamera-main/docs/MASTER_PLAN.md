# Master Implementation Plan (V4 → V10 + Remote Controller)

Status legend: ✅ done · 🔨 in progress · ⬜ planned

V1–V3 (RAW pipeline, CFR, cinema UI, scopes, presets, basic ramps) shipped 2026-07-04.

> **Scope note (2026-07-04):** all gimbal *control* features are cut — the Osmo Mobile HID
> link exposes no motor control, so waypoints/PID-to-gimbal were speculative. Camera moves
> are digital (crop-region pan/tilt + zoom). The gimbal record button (HID key events) stays.
> `GimbalDriver`-style hooks remain a documented mod point only.

## Step 0 — Open-source scaffolding ✅
git repo, MIT LICENSE, README, CONTRIBUTING, ARCHITECTURE, MODDING docs.

## Step 1 — V4: ACES color science ✅
- IDT built from the sensor's `SENSOR_COLOR_TRANSFORM1/2` + `SENSOR_CALIBRATION_TRANSFORM` →
  camera RGB → CIE XYZ → ACES AP1 matrix, computed in Kotlin, uploaded as a shader uniform.
- New log profile `ACES_CCT` (ACEScct encode) alongside CINE_FLAT/CINE_STD/REC709.
- Live 3D LUT preview: parse `.cube` files (Kotlin), upload as GLES3 3D texture, applied
  preview-only (recording stays flat log). LUT picker in LENS panel (from `filesDir/luts`
  + SAF import).

## Step 2 — Automation Engine (keyframe timeline foundation) ✅
- Replace single `rampJob` with a multi-track `AutomationEngine` in core-domain/core-camera:
  tracks (FOCUS, ISO, SHUTTER, ZOOM), each a list of keyframes `(timeMs, value, easing)`.
  30Hz evaluator drives `dyn*` overrides; tracks run concurrently.
- `Sequence` model serializable to JSON (schema-versioned) — the same format the laptop
  timeline editor edits.
- Trigger modes: manual, on-record-start (armed), remote.
- MOVE panel gains "arm sequence on record" and sequence save/load.

## Correctness pass (user-reported trust-breakers, 2026-07-05) ✅
- ✅ Green cast: no white balance existed (null CaptureCallback, no shader WB step).
  Fixed with `uWbGain` from `COLOR_CORRECTION_GAINS` applied before the IDT matrix.
- ✅ Persistent settings: `SettingsStore` JSON in filesDir, loaded on startup.
- ✅ Dead processing toggles: made real in the debayer shader (preview + encoder) —
  lens shading (HAL `STATISTICS_LENS_SHADING_CORRECTION_MAP` → RGB gain texture),
  hot-pixel (same-color neighbor clamp), Sharpen (was "edge", unsharp), Denoise
  (was "noise reduction", spatial avg). Aberration/distortion removed from UI
  (ISP-only, can't touch RAW; fields kept for preset compat). Verified on-device.

## Step 3 — Refinement pass ✅
- MOVE panel params survive panel close (hoist out of local remember state).
- `RecordingResult.imuSampleCount` reported correctly; frame-count vs IMU sanity check.
- Per-clip EXPORT to gallery (MediaStore `IS_PENDING` handshake — Android 16 rejects
  direct `_data` inserts, so no auto-registration on stop).
- Battery / thermal / storage-remaining HUD with record-safe warnings.
- In-app media browser: list takes, play back, show gcsv sample count.

## Step 4 — V6: Audio, timecode & sync ✅
- AudioRecord 48kHz (float where supported, USB-C mics via standard audio HAL), AAC track
  added to the native muxer; RECORD_AUDIO permission.
- VU meters with peak hold in UI; headphone passthrough monitor toggle.
- `TimecodeSource` interface: internal free-run/time-of-day SMPTE generator now, BLE boxes
  (Tentacle-style) as pluggable drivers later. TC stamped into gcsv header + MP4 metadata +
  slate overlay.

## Step 5 — V7: Open gate & anamorphic — SKIPPED (user request 2026-07-05)
- Deprioritized; framing guides + anamorphic de-squeeze deferred. Not blocking V9/V10.

## ~~V8: Subject tracking & auto-framing~~ — CUT (2026-07-04)
Cut with the gimbal scope; tracking without motorized framing wasn't worth the complexity.
A `SubjectTracker` interface remains a documented mod point only.

## Step 6 — V9: Pro data & file management 🔨
- ✅ **V9a Slate**: Scene/Take/Roll UI, `ROLL_SCENE_TAKE` naming, JSON sidecar per clip,
  auto-increment take, persisted via SettingsStore. Verified on-device (commit 33c98d8).
  (MP4-embedded metadata deferred to V9c; sidecar `resolution` currently reports raw sensor
  size, to be corrected to encoded output dims.)
- ⬜ **V9b Bitrate/codec**: ladder up to 400 Mbps, explicit `KEY_PROFILE`/`KEY_LEVEL`
  (8-bit Main), then 10-bit HEVC (Main10) best-effort with capability probe + 8-bit fallback
  (needs a 10-bit encoder surface from the GL debayer).
- ⬜ **V9c Direct-to-SSD**: SAF tree picker for USB-C drives (`ACTION_OPEN_DOCUMENT_TREE` +
  persistable permission), muxer/gcsv open via fd from `openFileDescriptor`; MP4 metadata.

## Step 8 — V10: Remote controller, monitor & cloud 🔨
- ✅ **V10a Server + REST control + web panel**: new `:core-remote` module runs an embedded
  Ktor CIO server (port 8080) in-process, started when the RAW stream starts. `RemoteController`
  seam implemented by `MainViewModel`. PIN pairing (SecureRandom 6-digit) → opaque 32-byte
  session tokens (in-memory set); all `/api/**` require `Authorization: Bearer` or `?t=`.
  REST: status, settings get/patch, record on/off (remote trigger), slate, presets
  apply/save/delete, sequences list/load/play/stop/arm, clips list + download + sidecar.
  Self-contained vanilla-JS SPA served from assets. In-app DIRECTOR panel shows LAN URL + PIN.
  Verified on-device: auth rejects (401), pairing works, live status, settings apply, remote
  record recorded a real clip, GET download streams. Mutation echoes made truthful (await the
  async apply). Slice built by Sonnet subagent, vetted + device-tested + echo-fixed by Fable.
- ⬜ **V10b**: browser multi-track timeline editor (Sequence JSON) + live-status WebSocket.
- ⬜ **V10c**: MJPEG live monitor over WebSocket (native preview readback).
- Security later: optional TLS with generated self-signed cert; PIN pairing brute-force
  throttling; token expiry.
- Remaining API surface (V10b/c): scopes data, live preview frames.
- Timeline editor in the web app: multi-track keyframes (focus A/B pulls, exposure, zoom,
  gimbal), drag handles, easing per keyframe, "play on record" arming — edits the same JSON
  `Sequence` schema as Step 2.
- Director's monitor: MJPEG-over-WebSocket live preview (LUT applied) first; WebRTC upgrade
  path documented.
- Proxy upload hook: `UploadTarget` interface + generic S3-compatible/WebDAV impl (Frame.io
  requires account-specific API; left as a documented mod hook).

## Nice-to-haves (added as we go)
- Media browser / shot log in app (play back takes, gcsv sample count check).
- RGB histogram + vectorscope shader modes.
- Preset schema versioning & migration.
- Battery/thermal/storage HUD with rec-safe warnings.
- Crash-safe muxer recovery note (moov recovery guidance).
