# Motion Control (OpenMotionFX)

[OpenMotionFX](https://github.com/openlumenorg/OpenMotionFX) is a planned
open-source motion-control platform from the same org as this app: a
Conductor app that drives motorized rigs (pan/tilt heads, sliders, turntables) from
`.omfx` move files, executed by field Nodes. Its wire protocol (OMP) is
pre-v0 — nothing about frame formats or the sync plane is locked yet. This
app does not implement OMP. It integrates only with the handful of
OpenMotionFX decisions that are already fixed: service discovery, the
Compile→Upload→Arm→GO execution model, and the `.omfx` camera metadata
schema. Everything below is scoped to those locked parts; anything protocol-
level is explicitly out of scope until OMP reaches v0.

## Discovery

The app advertises itself over NSD/mDNS as an OpenMotionFX Node:

- Service type: `_openmotionfx._tcp`
- Service name: `OpenCamera-<device model>` (spaces sanitized to dashes)
- Port: `8080` (the existing REST server, see `core-remote`)
- TXT records: `role=camera`, `api=rest`, `ver=0`, `app=opencamera`

A future OpenMotionFX Conductor finds this camera the same way it finds any
other Node — no camera-specific discovery code needed on their side. See
`RemoteServer.registerNsd()` in `core-remote/.../RemoteServer.kt`.

## Trigger and record

OpenMotionFX sequences run through a Compile→Upload→Arm→GO cycle. This
camera's existing REST API (routes defined in
`core-remote/.../RemoteServer.kt`) maps onto that model without changes:

| OpenMotionFX phase | Camera REST call         |
|---------------------|---------------------------|
| Upload               | `POST /api/sequences/load` |
| Arm                  | `POST /api/sequences/arm`  |
| GO                   | `POST /api/record` and/or `POST /api/sequences/play` |

Ordinary LAN HTTP latency (tens of milliseconds, occasionally more under Wi-Fi
contention) is fine here: OpenMotionFX's design puts nothing time-critical on
the network. Frame-accurate sync comes from the Sync Box's flash or beep,
which this camera simply films/records like any other light or sound in the
scene — the HTTP call only has to land before the physical trigger fires, not
in sync with it.

## Sync

Two sync mechanisms work today, camera-agnostic, no protocol needed:

- **Sync-flash**: a visible flash from the Sync Box, filmed in-frame, used to
  align footage to the move file in post.
- **Audio-slate**: a beep or clap recorded on this camera's synced AAC-LC
  audio track (`CaptureSettings.audioEnabled`), aligned the same way.

The app additionally embeds SMPTE timecode (`Timecode`/`TimecodeSource`) and
writes it into the per-take JSON sidecar (`timecodeStart`), so a take already
carries a `tc` reference independent of sync-flash/audio-slate. LTC jam sync
(genlocking this camera's timecode to an external LTC source) is a plausible
future feature but is not implemented — it isn't required for any locked
OpenMotionFX behavior today.

## Metadata

The per-take JSON sidecar (written at record-stop, next to the `.mp4` or
inside the CinemaDNG take folder) includes a nested `camera` object whose
field names match `.omfx`'s `camera.json` exactly, so a take's metadata can
be dropped straight into a move file:

- `focalLengthMm` — from `CameraCharacteristics.LENS_INFO_AVAILABLE_FOCAL_LENGTHS[0]`
- `sensorSizeMm` — `[width, height]` from `CameraCharacteristics.SENSOR_INFO_PHYSICAL_SIZE`
- `focusDistanceM` — `1 / focusDiopters` when manual focus is set, `null` for
  continuous AF/infinity (diopters `<= 0`)
- `iso` — the take's `ExposureSettings.iso`
- `shutterS` — the take's effective shutter time in seconds (e.g. `1/48` shutter
  serializes as `0.02083`)
- `principalPoint` — always `null`; this app has no depth-calibration data to
  derive it from, so it is left absent rather than faked

The gyro-derived `.gcsv` motion track recorded alongside every take (see
`docs/POST_PRODUCTION.md`) is not an OpenMotionFX-defined field, but it's a
useful bonus motion reference for anyone stabilizing or cross-referencing
footage against a move file.

## Explicitly out of scope

The following depend on OMP decisions that don't exist yet and are
deliberately not implemented:

- CBOR/protobuf wire frames for the motion-control protocol itself
- The ESP-NOW-based low-latency sync plane
- CAN bus integration for rig-side communication

None of these are needed for a camera to be a well-behaved OpenMotionFX
Node today; they're artifacts of the *rig* side of the protocol, not the
camera side.
