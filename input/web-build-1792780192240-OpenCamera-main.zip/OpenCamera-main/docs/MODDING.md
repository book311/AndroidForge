# Modding Guide

CinemaCamera is built to be forked and extended. Every subsystem hides behind a small
interface in `core-domain`, bound via Hilt — swap the binding, ship your variant.

## Extension points

| You want to… | Do this |
|---|---|
| Support another phone/sensor | `CameraProber` ranks RAW sensors generically; add quirks there (e.g. the Vivo dummy-stream 30fps fix in `Camera2Engine`). File an issue with your `ProbeReport`. |
| Add a look / log curve | Add a mode to the fragment shader in `gl_debayer.cpp` (`applyLog`), a `LogProfile` enum entry, and a chip in `SettingsPanel`. Parameterize by black/white levels — don't hardcode sensor values. |
| Add a scope | Same shader, new uniform-gated branch (see false color / zebra / peaking), or CPU-side like the waveform tap. |
| Ship a LUT pack | Drop `.cube` files in `filesDir/luts` (or import via the LENS panel). |
| Drive a real gimbal | Implement `GimbalDriver` (attitude/waypoint control) in your own module and bind it with Hilt; the automation engine and tracker will use it automatically. |
| Add a timecode box | Implement `TimecodeSource` (BLE protocol of your box) and bind it. |
| Auto-upload footage | Implement `UploadTarget` (called with proxy + master paths on stop). |
| Remote-control from anything | The remote API is plain REST + WebSocket with documented JSON (see `docs/REMOTE_API.md` once Step 8 lands). Sequences are versioned JSON — generate them from your own tools. |
| New input hardware | `GimbalLink.onKeyEvent` receives all hardware keys; map your controller there. |

## Rules of the road

- Keep `core-domain` free of implementation and heavy dependencies.
- Respect the threading rules in [ARCHITECTURE.md](ARCHITECTURE.md) — the render thread owns GL.
- Presets and sequences are schema-versioned JSON; bump the version and write a migration
  instead of breaking old files.

## License

MIT — fork freely, credit appreciated.
