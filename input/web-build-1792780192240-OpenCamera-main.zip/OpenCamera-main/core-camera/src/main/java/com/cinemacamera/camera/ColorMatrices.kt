package com.cinemacamera.camera

import kotlin.math.abs

/**
 * Fixed color-science constants and 3x3 helpers for building a sensor IDT
 * (camera RGB -> ACES AP1). All matrices are row-major float[9]; `m * v`
 * means `out[r] = sum_c m[r*3+c] * v[c]`.
 */
object ColorMatrices {

    val IDENTITY = floatArrayOf(
        1f, 0f, 0f,
        0f, 1f, 0f,
        0f, 0f, 1f,
    )

    /** CIE XYZ -> ACES AP1 (linear, D60 white), the standard ACES working-space matrix. */
    val XYZ_TO_AP1 = floatArrayOf(
        1.6410233797f, -0.3248032942f, -0.2364246952f,
        -0.6636628587f, 1.6153315917f, 0.0167563477f,
        0.0117218943f, -0.0082844420f, 0.9883948585f,
    )

    /** Bradford cone-response matrix, used for chromatic adaptation. */
    val BRADFORD = floatArrayOf(
        0.8951f, 0.2664f, -0.1614f,
        -0.7502f, 1.7135f, 0.0367f,
        0.0389f, -0.0685f, 1.0296f,
    )

    private val BRADFORD_INV = invert3x3(BRADFORD)

    /** ACES white point, CIE xy = (0.32168, 0.33767). */
    val ACES_D60_WHITE = xyToXyz(0.32168f, 0.33767f)

    fun multiply3x3(a: FloatArray, b: FloatArray): FloatArray {
        val out = FloatArray(9)
        for (r in 0..2) {
            for (c in 0..2) {
                var sum = 0f
                for (k in 0..2) sum += a[r * 3 + k] * b[k * 3 + c]
                out[r * 3 + c] = sum
            }
        }
        return out
    }

    fun multiply3x3Vec(m: FloatArray, v: FloatArray): FloatArray {
        val out = FloatArray(3)
        for (r in 0..2) out[r] = m[r * 3] * v[0] + m[r * 3 + 1] * v[1] + m[r * 3 + 2] * v[2]
        return out
    }

    fun invert3x3(m: FloatArray): FloatArray {
        val a = m[0]; val b = m[1]; val c = m[2]
        val d = m[3]; val e = m[4]; val f = m[5]
        val g = m[6]; val h = m[7]; val i = m[8]

        val a00 = e * i - f * h
        val a01 = -(d * i - f * g)
        val a02 = d * h - e * g
        val a10 = -(b * i - c * h)
        val a11 = a * i - c * g
        val a12 = -(a * h - b * g)
        val a20 = b * f - c * e
        val a21 = -(a * f - c * d)
        val a22 = a * e - b * d

        val det = a * a00 + b * a01 + c * a02
        if (abs(det) < 1e-12f) return IDENTITY.copyOf()
        val invDet = 1f / det
        // Adjugate is the transpose of the cofactor matrix.
        return floatArrayOf(
            a00 * invDet, a10 * invDet, a20 * invDet,
            a01 * invDet, a11 * invDet, a21 * invDet,
            a02 * invDet, a12 * invDet, a22 * invDet,
        )
    }

    fun xyToXyz(x: Float, y: Float): FloatArray {
        if (y == 0f) return floatArrayOf(0f, 0f, 0f)
        return floatArrayOf(x / y, 1f, (1f - x - y) / y)
    }

    /** Bradford chromatic-adaptation matrix mapping XYZ under [srcWhite] to XYZ under [dstWhite]. */
    fun bradfordAdapt(srcWhite: FloatArray, dstWhite: FloatArray): FloatArray {
        val srcLms = multiply3x3Vec(BRADFORD, srcWhite)
        val dstLms = multiply3x3Vec(BRADFORD, dstWhite)
        val scale = floatArrayOf(
            if (abs(srcLms[0]) > 1e-8f) dstLms[0] / srcLms[0] else 1f, 0f, 0f,
            0f, if (abs(srcLms[1]) > 1e-8f) dstLms[1] / srcLms[1] else 1f, 0f,
            0f, 0f, if (abs(srcLms[2]) > 1e-8f) dstLms[2] / srcLms[2] else 1f,
        )
        return multiply3x3(BRADFORD_INV, multiply3x3(scale, BRADFORD))
    }

    /** Approximate CIE xy white point for an ANDROID_SENSOR_REFERENCE_ILLUMINANT1/2 value. */
    fun illuminantWhiteXyz(illuminant: Int?): FloatArray = when (illuminant) {
        1, 9, 12, 21 -> xyToXyz(0.3127f, 0.3290f)   // DAYLIGHT / FINE_WEATHER / DAYLIGHT_FLUORESCENT / D65
        2, 14 -> xyToXyz(0.3721f, 0.3751f)          // FLUORESCENT / COOL_WHITE_FLUORESCENT
        3, 17, 24 -> xyToXyz(0.4476f, 0.4074f)      // TUNGSTEN / STANDARD_A / ISO_STUDIO_TUNGSTEN
        4, 20 -> xyToXyz(0.3324f, 0.3474f)          // FLASH / D55
        10, 11, 22 -> xyToXyz(0.2990f, 0.3149f)     // CLOUDY_WEATHER / SHADE / D75
        13, 23 -> xyToXyz(0.3457f, 0.3585f)         // DAY_WHITE_FLUORESCENT / D50
        15 -> xyToXyz(0.3800f, 0.3800f)             // WHITE_FLUORESCENT
        18 -> xyToXyz(0.3484f, 0.3516f)             // STANDARD_B
        19 -> xyToXyz(0.3101f, 0.3162f)             // STANDARD_C
        else -> xyToXyz(0.3457f, 0.3585f)           // unknown: fall back to D50 (common DNG reference)
    }

    /**
     * Camera RGB -> ACES AP1: invert the sensor's XYZ->camRGB transform,
     * Bradford-adapt from the reference illuminant white to D60, then project
     * into AP1. Rows are normalized so neutral (1,1,1) camera stays neutral.
     */
    fun buildIdtMatrix(xyzToCamRgb: FloatArray, illuminant: Int?): FloatArray {
        val camToXyz = invert3x3(xyzToCamRgb)
        val cat = bradfordAdapt(illuminantWhiteXyz(illuminant), ACES_D60_WHITE)
        val camToAp1 = multiply3x3(XYZ_TO_AP1, multiply3x3(cat, camToXyz))
        return normalizeNeutral(camToAp1)
    }

    private fun normalizeNeutral(m: FloatArray): FloatArray {
        val neutral = multiply3x3Vec(m, floatArrayOf(1f, 1f, 1f))
        val out = m.copyOf()
        for (r in 0..2) {
            val s = if (abs(neutral[r]) > 1e-6f) 1f / neutral[r] else 1f
            out[r * 3] *= s; out[r * 3 + 1] *= s; out[r * 3 + 2] *= s
        }
        return out
    }
}
