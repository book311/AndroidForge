package com.cinemacamera.camera

import com.cinemacamera.domain.AutoTrack
import com.cinemacamera.domain.AutoTrackKind
import com.cinemacamera.domain.Easing
import com.cinemacamera.domain.Keyframe
import com.cinemacamera.domain.Sequence

/**
 * Pure keyframe evaluator: given a [Sequence] and an elapsed time, produces
 * the value of every track at that instant. No side effects, no coroutines —
 * unit-testable in isolation from Camera2Engine.
 */
object AutomationEngine {

    /** One value per track kind present in [seq], evaluated at [elapsedMs]. */
    fun evaluate(seq: Sequence, elapsedMs: Long): Map<AutoTrackKind, Double> =
        seq.tracks.associate { it.kind to evaluateTrack(it, elapsedMs) }

    fun evaluateTrack(track: AutoTrack, elapsedMs: Long): Double {
        val kfs = track.keyframes
        if (kfs.isEmpty()) return 0.0
        if (elapsedMs <= kfs.first().timeMs) return kfs.first().value
        if (elapsedMs >= kfs.last().timeMs) return kfs.last().value

        var lo: Keyframe = kfs.first()
        var hi: Keyframe = kfs.last()
        for (i in 0 until kfs.size - 1) {
            if (elapsedMs >= kfs[i].timeMs && elapsedMs <= kfs[i + 1].timeMs) {
                lo = kfs[i]
                hi = kfs[i + 1]
                break
            }
        }
        val span = (hi.timeMs - lo.timeMs).coerceAtLeast(1)
        val t = ((elapsedMs - lo.timeMs).toDouble() / span).coerceIn(0.0, 1.0)
        val e = ease(hi.easing, t)
        return when (track.kind) {
            AutoTrackKind.ISO, AutoTrackKind.SHUTTER_NS -> geometricLerp(lo.value, hi.value, e)
            AutoTrackKind.FOCUS, AutoTrackKind.ZOOM -> lo.value + (hi.value - lo.value) * e
        }
    }

    private fun geometricLerp(from: Double, to: Double, e: Double): Double {
        if (from <= 0.0 || to <= 0.0) return from + (to - from) * e
        return from * Math.pow(to / from, e)
    }

    private fun ease(easing: Easing, t: Double): Double = when (easing) {
        Easing.LINEAR -> t
        Easing.SMOOTH -> t * t * (3.0 - 2.0 * t)
        Easing.EASE_IN -> t * t
        Easing.EASE_OUT -> 1.0 - (1.0 - t) * (1.0 - t)
        Easing.HOLD -> if (t >= 1.0) 1.0 else 0.0
    }
}
