package com.cinemacamera.camera

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.ImageFormat
import android.hardware.camera2.CameraCaptureSession
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraDevice
import android.hardware.camera2.CameraManager
import android.hardware.camera2.CameraMetadata
import android.hardware.camera2.CaptureRequest
import android.hardware.camera2.CaptureResult
import android.hardware.camera2.TotalCaptureResult
import android.hardware.camera2.params.ColorSpaceTransform
import android.hardware.camera2.params.OutputConfiguration
import android.hardware.camera2.params.SessionConfiguration
import android.hardware.camera2.params.TonemapCurve
import android.media.ImageReader
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.util.Log
import android.util.Range
import android.util.Size
import android.view.Surface
import com.cinemacamera.domain.AutoTrackKind
import com.cinemacamera.domain.CameraEngine
import com.cinemacamera.domain.CaptureSettings
import com.cinemacamera.domain.EnginePhase
import com.cinemacamera.domain.EngineState
import com.cinemacamera.domain.LogProfile
import com.cinemacamera.domain.ProbeReport
import com.cinemacamera.domain.RawSize
import com.cinemacamera.domain.RecordingResult
import com.cinemacamera.domain.RecordingTarget
import com.cinemacamera.domain.ScopeConfig
import com.cinemacamera.domain.Sequence
import com.cinemacamera.domain.SequenceTransport
import com.cinemacamera.domain.SensorInfo
import com.cinemacamera.domain.StreamStats
import com.cinemacamera.domain.WaveformData
import dagger.hilt.android.qualifiers.ApplicationContext
import java.io.File
import java.util.concurrent.Executor
import java.util.concurrent.atomic.AtomicLong
import javax.inject.Inject
import javax.inject.Singleton
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext

@Singleton
class Camera2Engine @Inject constructor(
    @ApplicationContext private val context: Context,
) : CameraEngine {

    private val manager: CameraManager = context.getSystemService(CameraManager::class.java)

    private val _state = MutableStateFlow(EngineState())
    override val state: StateFlow<EngineState> = _state
    private val _stats = MutableStateFlow(StreamStats())
    override val stats: StateFlow<StreamStats> = _stats
    private val _sensors = MutableStateFlow<List<SensorInfo>>(emptyList())
    override val sensors: StateFlow<List<SensorInfo>> = _sensors
    private val _settings = MutableStateFlow(CaptureSettings())
    override val settings: StateFlow<CaptureSettings> = _settings
    private val _audioLevels = MutableStateFlow(floatArrayOf(0f, 0f))
    override val audioLevels: StateFlow<FloatArray> = _audioLevels

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private val restartLock = Mutex()

    private val camThread = HandlerThread("cam-engine").apply { start() }
    private val camHandler = Handler(camThread.looper)
    private val camExecutor = Executor { camHandler.post(it) }
    // Dedicated thread for the RAW frame firehose; nothing else runs on it.
    private val frameThread = HandlerThread("raw-frames", android.os.Process.THREAD_PRIORITY_URGENT_DISPLAY).apply { start() }
    private val frameHandler = Handler(frameThread.looper)

    private var allChars = mapOf<String, CameraCharacteristics>()
    private var characteristics: CameraCharacteristics? = null
    private var probeReport: ProbeReport? = null
    private var device: CameraDevice? = null
    private var session: CameraCaptureSession? = null
    private var rawReader: ImageReader? = null
    private var dummyReader: ImageReader? = null
    private var rawSize: Size = Size(0, 0)
    private var activeSensor: SensorInfo? = null
    private var scopeConfig = ScopeConfig()

    private val framesCaptured = AtomicLong(0)
    @Volatile private var recording = false
    @Volatile private var dngActive = false
    @Volatile private var firstRecordedTsNs = 0L
    @Volatile private var lastTsNs = 0L
    private var recordingTarget: RecordingTarget? = null
    private var statsJob: Job? = null
    private var audioLevelsJob: Job? = null
    private var rampJob: Job? = null
    private var sequenceJob: Job? = null
    private var nativeReady = false
    private val waveformBuf = ByteArray(NativePipeline.WAVEFORM_COLS * NativePipeline.WAVEFORM_ROWS)
    private var lastWaveformSeq = -1L

    // Live overrides written by ramps, merged into every repeating request.
    @Volatile private var dynIso: Int? = null
    @Volatile private var dynShutterNs: Long? = null
    @Volatile private var dynFocus: Float? = null
    @Volatile private var dynZoom: Float = 1f

    // AWB gains read from CaptureResult, throttled before hitting the JNI/GL setter.
    @Volatile private var lastWbGain: FloatArray = floatArrayOf(1f, 1f, 1f)
    @Volatile private var lastWbPushNs: Long = 0L
    @Volatile private var lastShadingPushNs: Long = 0L
    @Volatile private var shadingUploaded: Boolean = false
    private val captureCallback = object : CameraCaptureSession.CaptureCallback() {
        override fun onCaptureCompleted(
            session: CameraCaptureSession,
            request: CaptureRequest,
            result: TotalCaptureResult,
        ) {
            val gains = result.get(CaptureResult.COLOR_CORRECTION_GAINS)
            val gain: FloatArray = if (gains != null) {
                val r = gains.red
                val g = (gains.greenEven + gains.greenOdd) / 2f
                val b = gains.blue
                if (g > 0f) floatArrayOf(r / g, 1f, b / g) else DEFAULT_WB_GAIN
            } else {
                // SENSOR_NEUTRAL_COLOR_POINT is only ever populated on a
                // CaptureResult (android.sensor.neutralColorPoint), not on
                // CameraCharacteristics — read it off the same result.
                val neutral = result.get(CaptureResult.SENSOR_NEUTRAL_COLOR_POINT)
                if (neutral != null && neutral.size >= 3) {
                    val rn = neutral[0].toDouble()
                    val gn = neutral[1].toDouble()
                    val bn = neutral[2].toDouble()
                    val rg = if (rn != 0.0) (1.0 / rn).toFloat() else 1f
                    val gg = if (gn != 0.0) (1.0 / gn).toFloat() else 1f
                    val bg = if (bn != 0.0) (1.0 / bn).toFloat() else 1f
                    if (gg > 0f) floatArrayOf(rg / gg, 1f, bg / gg) else DEFAULT_WB_GAIN
                } else {
                    DEFAULT_WB_GAIN
                }
            }
            maybePushWbGain(gain)
            maybePushShadingMap(result)
        }
    }

    /** Throttle: only push to the native setter on >1% channel change or >=500ms elapsed. */
    private fun maybePushWbGain(gain: FloatArray) {
        val now = System.nanoTime()
        val elapsedMs = (now - lastWbPushNs) / 1_000_000L
        val last = lastWbGain
        val changed = (0 until 3).any { i ->
            val denom = if (last[i] != 0f) last[i] else 1f
            kotlin.math.abs(gain[i] - last[i]) / kotlin.math.abs(denom) > 0.01f
        }
        if (changed || elapsedMs >= 500L) {
            lastWbGain = gain
            lastWbPushNs = now
            NativePipeline.setWbGain(gain)
        }
    }

    private fun maybePushShadingMap(result: TotalCaptureResult) {
        val on = _settings.value.processing.lensShading
        if (!on) { shadingUploaded = false; return }
        val now = System.nanoTime()
        // Shading changes slowly; refresh at most every 2s (and once on enable).
        if (shadingUploaded && (now - lastShadingPushNs) / 1_000_000L < 2000L) return
        val map = result.get(CaptureResult.STATISTICS_LENS_SHADING_CORRECTION_MAP) ?: return
        val cols = map.columnCount
        val rows = map.rowCount
        val rggb = FloatArray(cols * rows * 4)
        map.copyGainFactors(rggb, 0)
        // RGGB gain map -> per-pixel RGB gains (average the two greens).
        val rgb = FloatArray(cols * rows * 3)
        for (i in 0 until cols * rows) {
            rgb[i * 3]     = rggb[i * 4]
            rgb[i * 3 + 1] = (rggb[i * 4 + 1] + rggb[i * 4 + 2]) * 0.5f
            rgb[i * 3 + 2] = rggb[i * 4 + 3]
        }
        NativePipeline.setShadingMap(rgb, cols, rows)
        lastShadingPushNs = now
        shadingUploaded = true
    }

    private val _activeSequence = MutableStateFlow<Sequence?>(null)
    override val activeSequence: StateFlow<Sequence?> = _activeSequence
    private val _sequenceTransport = MutableStateFlow(SequenceTransport.IDLE)
    override val sequenceTransport: StateFlow<SequenceTransport> = _sequenceTransport
    private val _sequencePositionMs = MutableStateFlow(0L)
    override val sequencePositionMs: StateFlow<Long> = _sequencePositionMs
    private val _sequenceArmed = MutableStateFlow(false)
    override val sequenceArmed: StateFlow<Boolean> = _sequenceArmed

    override suspend fun initialize(): ProbeReport = withContext(Dispatchers.Default) {
        _state.value = EngineState(EnginePhase.INITIALIZING)
        val sel = CameraProber(manager).probe()
        probeReport = sel.report
        characteristics = sel.characteristics
        allChars = sel.rawCandidates

        _sensors.value = sel.rawCandidates.map { (id, ch) ->
            buildSensorInfo(id, ch, id in sel.hidden)
        }

        val defaultSensor = _sensors.value.firstOrNull()
        if (defaultSensor == null) {
            _state.value = EngineState(
                EnginePhase.ERROR,
                message = "No RAW_SENSOR access on any visible camera — see probe notes",
            )
            return@withContext sel.report
        }
        activeSensor = defaultSensor
        val size = defaultRawSize(defaultSensor)
        rawSize = Size(size.width, size.height)
        _settings.value = CaptureSettings(
            sensorId = defaultSensor.id,
            rawWidth = size.width,
            rawHeight = size.height,
            fps = defaultSensor.fpsOptions.filter { it <= 30 }.maxOrNull()
                ?: defaultSensor.fpsOptions.minOrNull() ?: 30,
        )
        nativeReady = initNative(defaultSensor, size)
        pushLook()
        // Define the WB uniform before the first CaptureResult arrives.
        // LookParams.wbGain already defaults to {1,1,1}; push explicitly here
        // to be the single obvious init point.
        NativePipeline.setWbGain(DEFAULT_WB_GAIN)
        sel.report
    }

    private fun buildSensorInfo(id: String, ch: CameraCharacteristics, hidden: Boolean): SensorInfo {
        val facing = when (ch.get(CameraCharacteristics.LENS_FACING)) {
            CameraMetadata.LENS_FACING_BACK -> "BACK"
            CameraMetadata.LENS_FACING_FRONT -> "FRONT"
            else -> "EXTERNAL"
        }
        val fps = (ch.get(CameraCharacteristics.CONTROL_AE_AVAILABLE_TARGET_FPS_RANGES) ?: emptyArray())
            .filter { it.lower == it.upper }.map { it.upper }.distinct().sorted()
        val isoRange = ch.get(CameraCharacteristics.SENSOR_INFO_SENSITIVITY_RANGE)
        val expRange = ch.get(CameraCharacteristics.SENSOR_INFO_EXPOSURE_TIME_RANGE)
        val caps = ch.get(CameraCharacteristics.REQUEST_AVAILABLE_CAPABILITIES) ?: IntArray(0)
        val focalLengths = ch.get(CameraCharacteristics.LENS_INFO_AVAILABLE_FOCAL_LENGTHS)
        val physicalSize = ch.get(CameraCharacteristics.SENSOR_INFO_PHYSICAL_SIZE)
        return SensorInfo(
            id = id,
            hidden = hidden,
            facing = facing,
            rawSizes = CameraProber(manager).rawSizes(ch).map { RawSize(it.width, it.height) },
            fpsOptions = fps.ifEmpty { listOf(30) },
            isoMin = isoRange?.lower ?: 100,
            isoMax = isoRange?.upper ?: 3200,
            exposureMinNs = expRange?.lower ?: 100_000L,
            exposureMaxNs = expRange?.upper ?: 100_000_000L,
            minFocusDiopters = ch.get(CameraCharacteristics.LENS_INFO_MINIMUM_FOCUS_DISTANCE) ?: 0f,
            hasManualSensor = caps.contains(CameraMetadata.REQUEST_AVAILABLE_CAPABILITIES_MANUAL_SENSOR),
            cfaPattern = ch.get(CameraCharacteristics.SENSOR_INFO_COLOR_FILTER_ARRANGEMENT) ?: 0,
            whiteLevel = ch.get(CameraCharacteristics.SENSOR_INFO_WHITE_LEVEL) ?: 1023,
            blackLevel = ch.get(CameraCharacteristics.SENSOR_BLACK_LEVEL_PATTERN)
                ?.let { p -> (0..3).map { p.getOffsetForIndex(it % 2, it / 2) }.average().toInt() }
                ?: 64,
            focalLengthMm = focalLengths?.firstOrNull() ?: 0f,
            sensorWidthMm = physicalSize?.width ?: 0f,
            sensorHeightMm = physicalSize?.height ?: 0f,
        )
    }

    /** Largest RAW size that still fits the ring comfortably (open gate, binned preferred). */
    private fun defaultRawSize(s: SensorInfo): RawSize {
        val fitting = s.rawSizes.filter { it.width.toLong() * it.height <= 4096L * 3072L }
        return fitting.maxByOrNull { it.width.toLong() * it.height }
            ?: s.rawSizes.minByOrNull { it.width.toLong() * it.height }
            ?: RawSize(4096, 3072)
    }

    private fun initNative(s: SensorInfo, size: RawSize): Boolean {
        val frameBytes = size.width.toLong() * size.height * 2
        if (frameBytes > MAX_FRAME_BYTES) {
            _state.value = _state.value.copy(message = "RAW $size too large for the ring buffer")
            return false
        }
        val slots = (512L * 1024 * 1024 / frameBytes).toInt().coerceIn(3, 8)
        val ok = NativePipeline.init(size.width, size.height, slots, s.whiteLevel, s.blackLevel, s.cfaPattern)
        Log.i(TAG, "Native: RAW $size white=${s.whiteLevel} black=${s.blackLevel} cfa=${s.cfaPattern} slots=$slots ok=$ok")
        return ok
    }

    @SuppressLint("MissingPermission")
    override suspend fun startStream(previewSurface: Surface?) {
        probeReport ?: error("initialize() first")
        previewSurface?.let { NativePipeline.setPreviewSurface(it) }
        openAndConfigure()
    }

    @SuppressLint("MissingPermission")
    private suspend fun openAndConfigure() {
        val report = probeReport ?: return
        val wanted = _settings.value.sensorId ?: report.selectedCameraId
        // Hidden physical ids may refuse to open for third-party apps on BBK
        // builds; walk down: selected id -> logical parent -> first logical.
        val fallbacks = buildList {
            add(wanted)
            report.physicalIds.entries.firstOrNull { wanted in it.value }?.let { add(it.key) }
            report.logicalIds.firstOrNull()?.let { add(it) }
        }.distinct()

        var lastErr: Exception? = null
        for (id in fallbacks) {
            try {
                val dev = openCamera(id)
                device = dev
                characteristics = allChars[id] ?: manager.getCameraCharacteristics(id)
                configureSession(dev)
                _state.value = EngineState(
                    if (recording) EnginePhase.RECORDING else EnginePhase.STREAMING,
                    cameraId = id,
                    rawWidth = rawSize.width,
                    rawHeight = rawSize.height,
                    message = if (id == wanted) null else "Fell back from $wanted to $id",
                )
                startStatsJob()
                return
            } catch (e: Exception) {
                lastErr = e
                Log.w(TAG, "open/configure $id failed", e)
                device?.close(); device = null
            }
        }
        _state.value = EngineState(EnginePhase.ERROR, message = "Camera open failed: $lastErr")
    }

    private suspend fun openCamera(id: String): CameraDevice =
        suspendCancellableCoroutine { cont ->
            manager.openCamera(id, camExecutor, object : CameraDevice.StateCallback() {
                override fun onOpened(camera: CameraDevice) {
                    if (cont.isActive) cont.resume(camera)
                }
                override fun onDisconnected(camera: CameraDevice) {
                    camera.close()
                    if (cont.isActive) cont.resumeWithException(IllegalStateException("disconnected"))
                    else onStreamLost("Camera disconnected")
                }
                override fun onError(camera: CameraDevice, error: Int) {
                    camera.close()
                    if (cont.isActive) cont.resumeWithException(IllegalStateException("open error $error"))
                    else onStreamLost("Camera error $error")
                }
            })
        }

    private fun onStreamLost(why: String) {
        session = null; device = null
        _state.value = EngineState(EnginePhase.ERROR, message = why)
    }

    private suspend fun configureSession(dev: CameraDevice) {
        rawReader?.close()
        val reader = ImageReader.newInstance(
            rawSize.width, rawSize.height, ImageFormat.RAW_SENSOR, /*maxImages=*/6,
        )
        reader.setOnImageAvailableListener({ r ->
            val img = r.acquireNextImage() ?: return@setOnImageAvailableListener
            try {
                val ts = img.timestamp
                lastTsNs = ts
                framesCaptured.incrementAndGet()
                if (recording && firstRecordedTsNs == 0L) firstRecordedTsNs = ts
                val plane = img.planes[0]
                NativePipeline.pushFrame(plane.buffer, plane.rowStride, ts)
            } finally {
                img.close()
            }
        }, frameHandler)
        rawReader = reader

        // The viewfinder renders from the RAW stream via GL, so no HAL preview
        // stream carries pixels. A small PRIVATE stream is still CONFIGURED
        // (never targeted by any request): without it the vivo HAL drops the
        // sensor into a ~20fps readout mode for RAW-only sessions.
        dummyReader?.close()
        val dummy = ImageReader.newInstance(1920, 1080, ImageFormat.PRIVATE, 2)
        dummyReader = dummy
        session = suspendCancellableCoroutine { cont ->
            val cfg = SessionConfiguration(
                SessionConfiguration.SESSION_REGULAR,
                listOf(OutputConfiguration(reader.surface), OutputConfiguration(dummy.surface)),
                camExecutor,
                object : CameraCaptureSession.StateCallback() {
                    override fun onConfigured(s: CameraCaptureSession) {
                        if (cont.isActive) cont.resume(s)
                    }
                    override fun onConfigureFailed(s: CameraCaptureSession) {
                        if (cont.isActive) cont.resumeWithException(IllegalStateException("session configure failed"))
                    }
                },
            )
            dev.createCaptureSession(cfg)
        }
        updateRepeating()
    }

    /** Rebuild + resubmit the repeating request from settings and ramp overrides. */
    private fun updateRepeating() {
        val dev = device ?: return
        val s = session ?: return
        try {
            s.setRepeatingRequest(buildRequest(dev), captureCallback, camHandler)
        } catch (e: Exception) {
            Log.w(TAG, "setRepeatingRequest failed", e)
        }
    }

    /**
     * Capture request from [CaptureSettings]: Process-Zero by default with
     * per-stage opt-in, manual exposure with hard CFR via frame duration, and
     * manual focus / zoom hooks used by the V3 ramps.
     */
    private fun buildRequest(dev: CameraDevice): CaptureRequest {
        val ch = characteristics!!
        val cfg = _settings.value
        val raw = rawReader!!.surface
        val b = dev.createCaptureRequest(CameraDevice.TEMPLATE_RECORD)
        b.addTarget(raw)

        fun supports(key: CameraCharacteristics.Key<IntArray>, mode: Int) =
            ch.get(key)?.contains(mode) == true

        fun setStage(
            availKey: CameraCharacteristics.Key<IntArray>,
            reqKey: CaptureRequest.Key<Int>,
            enabled: Boolean,
            onMode: Int,
            offMode: Int,
        ) {
            val mode = if (enabled) onMode else offMode
            if (supports(availKey, mode)) b.set(reqKey, mode)
        }

        val p = cfg.processing
        setStage(CameraCharacteristics.NOISE_REDUCTION_AVAILABLE_NOISE_REDUCTION_MODES,
            CaptureRequest.NOISE_REDUCTION_MODE, p.noiseReduction,
            CameraMetadata.NOISE_REDUCTION_MODE_FAST, CameraMetadata.NOISE_REDUCTION_MODE_OFF)
        setStage(CameraCharacteristics.EDGE_AVAILABLE_EDGE_MODES,
            CaptureRequest.EDGE_MODE, p.edgeEnhancement,
            CameraMetadata.EDGE_MODE_FAST, CameraMetadata.EDGE_MODE_OFF)
        setStage(CameraCharacteristics.SHADING_AVAILABLE_MODES,
            CaptureRequest.SHADING_MODE, p.lensShading,
            CameraMetadata.SHADING_MODE_FAST, CameraMetadata.SHADING_MODE_OFF)
        setStage(CameraCharacteristics.HOT_PIXEL_AVAILABLE_HOT_PIXEL_MODES,
            CaptureRequest.HOT_PIXEL_MODE, p.hotPixel,
            CameraMetadata.HOT_PIXEL_MODE_FAST, CameraMetadata.HOT_PIXEL_MODE_OFF)
        setStage(CameraCharacteristics.COLOR_CORRECTION_AVAILABLE_ABERRATION_MODES,
            CaptureRequest.COLOR_CORRECTION_ABERRATION_MODE, p.aberrationCorrection,
            CameraMetadata.COLOR_CORRECTION_ABERRATION_MODE_FAST,
            CameraMetadata.COLOR_CORRECTION_ABERRATION_MODE_OFF)
        setStage(CameraCharacteristics.DISTORTION_CORRECTION_AVAILABLE_MODES,
            CaptureRequest.DISTORTION_CORRECTION_MODE, p.distortionCorrection,
            CameraMetadata.DISTORTION_CORRECTION_MODE_FAST,
            CameraMetadata.DISTORTION_CORRECTION_MODE_OFF)
        if (p.forceIdentityTonemap &&
            supports(CameraCharacteristics.TONEMAP_AVAILABLE_TONE_MAP_MODES,
                CameraMetadata.TONEMAP_MODE_CONTRAST_CURVE)
        ) {
            b.set(CaptureRequest.TONEMAP_MODE, CameraMetadata.TONEMAP_MODE_CONTRAST_CURVE)
            val linear = floatArrayOf(0f, 0f, 1f, 1f)
            b.set(CaptureRequest.TONEMAP_CURVE, TonemapCurve(linear, linear, linear))
        }
        b.set(CaptureRequest.CONTROL_VIDEO_STABILIZATION_MODE,
            if (p.videoStabilization) CameraMetadata.CONTROL_VIDEO_STABILIZATION_MODE_ON
            else CameraMetadata.CONTROL_VIDEO_STABILIZATION_MODE_OFF)
        if (supports(CameraCharacteristics.STATISTICS_INFO_AVAILABLE_LENS_SHADING_MAP_MODES,
                CameraMetadata.STATISTICS_LENS_SHADING_MAP_MODE_ON)) {
            b.set(CaptureRequest.STATISTICS_LENS_SHADING_MAP_MODE,
                if (p.lensShading) CameraMetadata.STATISTICS_LENS_SHADING_MAP_MODE_ON
                else CameraMetadata.STATISTICS_LENS_SHADING_MAP_MODE_OFF)
        }

        // --- Exposure ---
        val sensor = activeSensor
        val manualOk = sensor?.hasManualSensor == true
        if (!cfg.exposure.auto && manualOk) {
            b.set(CaptureRequest.CONTROL_AE_MODE, CameraMetadata.CONTROL_AE_MODE_OFF)
            val frameNs = 1_000_000_000L / cfg.fps
            val iso = (dynIso ?: cfg.exposure.iso).coerceIn(sensor!!.isoMin, sensor.isoMax)
            val shutter = (dynShutterNs ?: cfg.exposure.effectiveShutterNs(cfg.fps))
                .coerceIn(sensor.exposureMinNs, minOf(sensor.exposureMaxNs, frameNs - 200_000L))
            b.set(CaptureRequest.SENSOR_SENSITIVITY, iso)
            b.set(CaptureRequest.SENSOR_EXPOSURE_TIME, shutter)
            // Hard CFR: lock the sensor readout cadence, no HAL fps drifting.
            b.set(CaptureRequest.SENSOR_FRAME_DURATION, frameNs)
        } else {
            b.set(CaptureRequest.CONTROL_AE_MODE, CameraMetadata.CONTROL_AE_MODE_ON)
            b.set(CaptureRequest.CONTROL_AE_TARGET_FPS_RANGE, Range(cfg.fps, cfg.fps))
        }

        // --- Focus ---
        val focus = dynFocus ?: cfg.focusDiopters
        if (focus >= 0f) {
            b.set(CaptureRequest.CONTROL_AF_MODE, CameraMetadata.CONTROL_AF_MODE_OFF)
            b.set(CaptureRequest.LENS_FOCUS_DISTANCE, focus)
        } else if (supports(CameraCharacteristics.CONTROL_AF_AVAILABLE_MODES,
                CameraMetadata.CONTROL_AF_MODE_CONTINUOUS_VIDEO)) {
            b.set(CaptureRequest.CONTROL_AF_MODE, CameraMetadata.CONTROL_AF_MODE_CONTINUOUS_VIDEO)
        }

        if (dynZoom != 1f) b.set(CaptureRequest.CONTROL_ZOOM_RATIO, dynZoom)

        // AWB runs independently of the manual/auto AE path above; force AUTO
        // explicitly (TEMPLATE_RECORD already defaults to it) so
        // COLOR_CORRECTION_GAINS is always populated for white balance.
        if (supports(CameraCharacteristics.CONTROL_AWB_AVAILABLE_MODES,
                CameraMetadata.CONTROL_AWB_MODE_AUTO)) {
            b.set(CaptureRequest.CONTROL_AWB_MODE, CameraMetadata.CONTROL_AWB_MODE_AUTO)
        }
        return b.build()
    }

    override suspend fun applySettings(new: CaptureSettings) = restartLock.withLock {
        val old = _settings.value
        val sensor = _sensors.value.firstOrNull { it.id == new.sensorId } ?: activeSensor
        var applied = new
        if (sensor != null && (new.rawWidth == 0 || new.rawHeight == 0 ||
                sensor.rawSizes.none { it.width == new.rawWidth && it.height == new.rawHeight })
        ) {
            val d = defaultRawSize(sensor)
            applied = applied.copy(rawWidth = d.width, rawHeight = d.height)
        }
        if (applied.rawWidth.toLong() * applied.rawHeight * 2 > MAX_FRAME_BYTES) {
            _state.value = _state.value.copy(
                message = "${applied.rawWidth}x${applied.rawHeight} exceeds the RAW ring budget")
            return
        }

        val needsRestart = applied.sensorId != old.sensorId ||
            applied.rawWidth != old.rawWidth || applied.rawHeight != old.rawHeight
        if (needsRestart && recording) {
            _state.value = _state.value.copy(message = "Stop recording before switching sensor/resolution")
            return
        }
        _settings.value = applied
        pushLook()

        if (needsRestart && _state.value.phase == EnginePhase.STREAMING) {
            stopStreamInternal()
            activeSensor = sensor
            characteristics = sensor?.let { allChars[it.id] } ?: characteristics
            rawSize = Size(applied.rawWidth, applied.rawHeight)
            nativeReady = sensor != null && initNative(sensor, RawSize(applied.rawWidth, applied.rawHeight))
            // Native init resets render-thread state; resend the look/IDT.
            pushLook()
            openAndConfigure()
        } else {
            if (sensor != null) activeSensor = sensor
            updateRepeating()
        }
    }

    override fun setPreviewSurface(surface: Surface?) {
        NativePipeline.setPreviewSurface(surface)
    }

    override fun setScopeConfig(config: ScopeConfig) {
        scopeConfig = config
        pushLook()
    }

    private fun pushLook() {
        val log = when (_settings.value.logProfile) {
            LogProfile.CINE_FLAT -> 0
            LogProfile.CINE_STD -> 1
            LogProfile.REC709 -> 2
            LogProfile.ACES_CCT -> 3
        }
        val sc = scopeConfig
        NativePipeline.setLook(
            log, sc.falseColor, sc.zebras, (sc.zebraHighIre / 100f).coerceIn(0.1f, 1f),
            sc.focusPeaking, sc.peakingGain, sc.waveform,
        )
        pushColorMatrix()
        pushProcessing()
    }

    /** Sensor IDT (camera RGB -> ACES AP1), or identity when disabled/unavailable. */
    private fun pushColorMatrix() {
        val matrix = if (_settings.value.acesIdt) computeIdtMatrix() else ColorMatrices.IDENTITY
        NativePipeline.setColorMatrix(matrix)
    }

    private fun pushProcessing() {
        val p = _settings.value.processing
        // Boolean toggles map to fixed shader amounts (sliders can expose these later).
        val sharpen = if (p.edgeEnhancement) 0.6f else 0f
        val denoise = if (p.noiseReduction) 0.5f else 0f
        NativePipeline.setProcessing(if (p.hotPixel) 1 else 0, sharpen, denoise, p.lensShading)
        if (!p.lensShading) NativePipeline.clearShadingMap()
    }

    private fun computeIdtMatrix(): FloatArray {
        val ch = characteristics ?: return ColorMatrices.IDENTITY
        val transform = ch.get(CameraCharacteristics.SENSOR_COLOR_TRANSFORM1)
            ?: ch.get(CameraCharacteristics.SENSOR_COLOR_TRANSFORM2)
        if (transform == null) {
            Log.w(TAG, "No SENSOR_COLOR_TRANSFORM available; IDT falls back to identity")
            return ColorMatrices.IDENTITY
        }
        val illuminant = ch.get(CameraCharacteristics.SENSOR_REFERENCE_ILLUMINANT1)?.toInt()
            ?: ch.get(CameraCharacteristics.SENSOR_REFERENCE_ILLUMINANT2)?.toInt()
        return ColorMatrices.buildIdtMatrix(colorTransformToRowMajor(transform), illuminant)
    }

    private fun colorTransformToRowMajor(t: ColorSpaceTransform): FloatArray {
        val m = FloatArray(9)
        for (row in 0..2) for (col in 0..2) m[row * 3 + col] = t.getElement(col, row).toFloat()
        return m
    }

    override fun getWaveform(): WaveformData? {
        val seq = NativePipeline.getWaveform(waveformBuf)
        if (seq < 0 || seq == lastWaveformSeq) return null
        lastWaveformSeq = seq
        return WaveformData(
            NativePipeline.WAVEFORM_COLS, NativePipeline.WAVEFORM_ROWS,
            waveformBuf.copyOf(), seq,
        )
    }

    // --- V3: ramps -------------------------------------------------------

    override fun startFocusPull(fromDiopters: Float, toDiopters: Float, durationMs: Long) {
        runRamp(durationMs) { t ->
            dynFocus = fromDiopters + (toDiopters - fromDiopters) * smooth(t)
        } onDone {
            dynFocus = null
            _settings.value = _settings.value.copy(focusDiopters = toDiopters)
        }
    }

    override fun startExposureRamp(toIso: Int, toShutterNs: Long, durationMs: Long) {
        val cfg = _settings.value
        val fromIso = (dynIso ?: cfg.exposure.iso).toDouble()
        val fromShutter = (dynShutterNs ?: cfg.exposure.effectiveShutterNs(cfg.fps)).toDouble()
        runRamp(durationMs) { t ->
            val e = smooth(t)
            // Geometric interpolation: perceptually linear exposure change.
            dynIso = (fromIso * Math.pow(toIso / fromIso, e.toDouble())).toInt()
            dynShutterNs = (fromShutter * Math.pow(toShutterNs / fromShutter, e.toDouble())).toLong()
        } onDone {
            dynIso = null; dynShutterNs = null
            _settings.value = _settings.value.copy(
                exposure = _settings.value.exposure.copy(auto = false, iso = toIso, shutterNs = toShutterNs))
        }
    }

    override fun startZoomRamp(fromRatio: Float, toRatio: Float, durationMs: Long) {
        runRamp(durationMs) { t ->
            dynZoom = fromRatio + (toRatio - fromRatio) * smooth(t)
        } onDone { /* keep final zoom in dynZoom */ }
    }

    override fun cancelRamps() {
        rampJob?.cancel()
        rampJob = null
    }

    override fun currentZoomRatio(): Float = dynZoom

    private class RampHandle(val job: Job)

    private fun runRamp(durationMs: Long, step: (Float) -> Unit): RampHandle {
        rampJob?.cancel()
        sequenceJob?.cancel()
        val job = scope.launch {
            val start = System.nanoTime()
            while (isActive) {
                val t = ((System.nanoTime() - start) / 1e6 / durationMs).toFloat()
                step(t.coerceAtMost(1f))
                updateRepeating()
                if (t >= 1f) break
                delay(33)
            }
        }
        rampJob = job
        return RampHandle(job)
    }

    private infix fun RampHandle.onDone(block: () -> Unit) {
        scope.launch {
            job.join()
            if (!job.isCancelled) {
                block()
                updateRepeating()
            }
        }
    }

    private fun smooth(t: Float): Float = t * t * (3f - 2f * t)

    // --- Step 2: multi-track sequences ------------------------------------

    override fun loadSequence(seq: Sequence?) {
        if (_sequenceTransport.value == SequenceTransport.RUNNING) stopSequence()
        _activeSequence.value = seq
    }

    override fun playSequence() {
        val seq = _activeSequence.value ?: return
        cancelRamps()
        sequenceJob?.cancel()
        _sequenceTransport.value = SequenceTransport.RUNNING
        val job = scope.launch {
            val start = System.nanoTime()
            while (isActive) {
                val elapsedMs = (System.nanoTime() - start) / 1_000_000L
                val pos = elapsedMs.coerceAtMost(seq.durationMs)
                _sequencePositionMs.value = pos
                applySequenceValues(seq, pos)
                updateRepeating()
                if (elapsedMs >= seq.durationMs) break
                delay(33)
            }
        }
        sequenceJob = job
        scope.launch {
            job.join()
            if (!job.isCancelled) {
                bakeSequenceFinal(seq)
                updateRepeating()
            }
            _sequenceTransport.value = SequenceTransport.IDLE
            _sequencePositionMs.value = 0L
        }
    }

    override fun stopSequence() {
        sequenceJob?.cancel()
        sequenceJob = null
    }

    override fun armSequence(armed: Boolean) {
        _sequenceArmed.value = armed
    }

    /** Evaluate every track in [seq] at [elapsedMs] and write the dyn* overrides. */
    private fun applySequenceValues(seq: Sequence, elapsedMs: Long) {
        val values = AutomationEngine.evaluate(seq, elapsedMs)
        values[AutoTrackKind.FOCUS]?.let { dynFocus = it.toFloat() }
        values[AutoTrackKind.ISO]?.let { dynIso = it.toInt() }
        values[AutoTrackKind.SHUTTER_NS]?.let { dynShutterNs = it.toLong() }
        values[AutoTrackKind.ZOOM]?.let { dynZoom = it.toFloat() }
    }

    /** Bake the final dyn* values a completed sequence produced into [_settings]. */
    private fun bakeSequenceFinal(seq: Sequence) {
        val kinds = seq.tracks.map { it.kind }.toSet()
        if (AutoTrackKind.FOCUS in kinds) {
            val f = dynFocus
            dynFocus = null
            if (f != null) _settings.value = _settings.value.copy(focusDiopters = f)
        }
        if (AutoTrackKind.ISO in kinds || AutoTrackKind.SHUTTER_NS in kinds) {
            val iso = dynIso
            val shutter = dynShutterNs
            dynIso = null; dynShutterNs = null
            val exp = _settings.value.exposure
            _settings.value = _settings.value.copy(
                exposure = exp.copy(
                    auto = false,
                    iso = iso ?: exp.iso,
                    shutterNs = shutter ?: exp.effectiveShutterNs(_settings.value.fps),
                ),
            )
        }
        // ZOOM has no CaptureSettings field; final value stays live in dynZoom,
        // matching startZoomRamp's onDone.
    }

    // --- Recording -------------------------------------------------------

    private fun startStatsJob() {
        statsJob?.cancel()
        statsJob = scope.launch {
            var lastCount = 0L
            var lastAt = System.nanoTime()
            while (isActive) {
                delay(500)
                val now = System.nanoTime()
                val count = framesCaptured.get()
                val fps = (count - lastCount) * 1e9f / (now - lastAt)
                lastCount = count; lastAt = now
                // While a DNG sequence is recording, the interesting drop/written
                // counters come from the DNG writer pool, not the video encoder.
                val dropped = if (!nativeReady) 0L
                    else if (dngActive) NativePipeline.dngFramesDropped() else NativePipeline.framesDropped()
                val encoded = if (!nativeReady) 0L
                    else if (dngActive) NativePipeline.dngFramesWritten() else NativePipeline.framesEncoded()
                if (count % 4 == 0L || recording) {
                    Log.i(TAG, "stats fps=%.1f cap=%d drop=%d enc=%d".format(fps, count, dropped, encoded))
                }
                _stats.value = StreamStats(
                    fps = fps,
                    framesCaptured = count,
                    framesDropped = dropped,
                    framesEncoded = encoded,
                    lastSensorTimestampNs = lastTsNs,
                )
            }
        }
    }

    override suspend fun startRecording(target: RecordingTarget) {
        check(_state.value.phase == EnginePhase.STREAMING) { "not streaming" }
        check(nativeReady) { "native pipeline not ready" }
        val cfg = _settings.value
        var ow: Int
        var oh: Int
        if (cfg.encodeFullRes) {
            ow = rawSize.width.and(0x7FFFFFFE)
            oh = rawSize.height.and(0x7FFFFFFE)
        } else {
            ow = (rawSize.width / 2).and(0x7FFFFFFE)
            oh = (rawSize.height / 2).and(0x7FFFFFFE)
        }
        firstRecordedTsNs = 0L
        recordingTarget = target
        var ok = withContext(Dispatchers.IO) {
            NativePipeline.startEncoder(
                target.videoFile.absolutePath, ow, oh, cfg.fps, cfg.bitrateMbps * 1_000_000,
                cfg.audioEnabled, cfg.codec.mime,
            )
        }
        if (!ok && cfg.encodeFullRes) {
            // Codec rejected full open-gate res; drop to half and retry.
            ow = (rawSize.width / 2).and(0x7FFFFFFE)
            oh = (rawSize.height / 2).and(0x7FFFFFFE)
            ok = withContext(Dispatchers.IO) {
                NativePipeline.startEncoder(
                    target.videoFile.absolutePath, ow, oh, cfg.fps, cfg.bitrateMbps * 1_000_000,
                    cfg.audioEnabled, cfg.codec.mime,
                )
            }
            if (ok) _state.value = _state.value.copy(message = "Full-res encode unsupported; using ${ow}x$oh")
        }
        if (!ok) {
            _state.value = _state.value.copy(message = "Encoder start failed")
            return
        }
        recording = true
        _state.value = _state.value.copy(phase = EnginePhase.RECORDING)
        if (cfg.audioEnabled) startAudioLevelsPolling()
        if (_sequenceArmed.value && _activeSequence.value != null) playSequence()
    }

    private fun startAudioLevelsPolling() {
        audioLevelsJob?.cancel()
        audioLevelsJob = scope.launch {
            while (isActive) {
                _audioLevels.value = NativePipeline.getAudioLevels()
                delay(100)
            }
        }
    }

    private fun stopAudioLevelsPolling() {
        audioLevelsJob?.cancel()
        audioLevelsJob = null
        _audioLevels.value = floatArrayOf(0f, 0f)
    }

    override suspend fun stopRecording(): RecordingResult? {
        if (!recording) return null
        if (_sequenceArmed.value && _sequenceTransport.value == SequenceTransport.RUNNING) stopSequence()
        recording = false
        stopAudioLevelsPolling()
        val target = recordingTarget ?: return null
        val frames = withContext(Dispatchers.IO) { NativePipeline.stopEncoder() }
        val durationMs = if (firstRecordedTsNs > 0) (lastTsNs - firstRecordedTsNs) / 1_000_000 else 0
        _state.value = _state.value.copy(phase = EnginePhase.STREAMING)
        recordingTarget = null
        return RecordingResult(
            videoFile = target.videoFile,
            gcsvFile = target.gcsvFile,
            frameCount = frames,
            durationMs = durationMs,
            imuSampleCount = 0, // filled in by the caller after MotionCapture.stopSession()
        )
    }

    override fun firstRecordedFrameTimestampNs(): Long = firstRecordedTsNs

    /**
     * Start a CinemaDNG image sequence: one uncompressed DNG per RAW frame
     * written into [dir] as `<stem>_NNNNNN.dng`. Mirrors [startRecording]'s
     * contract (must be STREAMING, sets [recording] so the ImageReader
     * callback anchors [firstRecordedTsNs] the same way for IMU sync) but
     * skips the video encoder entirely.
     */
    override fun startDngRecording(dir: File, stem: String): Boolean {
        check(_state.value.phase == EnginePhase.STREAMING) { "not streaming" }
        check(nativeReady) { "native pipeline not ready" }
        val sensor = activeSensor ?: return false
        val (colorMatrix1, illuminant1) = computeDngColorMatrix1()
        val gain = lastWbGain
        val neutral = floatArrayOf(
            if (gain[0] != 0f) 1f / gain[0] else 1f,
            if (gain[1] != 0f) 1f / gain[1] else 1f,
            if (gain[2] != 0f) 1f / gain[2] else 1f,
        )
        val model = "${Build.MODEL} OpenLumen"
        firstRecordedTsNs = 0L
        val ok = NativePipeline.startDngSequence(
            dir.absolutePath, stem, rawSize.width, rawSize.height, sensor.cfaPattern,
            sensor.blackLevel, sensor.whiteLevel, colorMatrix1, illuminant1, neutral, model,
        )
        if (ok) {
            dngActive = true
            recording = true
            _state.value = _state.value.copy(phase = EnginePhase.RECORDING)
        }
        return ok
    }

    /** Stop the DNG sequence (draining any still-queued frames). Returns frames written. */
    override suspend fun stopDngRecording(): Long {
        if (!dngActive) return 0
        recording = false
        dngActive = false
        val frames = withContext(Dispatchers.IO) { NativePipeline.stopDngSequence() }
        _state.value = _state.value.copy(phase = EnginePhase.STREAMING)
        return frames
    }

    /**
     * DNG's ColorMatrix1: the sensor's raw XYZ->camera transform (not the
     * display/ACES IDT [computeIdtMatrix] builds), plus the illuminant it was
     * characterized under. Identity + D65 if the sensor doesn't publish one.
     */
    private fun computeDngColorMatrix1(): Pair<FloatArray, Int> {
        val ch = characteristics
        val transform = ch?.get(CameraCharacteristics.SENSOR_COLOR_TRANSFORM1)
        if (ch == null || transform == null) {
            return ColorMatrices.IDENTITY to 21 // 21 = SENSOR_REFERENCE_ILLUMINANT1_D65
        }
        val illuminant = ch.get(CameraCharacteristics.SENSOR_REFERENCE_ILLUMINANT1)?.toInt() ?: 21
        return colorTransformToRowMajor(transform) to illuminant
    }

    private suspend fun stopStreamInternal() {
        cancelRamps()
        stopSequence()
        runCatching { session?.stopRepeating() }
        session?.close(); session = null
        closeDevice()
        rawReader?.close(); rawReader = null
        dummyReader?.close(); dummyReader = null
        statsJob?.cancel()
    }

    private suspend fun closeDevice() {
        val dev = device ?: return
        device = null
        // close() is async; give the HAL a beat so reopening doesn't race.
        dev.close()
        delay(150)
    }

    override suspend fun stopStream() {
        stopStreamInternal()
        _state.value = EngineState(EnginePhase.IDLE)
    }

    override fun close() {
        scope.launch {
            if (dngActive) stopDngRecording() else if (recording) stopRecording()
            stopStream()
            if (nativeReady) NativePipeline.release()
            camThread.quitSafely()
            frameThread.quitSafely()
        }
    }

    private companion object {
        const val TAG = "Camera2Engine"
        // 96 MB/frame cap (~48 MP RAW16) protects the ring allocation.
        const val MAX_FRAME_BYTES = 96L * 1024 * 1024
        val DEFAULT_WB_GAIN = floatArrayOf(1f, 1f, 1f)
    }
}
