package com.cinemacamera.camera

import android.view.Surface
import java.nio.ByteBuffer

/**
 * JNI facade over the C++ pipeline: preallocated RAW16 ring buffer (off the
 * JVM heap), a persistent GL render thread that debayers every frame once and
 * draws it to both the viewfinder (letterboxed, with scopes) and the HEVC
 * encoder input surface, plus a CPU waveform sampler.
 *
 * Threading contract: [pushFrame] is called from the single ImageReader
 * thread; everything else from the engine's coroutine context. All EGL/GL
 * work happens on the native render thread.
 */
object NativePipeline {

    const val WAVEFORM_COLS = 240
    const val WAVEFORM_ROWS = 128

    init {
        System.loadLibrary("cinemapipeline")
    }

    /**
     * First call allocates the ring and starts the render thread. Subsequent
     * calls reconfigure for a new sensor — only valid while the camera stream
     * is stopped.
     */
    external fun init(
        width: Int,
        height: Int,
        ringSlots: Int,
        whiteLevel: Int,
        blackLevel: Int,
        cfaPattern: Int,
    ): Boolean

    /** Copy one RAW16 frame into the ring. False = ring full, frame dropped. */
    external fun pushFrame(buffer: ByteBuffer, rowStrideBytes: Int, timestampNs: Long): Boolean

    /** Attach/detach the viewfinder surface (null detaches). */
    external fun setPreviewSurface(surface: Surface?)

    /**
     * Viewfinder + encode look. logProfile: 0 CINE_FLAT, 1 CINE_STD, 2 REC709,
     * 3 ACES_CCT. Scope overlays (falseColor/zebras/peaking) affect the
     * viewfinder only.
     */
    external fun setLook(
        logProfile: Int,
        falseColor: Boolean,
        zebras: Boolean,
        zebraHi: Float,
        peaking: Boolean,
        peakGain: Float,
        waveform: Boolean,
    )

    /**
     * IDT: row-major 3x3 applied to linear camera RGB right after debayer, on
     * both preview and encoder draws. 9 floats, identity = no color science.
     */
    external fun setColorMatrix(m: FloatArray)

    /**
     * Per-channel white-balance gain (R, G, B), applied right after debayer
     * and before [setColorMatrix]'s color matrix. Identity = {1,1,1}.
     */
    external fun setWbGain(gain: FloatArray)

    /**
     * Install a live grading LUT for the viewfinder only (never the encoder).
     * [data] is size*size*size*3 RGB floats in [0,1], R fastest-varying
     * (standard .cube ordering). Uploaded as a GL_TEXTURE_3D on the render
     * thread.
     */
    external fun setLut(data: FloatArray, size: Int)

    /** Disable the preview LUT. */
    external fun clearLut()

    /**
     * Shader-side processing toggles applied to both preview and encoder:
     * hotPixel (0/1) same-color-neighbor clamp, sharpen (0 = off) unsharp
     * amount, denoise (0..1) spatial blend, lensShading gates the uploaded
     * shading map (see [setShadingMap]).
     */
    external fun setProcessing(hotPixel: Int, sharpen: Float, denoise: Float, lensShading: Boolean)

    /** Upload a cols*rows*3 RGB per-pixel gain map for lens shading correction. */
    external fun setShadingMap(rgb: FloatArray, cols: Int, rows: Int)

    /** Disable lens shading correction. */
    external fun clearShadingMap()

    /**
     * Copy the latest waveform ([WAVEFORM_COLS] x [WAVEFORM_ROWS], row 0 =
     * 0 IRE) into [out]. Returns a sequence number; unchanged = no new data.
     */
    external fun getWaveform(out: ByteArray): Long

    /**
     * Start encode of the live stream using [codecMime] (e.g. "video/hevc" or
     * "video/avc"; falls back to HEVC natively if the requested codec is
     * unavailable on-device). When [audioEnabled] is true, a synced AAC-LC
     * audio track is captured and muxed alongside the video (muxer start is
     * deferred until both tracks are known); if the audio device fails to
     * open, the native side silently falls back to video-only and
     * [getAudioLevels] stays at zero.
     */
    external fun startEncoder(
        path: String,
        outWidth: Int,
        outHeight: Int,
        fps: Int,
        bitrateBps: Int,
        audioEnabled: Boolean,
        codecMime: String,
    ): Boolean

    /** Stop encode, finalize the MP4. Returns frames written. */
    external fun stopEncoder(): Long

    /** Peak audio level since the last call, [left, right], each in [0, 1]. */
    external fun getAudioLevels(): FloatArray

    external fun framesEncoded(): Long
    external fun framesDropped(): Long

    /**
     * Start CinemaDNG image-sequence recording: one uncompressed DNG per RAW
     * frame written into [dir] as `<stem>_NNNNNN.dng`, off the render thread
     * (a pooled writer pool + a few writer threads own the file I/O).
     * [colorMatrix1] is the raw sensor XYZ->camera transform (9 floats,
     * row-major — DNG's ColorMatrix1, not the display IDT), [illuminant1] is
     * the matching ANDROID_SENSOR_REFERENCE_ILLUMINANT1 value, and [neutral]
     * is AsShotNeutral (R, G, B), green-normalized. Fails if already running
     * a DNG sequence or the native pipeline hasn't been [init]ed.
     */
    external fun startDngSequence(
        dir: String,
        stem: String,
        width: Int,
        height: Int,
        cfaPattern: Int,
        blackLevel: Int,
        whiteLevel: Int,
        colorMatrix1: FloatArray,
        illuminant1: Int,
        neutral: FloatArray,
        cameraModel: String,
    ): Boolean

    /** Stop the DNG sequence, draining any still-queued frames. Returns frames written. */
    external fun stopDngSequence(): Long

    external fun dngFramesWritten(): Long
    external fun dngFramesDropped(): Long

    external fun release()
}
