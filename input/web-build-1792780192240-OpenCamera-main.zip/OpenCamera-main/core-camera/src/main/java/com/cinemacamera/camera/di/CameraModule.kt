package com.cinemacamera.camera.di

import com.cinemacamera.camera.Camera2Engine
import com.cinemacamera.camera.InternalTimecodeSource
import com.cinemacamera.domain.CameraEngine
import com.cinemacamera.domain.TimecodeSource
import dagger.Binds
import dagger.Module
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
abstract class CameraModule {
    @Binds
    @Singleton
    abstract fun bindCameraEngine(impl: Camera2Engine): CameraEngine

    @Binds
    @Singleton
    abstract fun bindTimecodeSource(impl: InternalTimecodeSource): TimecodeSource
}
