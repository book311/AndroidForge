package com.cinemacamera.camera

import android.os.SystemClock
import com.cinemacamera.domain.Timecode
import com.cinemacamera.domain.TimecodeMode
import com.cinemacamera.domain.TimecodeSource
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Device-clock timecode: time-of-day by default (wall clock, wraps at
 * midnight), or free-run from the moment this object was constructed
 * (roughly process start). No external genlock/BLE box support — see
 * [TimecodeSource] for the interface an external source would implement.
 */
@Singleton
class InternalTimecodeSource @Inject constructor() : TimecodeSource {

    @Volatile
    var mode: TimecodeMode = TimecodeMode.TIME_OF_DAY

    private val freeRunStartElapsedMs = SystemClock.elapsedRealtime()

    override fun currentTimecode(fps: Int): Timecode {
        val safeFps = fps.coerceAtLeast(1)
        val ms = when (mode) {
            TimecodeMode.TIME_OF_DAY -> System.currentTimeMillis() % MS_PER_DAY
            TimecodeMode.FREE_RUN -> SystemClock.elapsedRealtime() - freeRunStartElapsedMs
        }
        val totalSeconds = ms / 1000
        val hours = ((totalSeconds / 3600) % 24).toInt()
        val minutes = ((totalSeconds / 60) % 60).toInt()
        val seconds = (totalSeconds % 60).toInt()
        val frameMs = ms % 1000
        val frames = ((frameMs * safeFps) / 1000).toInt().coerceIn(0, safeFps - 1)
        return Timecode(hours, minutes, seconds, frames)
    }

    private companion object {
        const val MS_PER_DAY = 24L * 60 * 60 * 1000
    }
}
