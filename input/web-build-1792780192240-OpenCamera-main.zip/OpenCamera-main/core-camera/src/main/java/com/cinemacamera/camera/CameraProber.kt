package com.cinemacamera.camera

import android.graphics.ImageFormat
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.hardware.camera2.CameraMetadata
import android.util.Log
import com.cinemacamera.domain.ProbeReport

/**
 * Interrogates the BBK/MediaTek camera HAL: enumerates the public logical
 * cameras, the physical ids behind them, ids reachable only by direct
 * characteristics query (hidden from getCameraIdList on BBK builds), and any
 * vendor tags (com.vivo.*, com.mediatek.*) exposed on the selected camera.
 * Picks the best directly-openable RAW-capable sensor.
 */
class CameraProber(private val manager: CameraManager) {

    data class Selection(
        val report: ProbeReport,
        val characteristics: CameraCharacteristics?,
        /** Every RAW-capable id in ranked order (best first). */
        val rawCandidates: Map<String, CameraCharacteristics> = emptyMap(),
        val hidden: Set<String> = emptySet(),
    )

    fun probe(): Selection {
        val notes = mutableListOf<String>()
        val logicalIds = try {
            manager.cameraIdList.toList()
        } catch (e: Exception) {
            notes += "getCameraIdList failed: $e"
            emptyList()
        }

        val physicalIds = mutableMapOf<String, List<String>>()
        val allChars = mutableMapOf<String, CameraCharacteristics>()
        for (id in logicalIds) {
            runCatching {
                val ch = manager.getCameraCharacteristics(id)
                allChars[id] = ch
                val phys = ch.physicalCameraIds.toList()
                if (phys.isNotEmpty()) physicalIds[id] = phys
            }.onFailure { notes += "characteristics($id) failed: $it" }
        }

        // BBK/MTK builds usually hide physical sensors from the public list but
        // still serve getCameraCharacteristics for direct numeric ids.
        val hiddenIds = mutableListOf<String>()
        for (n in 0..63) {
            val id = n.toString()
            if (id in logicalIds) continue
            runCatching {
                val ch = manager.getCameraCharacteristics(id)
                hiddenIds += id
                allChars[id] = ch
            }
        }
        if (hiddenIds.isNotEmpty()) notes += "Hidden ids reachable: $hiddenIds"

        fun caps(ch: CameraCharacteristics): IntArray =
            ch.get(CameraCharacteristics.REQUEST_AVAILABLE_CAPABILITIES) ?: IntArray(0)

        fun hasRaw(ch: CameraCharacteristics): Boolean =
            caps(ch).contains(CameraMetadata.REQUEST_AVAILABLE_CAPABILITIES_RAW) &&
                rawSizes(ch).isNotEmpty()

        // Rank candidates: RAW capability required; prefer back-facing, then
        // largest RAW area. Hidden ids are candidates too — opening them may be
        // blocked by the OEM, so the engine falls back down this list.
        val ranked = allChars.entries
            .filter { hasRaw(it.value) }
            .sortedWith(
                compareByDescending<Map.Entry<String, CameraCharacteristics>> {
                    it.value.get(CameraCharacteristics.LENS_FACING) == CameraMetadata.LENS_FACING_BACK
                }.thenByDescending {
                    rawSizes(it.value).maxOfOrNull { s -> s.width.toLong() * s.height } ?: 0L
                }.thenBy { it.key in logicalIds } // prefer a direct physical id over the logical wrapper
            )

        if (ranked.isEmpty()) {
            notes += "NO RAW-capable camera visible to this app. Capabilities per id: " +
                allChars.entries.joinToString { "${it.key}=${caps(it.value).joinToString("/")}" }
        }

        val selectedId = ranked.firstOrNull()?.key ?: logicalIds.firstOrNull().orEmpty()
        val selected = allChars[selectedId]

        val vendorTags = selected?.let { ch ->
            (ch.keys.map { it.name } +
                (runCatching { ch.availableCaptureRequestKeys.map { it.name } }.getOrNull() ?: emptyList()) +
                (runCatching { ch.availableCaptureResultKeys.map { it.name } }.getOrNull() ?: emptyList()))
                .filter { !it.startsWith("android.") }
                .distinct()
                .sorted()
        } ?: emptyList()
        if (vendorTags.isNotEmpty()) notes += "Vendor tags on $selectedId: ${vendorTags.size}"

        val level = selected?.get(CameraCharacteristics.INFO_SUPPORTED_HARDWARE_LEVEL)?.let {
            when (it) {
                CameraMetadata.INFO_SUPPORTED_HARDWARE_LEVEL_LEGACY -> "LEGACY"
                CameraMetadata.INFO_SUPPORTED_HARDWARE_LEVEL_LIMITED -> "LIMITED"
                CameraMetadata.INFO_SUPPORTED_HARDWARE_LEVEL_FULL -> "FULL"
                CameraMetadata.INFO_SUPPORTED_HARDWARE_LEVEL_3 -> "LEVEL_3"
                CameraMetadata.INFO_SUPPORTED_HARDWARE_LEVEL_EXTERNAL -> "EXTERNAL"
                else -> it.toString()
            }
        } ?: "?"

        val tsSource = selected?.get(CameraCharacteristics.SENSOR_INFO_TIMESTAMP_SOURCE)?.let {
            if (it == CameraMetadata.SENSOR_INFO_TIMESTAMP_SOURCE_REALTIME) "REALTIME" else "UNKNOWN_CLOCK"
        } ?: "?"
        if (tsSource != "REALTIME") {
            notes += "Timestamp source is not REALTIME — gcsv/IMU sync will need an offset calibration."
        }

        val report = ProbeReport(
            logicalIds = logicalIds,
            physicalIds = physicalIds,
            hiddenIds = hiddenIds,
            selectedCameraId = selectedId,
            selectedIsPhysical = selectedId !in logicalIds,
            hardwareLevel = level,
            capabilities = selected?.let { caps(it).map(::capName) } ?: emptyList(),
            rawSizes = selected?.let { rawSizes(it).map { s -> "${s.width}x${s.height}" } } ?: emptyList(),
            fpsRanges = selected?.get(CameraCharacteristics.CONTROL_AE_AVAILABLE_TARGET_FPS_RANGES)
                ?.map { it.toString() } ?: emptyList(),
            timestampSource = tsSource,
            vendorTags = vendorTags,
            notes = notes,
        )
        Log.i(TAG, "Probe: $report")
        val rawCandidates = LinkedHashMap<String, CameraCharacteristics>()
        ranked.forEach { rawCandidates[it.key] = it.value }
        return Selection(report, selected, rawCandidates, hiddenIds.toSet())
    }

    fun rawSizes(ch: CameraCharacteristics) =
        ch.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP)
            ?.getOutputSizes(ImageFormat.RAW_SENSOR)?.toList() ?: emptyList()

    private fun capName(c: Int): String = when (c) {
        CameraMetadata.REQUEST_AVAILABLE_CAPABILITIES_RAW -> "RAW"
        CameraMetadata.REQUEST_AVAILABLE_CAPABILITIES_MANUAL_SENSOR -> "MANUAL_SENSOR"
        CameraMetadata.REQUEST_AVAILABLE_CAPABILITIES_MANUAL_POST_PROCESSING -> "MANUAL_POST"
        CameraMetadata.REQUEST_AVAILABLE_CAPABILITIES_BACKWARD_COMPATIBLE -> "BACKWARD_COMPAT"
        CameraMetadata.REQUEST_AVAILABLE_CAPABILITIES_LOGICAL_MULTI_CAMERA -> "LOGICAL_MULTI"
        CameraMetadata.REQUEST_AVAILABLE_CAPABILITIES_ULTRA_HIGH_RESOLUTION_SENSOR -> "ULTRA_HIGH_RES"
        else -> c.toString()
    }

    private companion object { const val TAG = "CameraProber" }
}
