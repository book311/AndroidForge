#include <jni.h>

#include <android/native_window.h>
#include <android/native_window_jni.h>

#include <atomic>
#include <chrono>
#include <cmath>
#include <condition_variable>
#include <cstring>
#include <mutex>
#include <thread>
#include <vector>

#include "audio_capture.h"
#include "dng_writer.h"
#include "encoder.h"
#include "gl_debayer.h"
#include "log_util.h"
#include "ring_buffer.h"

namespace {

constexpr int WF_COLS = 240;
constexpr int WF_ROWS = 128;

RingBuffer g_ring;
VideoEncoder g_encoder;
AudioCapture g_audio;
GlDebayer g_gl;
DngWriter g_dng;
std::thread g_renderThread;
std::atomic<bool> g_running{false};
std::atomic<bool> g_encoding{false};
std::atomic<bool> g_dngActive{false};
std::atomic<bool> g_audioEnabled{false};
std::atomic<int64_t> g_framesEncoded{0};
// Sensor timestamp (CLOCK_BOOTTIME ns) of the first encoded video frame, or
// -1 if encoding hasn't produced one yet. Written only by the render thread;
// read by the render thread (audio rebasing) and by stopEncoder()'s final
// audio flush, which runs on the JNI caller's thread after the render thread
// has already detached the encoder window (no concurrent writers by then).
std::atomic<int64_t> g_firstPts{-1};

// Commands handed to the render thread (EGL/GL state is thread-bound, so all
// surface + texture changes execute there, between frames).
std::mutex g_cmdM;
std::condition_variable g_ackCv;
ANativeWindow* g_pendingPreview = nullptr;
bool g_previewChange = false;
struct SrcCfg { int w = 0, h = 0, slots = 0; float black = 64, white = 1023; int cfa = 0; };
SrcCfg g_pendingSrc;
bool g_srcChange = false;
ANativeWindow* g_pendingEncWindow = nullptr;
int g_encW = 0, g_encH = 0;
bool g_encAttach = false, g_encDetach = false, g_encDetached = true;
bool g_resetPts = false;

struct PendingLut { std::vector<float> data; int size = 0; };
PendingLut g_pendingLut;
bool g_lutChange = false;
bool g_lutClear = false;

struct PendingShading { std::vector<float> data; int cols = 0, rows = 0; };
PendingShading g_pendingShading;
bool g_shadingChange = false;
bool g_shadingClear = false;

std::mutex g_lookM;
LookParams g_look;
std::atomic<bool> g_wfEnabled{false};

std::mutex g_wfM;
uint8_t g_wfBins[WF_COLS * WF_ROWS];
std::atomic<int64_t> g_wfSeq{0};

// Render-thread-local copy of the active source config (for the waveform).
SrcCfg g_src;

void computeWaveform(const uint8_t* raw, const SrcCfg& s) {
    static uint8_t local[WF_COLS * WF_ROWS];
    memset(local, 0, sizeof(local));
    const uint16_t* px = reinterpret_cast<const uint16_t*>(raw);
    // Green-pixel offset inside the 2x2 CFA cell.
    const int gx = (s.cfa == 0 || s.cfa == 3) ? 1 : 0;
    const float inv = 1.0f / (s.white - s.black > 0 ? s.white - s.black : 1.0f);
    const float logDen = log2f(s.white - s.black + 1.0f);
    const int rowsSampled = 96;
    for (int c = 0; c < WF_COLS; c++) {
        const int x = ((c * s.w / WF_COLS) & ~1) + gx;
        for (int r = 0; r < rowsSampled; r++) {
            const int y = (r * s.h / rowsSampled) & ~1;
            float v = ((float)px[(size_t)y * s.w + x] - s.black) * inv;
            v = v < 0 ? 0 : (v > 1 ? 1 : v);
            // Same differential flat-log the shader applies.
            float e = log2f(v * (s.white - s.black) + 1.0f) / logDen;
            int bin = (int)(e * (WF_ROWS - 1));
            uint8_t* cell = &local[(size_t)bin * WF_COLS + c];
            int nv = *cell + 40;
            *cell = nv > 255 ? 255 : (uint8_t)nv;
        }
    }
    {
        std::lock_guard<std::mutex> l(g_wfM);
        memcpy(g_wfBins, local, sizeof(g_wfBins));
    }
    g_wfSeq.fetch_add(1, std::memory_order_release);
}

// Pops whatever the audio capture thread has produced and feeds it to the
// video encoder: the AAC format (once, to add the muxer track) and any
// queued samples, rebased to the video's firstPts timebase. Called every
// render loop iteration while encoding audio, regardless of whether a video
// frame popped this tick, so the bounded AudioCapture queue never backs up
// during a ring stall.
void pumpAudio() {
    AMediaFormat* fmt = g_audio.takeFormat();
    if (fmt) {
        g_encoder.addAudioTrack(fmt);
        AMediaFormat_delete(fmt);
    }
    const int64_t fp = g_firstPts.load(std::memory_order_relaxed);
    AudioSample sample;
    while (g_audio.popSample(&sample)) {
        if (fp < 0) continue;  // pre-roll before the first encoded video frame
        const int64_t muxPtsUs = sample.ptsUs - fp / 1000;
        if (muxPtsUs < 0) continue;  // still pre-roll after rebasing
        g_encoder.writeAudioSample(sample.data.data(), sample.data.size(), muxPtsUs,
                                    sample.flags);
    }
}

void processCommands() {
    std::unique_lock<std::mutex> l(g_cmdM);
    if (g_srcChange) {
        SrcCfg cfg = g_pendingSrc;
        g_srcChange = false;
        l.unlock();
        g_ring.init(cfg.w, cfg.h, cfg.slots);
        g_gl.configureSource(cfg.w, cfg.h, cfg.black, cfg.white, cfg.cfa);
        g_src = cfg;
        l.lock();
    }
    if (g_previewChange) {
        ANativeWindow* w = g_pendingPreview;
        g_pendingPreview = nullptr;
        g_previewChange = false;
        l.unlock();
        g_gl.setPreviewWindow(w);
        l.lock();
    }
    if (g_encAttach) {
        ANativeWindow* w = g_pendingEncWindow;
        int ew = g_encW, eh = g_encH;
        g_encAttach = false;
        l.unlock();
        if (g_gl.setEncoderWindow(w, ew, eh)) {
            l.lock();
            g_encDetached = false;
        } else {
            g_encoding.store(false);
            l.lock();
        }
    }
    if (g_encDetach) {
        g_encDetach = false;
        l.unlock();
        g_gl.clearEncoderWindow();
        l.lock();
        g_encDetached = true;
        g_ackCv.notify_all();
    }
    if (g_resetPts) {
        g_firstPts.store(-1, std::memory_order_relaxed);
        g_resetPts = false;
    }
    if (g_lutChange) {
        PendingLut lut = std::move(g_pendingLut);
        g_pendingLut = PendingLut{};
        g_lutChange = false;
        l.unlock();
        g_gl.uploadLut(lut.data.data(), lut.size);
        l.lock();
    }
    if (g_lutClear) {
        g_lutClear = false;
        l.unlock();
        g_gl.clearLut();
        l.lock();
    }
    if (g_shadingChange) {
        PendingShading sh = std::move(g_pendingShading);
        g_pendingShading = PendingShading{};
        g_shadingChange = false;
        l.unlock();
        g_gl.uploadShadingMap(sh.data.data(), sh.cols, sh.rows);
        l.lock();
    }
    if (g_shadingClear) {
        g_shadingClear = false;
        l.unlock();
        g_gl.clearShadingMap();
        l.lock();
    }
}

void renderLoop() {
    if (!g_gl.initContext()) {
        LOGE("renderLoop: no GL context, preview/encode disabled");
        return;
    }
    int64_t frameIdx = 0;
    while (g_running.load(std::memory_order_acquire)) {
        processCommands();
        if (g_audioEnabled.load(std::memory_order_relaxed)) pumpAudio();
        uint8_t* data = nullptr;
        int64_t ts = 0;
        if (!g_ring.pop(&data, &ts, 50)) continue;

        const bool encodeThis = g_encoding.load(std::memory_order_acquire) && g_gl.hasEncoder();
        const bool dngThis = g_dngActive.load(std::memory_order_acquire);
        // The encoder/DNG writer has priority: shed the viewfinder draw when
        // the ring starts backing up so recording never drops below sensor rate.
        const bool drawPreviewThis = g_gl.hasPreview() && (!(encodeThis || dngThis) || g_ring.count() <= 2);
        if (drawPreviewThis || encodeThis || dngThis) {
            g_gl.uploadFrame(data);
            if (dngThis) g_dng.push(data);
            LookParams look;
            {
                std::lock_guard<std::mutex> l(g_lookM);
                look = g_look;
            }
            if (drawPreviewThis) g_gl.drawPreview(look);
            if (encodeThis) {
                int64_t fp = g_firstPts.load(std::memory_order_relaxed);
                if (fp < 0) {
                    fp = ts;
                    g_firstPts.store(fp, std::memory_order_relaxed);
                }
                if (g_gl.drawEncoder(look, ts - fp)) {
                    g_framesEncoded.fetch_add(1, std::memory_order_relaxed);
                }
                g_encoder.drain(false);
            }
        }
        if (g_wfEnabled.load(std::memory_order_relaxed) && (frameIdx % 3 == 0)) {
            computeWaveform(data, g_src);
        }
        g_ring.popDone();
        frameIdx++;
    }
    g_gl.destroyContext();
    LOGI("renderLoop: exited after %lld encoded frames", (long long)g_framesEncoded.load());
}

}  // namespace

extern "C" {

JNIEXPORT jboolean JNICALL
Java_com_cinemacamera_camera_NativePipeline_init(JNIEnv*, jobject, jint width, jint height,
                                                 jint ringSlots, jint whiteLevel,
                                                 jint blackLevel, jint cfaPattern) {
    SrcCfg cfg{width, height, ringSlots, (float)blackLevel, (float)whiteLevel, cfaPattern};
    if (!g_running.load()) {
        if (!g_ring.init(width, height, ringSlots)) return JNI_FALSE;
        {
            std::lock_guard<std::mutex> l(g_cmdM);
            g_pendingSrc = cfg;
            g_srcChange = true;  // render thread configures the texture once GL is up
        }
        g_running.store(true, std::memory_order_release);
        g_renderThread = std::thread(renderLoop);
        return JNI_TRUE;
    }
    // Reconfigure (sensor/size switch). Contract: camera stream is stopped, so
    // no pushFrame races the ring re-init on the render thread.
    std::lock_guard<std::mutex> l(g_cmdM);
    g_pendingSrc = cfg;
    g_srcChange = true;
    return JNI_TRUE;
}

JNIEXPORT jboolean JNICALL
Java_com_cinemacamera_camera_NativePipeline_pushFrame(JNIEnv* env, jobject, jobject buffer,
                                                      jint rowStrideBytes, jlong timestampNs) {
    auto* src = static_cast<uint8_t*>(env->GetDirectBufferAddress(buffer));
    if (!src) return JNI_FALSE;
    return g_ring.push(src, rowStrideBytes, timestampNs) ? JNI_TRUE : JNI_FALSE;
}

JNIEXPORT void JNICALL
Java_com_cinemacamera_camera_NativePipeline_setPreviewSurface(JNIEnv* env, jobject,
                                                              jobject surface) {
    ANativeWindow* window = surface ? ANativeWindow_fromSurface(env, surface) : nullptr;
    std::lock_guard<std::mutex> l(g_cmdM);
    if (g_pendingPreview) ANativeWindow_release(g_pendingPreview);
    g_pendingPreview = window;
    g_previewChange = true;
}

JNIEXPORT void JNICALL
Java_com_cinemacamera_camera_NativePipeline_setLook(JNIEnv*, jobject, jint logProfile,
                                                    jboolean falseColor, jboolean zebras,
                                                    jfloat zebraHi, jboolean peaking,
                                                    jfloat peakGain, jboolean waveform) {
    {
        std::lock_guard<std::mutex> l(g_lookM);
        g_look.logProfile = logProfile;
        g_look.falseColor = falseColor;
        g_look.zebras = zebras;
        g_look.zebraHi = zebraHi;
        g_look.peaking = peaking;
        g_look.peakGain = peakGain;
    }
    g_wfEnabled.store(waveform, std::memory_order_relaxed);
}

JNIEXPORT void JNICALL
Java_com_cinemacamera_camera_NativePipeline_setColorMatrix(JNIEnv* env, jobject, jfloatArray m) {
    if (env->GetArrayLength(m) < 9) return;
    jfloat* buf = env->GetFloatArrayElements(m, nullptr);
    {
        std::lock_guard<std::mutex> l(g_lookM);
        memcpy(g_look.colorMat, buf, sizeof(g_look.colorMat));
    }
    env->ReleaseFloatArrayElements(m, buf, JNI_ABORT);
}

JNIEXPORT void JNICALL
Java_com_cinemacamera_camera_NativePipeline_setWbGain(JNIEnv* env, jobject, jfloatArray g) {
    if (env->GetArrayLength(g) < 3) return;
    jfloat* buf = env->GetFloatArrayElements(g, nullptr);
    {
        std::lock_guard<std::mutex> l(g_lookM);
        memcpy(g_look.wbGain, buf, sizeof(g_look.wbGain));
    }
    env->ReleaseFloatArrayElements(g, buf, JNI_ABORT);
}

JNIEXPORT void JNICALL
Java_com_cinemacamera_camera_NativePipeline_setLut(JNIEnv* env, jobject, jfloatArray data,
                                                   jint size) {
    jsize len = env->GetArrayLength(data);
    jfloat* buf = env->GetFloatArrayElements(data, nullptr);
    {
        std::lock_guard<std::mutex> l(g_cmdM);
        g_pendingLut.data.assign(buf, buf + len);
        g_pendingLut.size = size;
        g_lutChange = true;
        g_lutClear = false;
    }
    env->ReleaseFloatArrayElements(data, buf, JNI_ABORT);
}

JNIEXPORT void JNICALL
Java_com_cinemacamera_camera_NativePipeline_clearLut(JNIEnv*, jobject) {
    std::lock_guard<std::mutex> l(g_cmdM);
    g_pendingLut.data.clear();
    g_lutChange = false;
    g_lutClear = true;
}

JNIEXPORT void JNICALL
Java_com_cinemacamera_camera_NativePipeline_setProcessing(JNIEnv*, jobject, jint hotPixel,
                                                          jfloat sharpen, jfloat denoise,
                                                          jboolean lensShading) {
    std::lock_guard<std::mutex> l(g_lookM);
    g_look.hotPixel = hotPixel;
    g_look.sharpen = sharpen;
    g_look.denoise = denoise;
    g_look.lensShadingOn = lensShading ? 1 : 0;
}

JNIEXPORT void JNICALL
Java_com_cinemacamera_camera_NativePipeline_setShadingMap(JNIEnv* env, jobject, jfloatArray data,
                                                          jint cols, jint rows) {
    jsize len = env->GetArrayLength(data);
    jfloat* buf = env->GetFloatArrayElements(data, nullptr);
    {
        std::lock_guard<std::mutex> l(g_cmdM);
        g_pendingShading.data.assign(buf, buf + len);
        g_pendingShading.cols = cols;
        g_pendingShading.rows = rows;
        g_shadingChange = true;
        g_shadingClear = false;
    }
    env->ReleaseFloatArrayElements(data, buf, JNI_ABORT);
}

JNIEXPORT void JNICALL
Java_com_cinemacamera_camera_NativePipeline_clearShadingMap(JNIEnv*, jobject) {
    std::lock_guard<std::mutex> l(g_cmdM);
    g_pendingShading.data.clear();
    g_shadingChange = false;
    g_shadingClear = true;
}

JNIEXPORT jlong JNICALL
Java_com_cinemacamera_camera_NativePipeline_getWaveform(JNIEnv* env, jobject, jbyteArray out) {
    if (env->GetArrayLength(out) < WF_COLS * WF_ROWS) return -1;
    int64_t seq = g_wfSeq.load(std::memory_order_acquire);
    std::lock_guard<std::mutex> l(g_wfM);
    env->SetByteArrayRegion(out, 0, WF_COLS * WF_ROWS,
                            reinterpret_cast<const jbyte*>(g_wfBins));
    return seq;
}

JNIEXPORT jboolean JNICALL
Java_com_cinemacamera_camera_NativePipeline_startEncoder(JNIEnv* env, jobject, jstring jpath,
                                                         jint outW, jint outH, jint fps,
                                                         jint bitrateBps, jboolean audioEnabled,
                                                         jstring jcodec) {
    if (g_encoding.load() || !g_running.load()) return JNI_FALSE;
    const char* path = env->GetStringUTFChars(jpath, nullptr);
    const char* codec = env->GetStringUTFChars(jcodec, nullptr);

    bool audioOk = false;
    if (audioEnabled) {
        audioOk = g_audio.start();
        if (!audioOk) {
            LOGW("Encoder: audio capture failed to start; recording video-only");
        }
    }

    bool ok = g_encoder.start(path, outW, outH, fps, bitrateBps, audioOk, codec);
    env->ReleaseStringUTFChars(jpath, path);
    env->ReleaseStringUTFChars(jcodec, codec);
    if (!ok) {
        if (audioOk) g_audio.stop();
        g_encoder.stop();
        return JNI_FALSE;
    }
    g_audioEnabled.store(audioOk, std::memory_order_release);
    g_framesEncoded.store(0);
    {
        std::lock_guard<std::mutex> l(g_cmdM);
        g_pendingEncWindow = g_encoder.inputWindow();
        g_encW = outW;
        g_encH = outH;
        g_encAttach = true;
        g_resetPts = true;
    }
    g_encoding.store(true, std::memory_order_release);
    return JNI_TRUE;
}

JNIEXPORT jlong JNICALL
Java_com_cinemacamera_camera_NativePipeline_stopEncoder(JNIEnv*, jobject) {
    if (!g_encoding.load()) return 0;
    g_encoding.store(false, std::memory_order_release);
    {
        std::unique_lock<std::mutex> l(g_cmdM);
        g_encDetach = true;
        g_ackCv.wait_for(l, std::chrono::milliseconds(1000), [] { return g_encDetached; });
    }
    if (g_audioEnabled.exchange(false)) {
        g_audio.stop();  // signal stop -> join capture thread (self-flushes its AAC encoder)
        pumpAudio();     // drain whatever's left in the audio queue into the muxer
    }
    return g_encoder.stop();  // existing video EOS drain + muxer stop
}

JNIEXPORT jfloatArray JNICALL
Java_com_cinemacamera_camera_NativePipeline_getAudioLevels(JNIEnv* env, jobject) {
    float l = 0.0f, r = 0.0f;
    g_audio.getLevels(&l, &r);
    jfloatArray arr = env->NewFloatArray(2);
    jfloat vals[2] = {l, r};
    env->SetFloatArrayRegion(arr, 0, 2, vals);
    return arr;
}

JNIEXPORT jlong JNICALL
Java_com_cinemacamera_camera_NativePipeline_framesEncoded(JNIEnv*, jobject) {
    return g_framesEncoded.load(std::memory_order_relaxed);
}

JNIEXPORT jlong JNICALL
Java_com_cinemacamera_camera_NativePipeline_framesDropped(JNIEnv*, jobject) {
    return g_ring.dropped();
}

JNIEXPORT jboolean JNICALL
Java_com_cinemacamera_camera_NativePipeline_startDngSequence(
        JNIEnv* env, jobject, jstring jdir, jstring jstem, jint width, jint height, jint cfa,
        jint black, jint white, jfloatArray jcolorMatrix1, jint illuminant1, jfloatArray jneutral,
        jstring jmodel) {
    if (g_dngActive.load() || !g_running.load()) return JNI_FALSE;
    if (env->GetArrayLength(jcolorMatrix1) < 9 || env->GetArrayLength(jneutral) < 3) return JNI_FALSE;

    const char* dir = env->GetStringUTFChars(jdir, nullptr);
    const char* stem = env->GetStringUTFChars(jstem, nullptr);
    const char* model = env->GetStringUTFChars(jmodel, nullptr);
    jfloat* colorMatrix1 = env->GetFloatArrayElements(jcolorMatrix1, nullptr);
    jfloat* neutral = env->GetFloatArrayElements(jneutral, nullptr);

    bool ok = g_dng.start(dir, stem, width, height, cfa, black, white, colorMatrix1, illuminant1,
                          neutral, model);

    env->ReleaseFloatArrayElements(jneutral, neutral, JNI_ABORT);
    env->ReleaseFloatArrayElements(jcolorMatrix1, colorMatrix1, JNI_ABORT);
    env->ReleaseStringUTFChars(jmodel, model);
    env->ReleaseStringUTFChars(jstem, stem);
    env->ReleaseStringUTFChars(jdir, dir);

    if (ok) g_dngActive.store(true, std::memory_order_release);
    return ok ? JNI_TRUE : JNI_FALSE;
}

JNIEXPORT jlong JNICALL
Java_com_cinemacamera_camera_NativePipeline_stopDngSequence(JNIEnv*, jobject) {
    if (!g_dngActive.load()) return 0;
    g_dngActive.store(false, std::memory_order_release);
    return g_dng.stop();
}

JNIEXPORT jlong JNICALL
Java_com_cinemacamera_camera_NativePipeline_dngFramesWritten(JNIEnv*, jobject) {
    return g_dng.framesWritten();
}

JNIEXPORT jlong JNICALL
Java_com_cinemacamera_camera_NativePipeline_dngFramesDropped(JNIEnv*, jobject) {
    return g_dng.dropped();
}

JNIEXPORT void JNICALL
Java_com_cinemacamera_camera_NativePipeline_release(JNIEnv* env, jobject obj) {
    if (g_encoding.load()) {
        Java_com_cinemacamera_camera_NativePipeline_stopEncoder(env, obj);
    }
    if (g_dngActive.load()) {
        Java_com_cinemacamera_camera_NativePipeline_stopDngSequence(env, obj);
    }
    g_running.store(false, std::memory_order_release);
    g_ring.wake();
    if (g_renderThread.joinable()) g_renderThread.join();
    g_ring.free();
}

}  // extern "C"
