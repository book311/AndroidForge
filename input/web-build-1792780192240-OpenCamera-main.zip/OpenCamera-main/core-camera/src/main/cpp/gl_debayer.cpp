#include "gl_debayer.h"

#include <android/native_window.h>

#include "log_util.h"

namespace {

const char* kVert = R"(#version 300 es
out vec2 vUv;
void main() {
    // Fullscreen triangle from gl_VertexID, no buffers needed.
    vec2 pos = vec2(float((gl_VertexID & 1) << 2) - 1.0,
                    float((gl_VertexID & 2) << 1) - 1.0);
    vUv = pos * 0.5 + 0.5;
    // Flip Y so row 0 (sensor top) lands at the top of the window.
    vUv.y = 1.0 - vUv.y;
    gl_Position = vec4(pos, 0.0, 1.0);
}
)";

const char* kFrag = R"(#version 300 es
precision highp float;
precision highp int;
precision highp usampler2D;
precision highp sampler3D;
uniform usampler2D uRaw;
uniform vec2 uRawSize;
uniform float uBlack;
uniform float uInvRange;
uniform float uRange;      // white - black: parameterizes the log curve per sensor
uniform int uCfa;
uniform int uLog;          // 0 CINE_FLAT, 1 CINE_STD, 2 REC709, 3 ACES_CCT
uniform int uFalseColor;
uniform int uZebra;
uniform float uZebraHi;
uniform int uPeak;
uniform float uPeakGain;
uniform vec3 uWbGain;     // per-channel white-balance gain, applied before uColorMat
uniform mat3 uColorMat;    // IDT: linear camera RGB -> working RGB, identity = off
uniform sampler3D uLut;
uniform int uLutEnabled;
uniform float uLutSize;
uniform int uHotPixel;
uniform float uSharpen;
uniform float uDenoise;
uniform int uShading;
uniform sampler2D uShadingMap;
in vec2 vUv;
out vec4 oColor;

float fetchRaw(ivec2 p) {
    p = clamp(p, ivec2(0), ivec2(uRawSize) - 1);
    return float(texelFetch(uRaw, p, 0).r);
}
float fetchPx(ivec2 p) {
    float v = fetchRaw(p);
    if (uHotPixel == 1) {
        // Same-color Bayer neighbors are 2 px away. Clamp true outliers
        // (hot/dead photosites) to the neighborhood range; leaves normal detail.
        float n0 = fetchRaw(p + ivec2(2, 0));
        float n1 = fetchRaw(p - ivec2(2, 0));
        float n2 = fetchRaw(p + ivec2(0, 2));
        float n3 = fetchRaw(p - ivec2(0, 2));
        float mx = max(max(n0, n1), max(n2, n3));
        float mn = min(min(n0, n1), min(n2, n3));
        v = clamp(v, mn, mx);
    }
    return (v - uBlack) * uInvRange;
}

vec3 decodeCell(ivec2 cell) {
    float p00 = fetchPx(cell);
    float p10 = fetchPx(cell + ivec2(1, 0));
    float p01 = fetchPx(cell + ivec2(0, 1));
    float p11 = fetchPx(cell + ivec2(1, 1));
    vec3 rgb;
    if (uCfa == 0)      rgb = vec3(p00, (p10 + p01) * 0.5, p11); // RGGB
    else if (uCfa == 1) rgb = vec3(p10, (p00 + p11) * 0.5, p01); // GRBG
    else if (uCfa == 2) rgb = vec3(p01, (p00 + p11) * 0.5, p10); // GBRG
    else                rgb = vec3(p11, (p10 + p01) * 0.5, p00); // BGGR
    return clamp(rgb, 0.0, 1.0);
}

float lumaAt(ivec2 cell) {
    vec3 c = decodeCell(cell);
    return dot(c, vec3(0.2126, 0.7152, 0.0722));
}

vec3 applyLog(vec3 x) {
    if (uLog == 0) {
        // Differential flat log: full sensor range mapped into [0,1].
        return clamp(log2(x * uRange + 1.0) / log2(uRange + 1.0), 0.0, 1.0);
    } else if (uLog == 1) {
        return clamp(log2(x * 255.0 + 1.0) * 0.125, 0.0, 1.0);
    } else if (uLog == 3) {
        // ACEScct piecewise encode.
        vec3 lo = 10.5402377416545 * x + 0.0729055341958355;
        vec3 hi = (log2(max(x, vec3(1e-10))) + 9.72) / 17.52;
        return clamp(mix(hi, lo, step(x, vec3(0.0078125))), 0.0, 1.0);
    }
    // Rec709 OETF (uLog == 2, default).
    vec3 lo = 4.5 * x;
    vec3 hi = 1.099 * pow(max(x, vec3(1e-6)), vec3(0.45)) - 0.099;
    return clamp(mix(hi, lo, step(x, vec3(0.018))), 0.0, 1.0);
}

vec3 falseColorMap(float e) {
    if (e < 0.025) return vec3(0.45, 0.0, 0.85);   // crushed blacks
    if (e < 0.10)  return vec3(0.10, 0.25, 0.95);  // deep shadow
    if (e >= 0.94) return vec3(1.0, 0.05, 0.05);   // clipping
    if (e >= 0.86) return vec3(1.0, 0.55, 0.05);   // near clip
    if (e >= 0.77) return vec3(1.0, 0.95, 0.10);   // highlights
    if (e > 0.52 && e < 0.60) return vec3(1.0, 0.55, 0.75); // skin key
    if (e > 0.38 && e < 0.45) return vec3(0.15, 0.85, 0.20); // 18% gray
    return vec3(e, e, e);
}

void main() {
    ivec2 cell = ivec2(vUv * uRawSize) & ivec2(~1);
    vec3 rgb = decodeCell(cell);
    if (uDenoise > 0.0 || uSharpen > 0.0) {
        vec3 na = decodeCell(cell + ivec2(2, 0));
        vec3 nb = decodeCell(cell - ivec2(2, 0));
        vec3 nc = decodeCell(cell + ivec2(0, 2));
        vec3 nd = decodeCell(cell - ivec2(0, 2));
        vec3 blur = (na + nb + nc + nd) * 0.25;
        if (uDenoise > 0.0) rgb = mix(rgb, blur, clamp(uDenoise, 0.0, 1.0));
        if (uSharpen > 0.0) rgb = clamp(rgb + uSharpen * (rgb - blur), 0.0, 1.0);
    }
    if (uShading == 1) {
        rgb = clamp(rgb * texture(uShadingMap, vUv).rgb, 0.0, 1.0);
    }
    rgb *= uWbGain;
    rgb = uColorMat * rgb;
    vec3 enc = applyLog(rgb);
    float eLuma = dot(enc, vec3(0.2126, 0.7152, 0.0722));
    vec3 outc = enc;

    if (uLutEnabled == 1) {
        vec3 coord = clamp(enc, 0.0, 1.0) * ((uLutSize - 1.0) / uLutSize) + (0.5 / uLutSize);
        outc = texture(uLut, coord).rgb;
    }
    if (uFalseColor == 1) {
        outc = falseColorMap(eLuma);
    }
    if (uZebra == 1 && eLuma >= uZebraHi) {
        float stripe = step(0.5, fract((gl_FragCoord.x + gl_FragCoord.y) / 14.0));
        outc = mix(outc, vec3(stripe), 0.85);
    }
    if (uPeak == 1) {
        float c = lumaAt(cell);
        float lap = abs(4.0 * c
                        - lumaAt(cell + ivec2(2, 0)) - lumaAt(cell - ivec2(2, 0))
                        - lumaAt(cell + ivec2(0, 2)) - lumaAt(cell - ivec2(0, 2)));
        float edge = smoothstep(0.10, 0.22, lap * uPeakGain);
        outc = mix(outc, vec3(1.0, 0.1, 0.1), edge);
    }
    oColor = vec4(outc, 1.0);
}
)";

}  // namespace

GLuint GlDebayer::compile(GLenum type, const char* src) {
    GLuint sh = glCreateShader(type);
    glShaderSource(sh, 1, &src, nullptr);
    glCompileShader(sh);
    GLint ok = 0;
    glGetShaderiv(sh, GL_COMPILE_STATUS, &ok);
    if (!ok) {
        char log[1024];
        glGetShaderInfoLog(sh, sizeof(log), nullptr, log);
        LOGE("GlDebayer: shader compile failed: %s", log);
        glDeleteShader(sh);
        return 0;
    }
    return sh;
}

bool GlDebayer::initContext() {
    display_ = eglGetDisplay(EGL_DEFAULT_DISPLAY);
    if (display_ == EGL_NO_DISPLAY || !eglInitialize(display_, nullptr, nullptr)) {
        LOGE("GlDebayer: eglInitialize failed");
        return false;
    }
    const EGLint cfgAttr[] = {
        EGL_RENDERABLE_TYPE, EGL_OPENGL_ES3_BIT,
        EGL_SURFACE_TYPE, EGL_WINDOW_BIT | EGL_PBUFFER_BIT,
        EGL_RED_SIZE, 8, EGL_GREEN_SIZE, 8, EGL_BLUE_SIZE, 8,
        EGL_RECORDABLE_ANDROID, 1,
        EGL_NONE,
    };
    EGLint numCfg = 0;
    if (!eglChooseConfig(display_, cfgAttr, &config_, 1, &numCfg) || numCfg == 0) {
        LOGE("GlDebayer: no recordable ES3 config");
        return false;
    }
    const EGLint ctxAttr[] = {EGL_CONTEXT_CLIENT_VERSION, 3, EGL_NONE};
    context_ = eglCreateContext(display_, config_, EGL_NO_CONTEXT, ctxAttr);
    const EGLint pbAttr[] = {EGL_WIDTH, 1, EGL_HEIGHT, 1, EGL_NONE};
    pbuffer_ = eglCreatePbufferSurface(display_, config_, pbAttr);
    if (context_ == EGL_NO_CONTEXT || pbuffer_ == EGL_NO_SURFACE ||
        !eglMakeCurrent(display_, pbuffer_, pbuffer_, context_)) {
        LOGE("GlDebayer: context init failed 0x%x", eglGetError());
        return false;
    }
    presentationTime_ = reinterpret_cast<PFNEGLPRESENTATIONTIMEANDROIDPROC>(
        eglGetProcAddress("eglPresentationTimeANDROID"));

    GLuint vs = compile(GL_VERTEX_SHADER, kVert);
    GLuint fs = compile(GL_FRAGMENT_SHADER, kFrag);
    if (!vs || !fs) return false;
    program_ = glCreateProgram();
    glAttachShader(program_, vs);
    glAttachShader(program_, fs);
    glLinkProgram(program_);
    glDeleteShader(vs);
    glDeleteShader(fs);
    GLint linked = 0;
    glGetProgramiv(program_, GL_LINK_STATUS, &linked);
    if (!linked) {
        char log[1024];
        glGetProgramInfoLog(program_, sizeof(log), nullptr, log);
        LOGE("GlDebayer: link failed: %s", log);
        return false;
    }
    glGenVertexArrays(1, &vao_);
    glUseProgram(program_);
    glUniform1i(glGetUniformLocation(program_, "uRaw"), 0);
    glUniform1i(glGetUniformLocation(program_, "uLut"), 1);
    glUniform1i(glGetUniformLocation(program_, "uShadingMap"), 2);
    uLog_ = glGetUniformLocation(program_, "uLog");
    uFalse_ = glGetUniformLocation(program_, "uFalseColor");
    uZebra_ = glGetUniformLocation(program_, "uZebra");
    uZebraHi_ = glGetUniformLocation(program_, "uZebraHi");
    uPeak_ = glGetUniformLocation(program_, "uPeak");
    uPeakGain_ = glGetUniformLocation(program_, "uPeakGain");
    uRange_ = glGetUniformLocation(program_, "uRange");
    uColorMat_ = glGetUniformLocation(program_, "uColorMat");
    uWbGain_ = glGetUniformLocation(program_, "uWbGain");
    uHotPixel_ = glGetUniformLocation(program_, "uHotPixel");
    uSharpen_  = glGetUniformLocation(program_, "uSharpen");
    uDenoise_  = glGetUniformLocation(program_, "uDenoise");
    uShading_  = glGetUniformLocation(program_, "uShading");
    uLutEnabled_ = glGetUniformLocation(program_, "uLutEnabled");
    uLutSize_ = glGetUniformLocation(program_, "uLutSize");
    glPixelStorei(GL_UNPACK_ALIGNMENT, 2);
    LOGI("GlDebayer: context ready");
    return true;
}

bool GlDebayer::configureSource(int rawW, int rawH, float blackLevel,
                                float whiteLevel, int cfaPattern) {
    rawW_ = rawW; rawH_ = rawH;
    black_ = blackLevel; white_ = whiteLevel; cfa_ = cfaPattern;
    if (texture_) { glDeleteTextures(1, &texture_); texture_ = 0; }
    glGenTextures(1, &texture_);
    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, texture_);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
    glTexStorage2D(GL_TEXTURE_2D, 1, GL_R16UI, rawW_, rawH_);

    glUseProgram(program_);
    glUniform2f(glGetUniformLocation(program_, "uRawSize"), (float)rawW_, (float)rawH_);
    glUniform1f(glGetUniformLocation(program_, "uBlack"), black_);
    float range = white_ - black_ > 0 ? white_ - black_ : 1.0f;
    glUniform1f(glGetUniformLocation(program_, "uInvRange"), 1.0f / range);
    glUniform1f(uRange_, range);
    glUniform1i(glGetUniformLocation(program_, "uCfa"), cfa_);
    LOGI("GlDebayer: source %dx%d cfa=%d black=%.0f white=%.0f",
         rawW_, rawH_, cfa_, black_, white_);
    return glGetError() == GL_NO_ERROR;
}

void GlDebayer::setPreviewWindow(ANativeWindow* window) {
    if (previewSurface_ != EGL_NO_SURFACE) {
        eglMakeCurrent(display_, pbuffer_, pbuffer_, context_);
        eglDestroySurface(display_, previewSurface_);
        previewSurface_ = EGL_NO_SURFACE;
    }
    if (previewWindow_) { ANativeWindow_release(previewWindow_); previewWindow_ = nullptr; }
    if (!window) return;
    previewWindow_ = window;  // already acquired by the caller
    previewSurface_ = eglCreateWindowSurface(display_, config_, window, nullptr);
    if (previewSurface_ == EGL_NO_SURFACE) {
        LOGE("GlDebayer: preview surface failed 0x%x", eglGetError());
        ANativeWindow_release(previewWindow_);
        previewWindow_ = nullptr;
    } else {
        LOGI("GlDebayer: preview attached");
    }
}

bool GlDebayer::setEncoderWindow(ANativeWindow* window, int outW, int outH) {
    clearEncoderWindow();
    outW_ = outW; outH_ = outH;
    encoderSurface_ = eglCreateWindowSurface(display_, config_, window, nullptr);
    if (encoderSurface_ == EGL_NO_SURFACE) {
        LOGE("GlDebayer: encoder surface failed 0x%x", eglGetError());
        return false;
    }
    return true;
}

void GlDebayer::clearEncoderWindow() {
    if (encoderSurface_ != EGL_NO_SURFACE) {
        eglMakeCurrent(display_, pbuffer_, pbuffer_, context_);
        eglDestroySurface(display_, encoderSurface_);
        encoderSurface_ = EGL_NO_SURFACE;
    }
}

void GlDebayer::uploadFrame(const uint8_t* raw16) {
    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, texture_);
    glTexSubImage2D(GL_TEXTURE_2D, 0, 0, 0, rawW_, rawH_, GL_RED_INTEGER,
                    GL_UNSIGNED_SHORT, raw16);
}

void GlDebayer::applyUniforms(const LookParams& look, bool scopes, bool allowLut) {
    glUseProgram(program_);
    glUniform1i(uLog_, look.logProfile);
    glUniform1i(uFalse_, scopes && look.falseColor ? 1 : 0);
    glUniform1i(uZebra_, scopes && look.zebras ? 1 : 0);
    glUniform1f(uZebraHi_, look.zebraHi);
    glUniform1i(uPeak_, scopes && look.peaking ? 1 : 0);
    glUniform1f(uPeakGain_, look.peakGain);
    // look.colorMat is row-major; glUniformMatrix3fv on GLES requires
    // transpose = GL_FALSE, so flip into column-major here.
    float colMajor[9];
    for (int r = 0; r < 3; r++)
        for (int c = 0; c < 3; c++)
            colMajor[c * 3 + r] = look.colorMat[r * 3 + c];
    glUniformMatrix3fv(uColorMat_, 1, GL_FALSE, colMajor);
    glUniform3fv(uWbGain_, 1, look.wbGain);
    glUniform1i(uHotPixel_, look.hotPixel);
    glUniform1f(uSharpen_, look.sharpen);
    glUniform1f(uDenoise_, look.denoise);
    const bool shadingOn = look.lensShadingOn && shadingCols_ > 0 && shadingRows_ > 0;
    glUniform1i(uShading_, shadingOn ? 1 : 0);
    if (shadingOn) {
        glActiveTexture(GL_TEXTURE2);
        glBindTexture(GL_TEXTURE_2D, shadingTex_);
    }
    const bool lutOn = allowLut && lutSize_ > 0;
    glUniform1i(uLutEnabled_, lutOn ? 1 : 0);
    if (lutOn) {
        glUniform1f(uLutSize_, (float)lutSize_);
        glActiveTexture(GL_TEXTURE1);
        glBindTexture(GL_TEXTURE_3D, lutTex_);
    }
}

bool GlDebayer::drawPreview(const LookParams& look) {
    if (previewSurface_ == EGL_NO_SURFACE) return false;
    if (!eglMakeCurrent(display_, previewSurface_, previewSurface_, context_)) {
        LOGE("GlDebayer: preview makeCurrent 0x%x", eglGetError());
        return false;
    }
    // Never block the encode path on display vsync.
    eglSwapInterval(display_, 0);
    EGLint sw = 0, sh = 0;
    eglQuerySurface(display_, previewSurface_, EGL_WIDTH, &sw);
    eglQuerySurface(display_, previewSurface_, EGL_HEIGHT, &sh);
    if (sw <= 0 || sh <= 0) return false;

    // Letterbox: the full open-gate frame, aspect-correct, no stretch.
    glClearColor(0.f, 0.f, 0.f, 1.f);
    glViewport(0, 0, sw, sh);
    glClear(GL_COLOR_BUFFER_BIT);
    float frameAspect = (float)rawW_ / (float)rawH_;
    float surfAspect = (float)sw / (float)sh;
    int vw = sw, vh = sh, vx = 0, vy = 0;
    if (surfAspect > frameAspect) {
        vw = (int)(sh * frameAspect); vx = (sw - vw) / 2;
    } else {
        vh = (int)(sw / frameAspect); vy = (sh - vh) / 2;
    }
    glViewport(vx, vy, vw, vh);

    applyUniforms(look, /*scopes=*/true, /*allowLut=*/true);
    glBindVertexArray(vao_);
    glDrawArrays(GL_TRIANGLES, 0, 3);
    if (!eglSwapBuffers(display_, previewSurface_)) {
        LOGE("GlDebayer: preview swap 0x%x", eglGetError());
        return false;
    }
    return true;
}

bool GlDebayer::drawEncoder(const LookParams& look, int64_t presentationTimeNs) {
    if (encoderSurface_ == EGL_NO_SURFACE) return false;
    if (!eglMakeCurrent(display_, encoderSurface_, encoderSurface_, context_)) {
        LOGE("GlDebayer: encoder makeCurrent 0x%x", eglGetError());
        return false;
    }
    glViewport(0, 0, outW_, outH_);
    applyUniforms(look, /*scopes=*/false, /*allowLut=*/false);
    glBindVertexArray(vao_);
    glDrawArrays(GL_TRIANGLES, 0, 3);
    if (presentationTime_) presentationTime_(display_, encoderSurface_, presentationTimeNs);
    if (!eglSwapBuffers(display_, encoderSurface_)) {
        LOGE("GlDebayer: encoder swap 0x%x", eglGetError());
        return false;
    }
    return true;
}

bool GlDebayer::uploadLut(const float* data, int size) {
    if (size <= 0 || !data) {
        clearLut();
        return false;
    }
    if (lutTex_) { glDeleteTextures(1, &lutTex_); lutTex_ = 0; }
    glGenTextures(1, &lutTex_);
    glActiveTexture(GL_TEXTURE1);
    glBindTexture(GL_TEXTURE_3D, lutTex_);
    glTexParameteri(GL_TEXTURE_3D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_3D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_3D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
    glTexParameteri(GL_TEXTURE_3D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
    glTexParameteri(GL_TEXTURE_3D, GL_TEXTURE_WRAP_R, GL_CLAMP_TO_EDGE);
    glTexImage3D(GL_TEXTURE_3D, 0, GL_RGB16F, size, size, size, 0, GL_RGB, GL_FLOAT, data);
    bool ok = glGetError() == GL_NO_ERROR;
    lutSize_ = ok ? size : 0;
    LOGI("GlDebayer: LUT upload size=%d ok=%d", size, ok);
    return ok;
}

void GlDebayer::clearLut() {
    if (lutTex_) { glDeleteTextures(1, &lutTex_); lutTex_ = 0; }
    lutSize_ = 0;
}

bool GlDebayer::uploadShadingMap(const float* rgb, int cols, int rows) {
    if (cols <= 0 || rows <= 0 || !rgb) { clearShadingMap(); return false; }
    if (shadingTex_) { glDeleteTextures(1, &shadingTex_); shadingTex_ = 0; }
    glGenTextures(1, &shadingTex_);
    glActiveTexture(GL_TEXTURE2);
    glBindTexture(GL_TEXTURE_2D, shadingTex_);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB16F, cols, rows, 0, GL_RGB, GL_FLOAT, rgb);
    bool ok = glGetError() == GL_NO_ERROR;
    shadingCols_ = ok ? cols : 0;
    shadingRows_ = ok ? rows : 0;
    LOGI("GlDebayer: shading map %dx%d ok=%d", cols, rows, ok);
    return ok;
}

void GlDebayer::clearShadingMap() {
    if (shadingTex_) { glDeleteTextures(1, &shadingTex_); shadingTex_ = 0; }
    shadingCols_ = shadingRows_ = 0;
}

void GlDebayer::destroyContext() {
    if (lutTex_) { glDeleteTextures(1, &lutTex_); lutTex_ = 0; }
    lutSize_ = 0;
    if (shadingTex_) { glDeleteTextures(1, &shadingTex_); shadingTex_ = 0; }
    shadingCols_ = shadingRows_ = 0;
    if (display_ != EGL_NO_DISPLAY) {
        eglMakeCurrent(display_, EGL_NO_SURFACE, EGL_NO_SURFACE, EGL_NO_CONTEXT);
        if (previewSurface_ != EGL_NO_SURFACE) eglDestroySurface(display_, previewSurface_);
        if (encoderSurface_ != EGL_NO_SURFACE) eglDestroySurface(display_, encoderSurface_);
        if (pbuffer_ != EGL_NO_SURFACE) eglDestroySurface(display_, pbuffer_);
        if (context_ != EGL_NO_CONTEXT) eglDestroyContext(display_, context_);
        eglTerminate(display_);
    }
    if (previewWindow_) { ANativeWindow_release(previewWindow_); previewWindow_ = nullptr; }
    display_ = EGL_NO_DISPLAY;
    previewSurface_ = encoderSurface_ = pbuffer_ = EGL_NO_SURFACE;
    context_ = EGL_NO_CONTEXT;
    program_ = texture_ = vao_ = 0;
}
