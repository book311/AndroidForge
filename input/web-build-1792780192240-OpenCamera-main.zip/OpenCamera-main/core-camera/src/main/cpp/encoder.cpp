#include "encoder.h"

#include <fcntl.h>
#include <unistd.h>

#include <android/native_window.h>

#include "log_util.h"

namespace {
constexpr int64_t kDequeueTimeoutUs = 0;
constexpr int64_t kEosTimeoutUs = 100000;
constexpr int32_t kColorFormatSurface = 0x7F000789;  // COLOR_FormatSurface
}  // namespace

bool VideoEncoder::start(const char* path, int width, int height, int fps, int bitrateBps,
                          bool audioEnabled, const char* mime) {
    audioEnabled_ = audioEnabled;
    muxerStarted_ = false;
    videoTrackAdded_ = false;
    audioTrackAdded_ = false;
    track_ = -1;
    audioTrack_ = -1;
    pendingSamples_.clear();

    codec_ = AMediaCodec_createEncoderByType(mime);
    if (!codec_) {
        LOGW("Encoder: no %s encoder, falling back to video/hevc", mime);
        mime = "video/hevc";
        codec_ = AMediaCodec_createEncoderByType(mime);
        if (!codec_) {
            LOGE("Encoder: no video/hevc encoder");
            return false;
        }
    }

    AMediaFormat* fmt = AMediaFormat_new();
    AMediaFormat_setString(fmt, AMEDIAFORMAT_KEY_MIME, mime);
    AMediaFormat_setInt32(fmt, AMEDIAFORMAT_KEY_WIDTH, width);
    AMediaFormat_setInt32(fmt, AMEDIAFORMAT_KEY_HEIGHT, height);
    AMediaFormat_setInt32(fmt, AMEDIAFORMAT_KEY_COLOR_FORMAT, kColorFormatSurface);
    AMediaFormat_setInt32(fmt, AMEDIAFORMAT_KEY_BIT_RATE, bitrateBps);
    AMediaFormat_setInt32(fmt, AMEDIAFORMAT_KEY_FRAME_RATE, fps);
    AMediaFormat_setInt32(fmt, AMEDIAFORMAT_KEY_I_FRAME_INTERVAL, 1);

    media_status_t st = AMediaCodec_configure(codec_, fmt, nullptr, nullptr,
                                              AMEDIACODEC_CONFIGURE_FLAG_ENCODE);
    AMediaFormat_delete(fmt);
    if (st != AMEDIA_OK) {
        LOGE("Encoder: configure failed %d (%dx%d @%d)", st, width, height, fps);
        return false;
    }

    st = AMediaCodec_createInputSurface(codec_, &window_);
    if (st != AMEDIA_OK || !window_) {
        LOGE("Encoder: createInputSurface failed %d", st);
        return false;
    }

    fd_ = open(path, O_CREAT | O_TRUNC | O_RDWR, 0644);
    if (fd_ < 0) {
        LOGE("Encoder: cannot open %s", path);
        return false;
    }
    muxer_ = AMediaMuxer_new(fd_, AMEDIAMUXER_OUTPUT_FORMAT_MPEG_4);
    if (!muxer_) {
        LOGE("Encoder: muxer create failed");
        return false;
    }

    st = AMediaCodec_start(codec_);
    if (st != AMEDIA_OK) {
        LOGE("Encoder: start failed %d", st);
        return false;
    }
    framesWritten_ = 0;
    LOGI("Encoder: %s %dx%d @%dfps %.0f Mbps -> %s", mime, width, height, fps,
         bitrateBps / 1e6, path);
    return true;
}

void VideoEncoder::drain(bool endOfStream) {
    if (!codec_) return;
    const int64_t timeout = endOfStream ? kEosTimeoutUs : kDequeueTimeoutUs;
    while (true) {
        AMediaCodecBufferInfo info;
        ssize_t idx = AMediaCodec_dequeueOutputBuffer(codec_, &info, timeout);
        if (idx == AMEDIACODEC_INFO_TRY_AGAIN_LATER) {
            if (!endOfStream) break;
            LOGW("Encoder: EOS drain timeout");
            break;
        } else if (idx == AMEDIACODEC_INFO_OUTPUT_FORMAT_CHANGED) {
            AMediaFormat* ofmt = AMediaCodec_getOutputFormat(codec_);
            track_ = AMediaMuxer_addTrack(muxer_, ofmt);
            AMediaFormat_delete(ofmt);
            videoTrackAdded_ = true;
            maybeStartMuxer();
        } else if (idx == AMEDIACODEC_INFO_OUTPUT_BUFFERS_CHANGED) {
            // ignore
        } else if (idx >= 0) {
            if ((info.flags & AMEDIACODEC_BUFFER_FLAG_CODEC_CONFIG) == 0 && info.size > 0) {
                size_t bufSize = 0;
                uint8_t* buf = AMediaCodec_getOutputBuffer(codec_, idx, &bufSize);
                if (buf && writeOrBuffer(track_, buf, info.size, info.presentationTimeUs,
                                          info.flags)) {
                    framesWritten_++;
                }
            }
            AMediaCodec_releaseOutputBuffer(codec_, idx, false);
            if (info.flags & AMEDIACODEC_BUFFER_FLAG_END_OF_STREAM) break;
        }
    }
}

bool VideoEncoder::addAudioTrack(AMediaFormat* fmt) {
    if (audioTrackAdded_ || !muxer_) return false;
    audioTrack_ = AMediaMuxer_addTrack(muxer_, fmt);
    audioTrackAdded_ = true;
    LOGI("Encoder: audio track added");
    maybeStartMuxer();
    return true;
}

void VideoEncoder::writeAudioSample(const uint8_t* data, size_t size, int64_t ptsUs,
                                     uint32_t flags) {
    if (!audioTrackAdded_) return;  // format always precedes samples; defensive no-op
    writeOrBuffer(audioTrack_, data, size, ptsUs, flags);
}

bool VideoEncoder::writeOrBuffer(ssize_t track, const uint8_t* data, size_t size, int64_t ptsUs,
                                  uint32_t flags) {
    if (muxerStarted_) {
        AMediaCodecBufferInfo info{};
        info.offset = 0;
        info.size = static_cast<int32_t>(size);
        info.presentationTimeUs = ptsUs;
        info.flags = flags;
        AMediaMuxer_writeSampleData(muxer_, track, data, &info);
        return true;
    }
    // Video-only path: identical to before this feature existed. The muxer
    // starts the instant the video FORMAT_CHANGED fires, so this branch is
    // only ever hit for the handful of buffers dequeued before that (none,
    // in practice — FORMAT_CHANGED is always the first output event).
    if (!audioEnabled_) return false;
    if (pendingSamples_.size() >= kMaxPending) {
        LOGW("Encoder: pending sample buffer full (%zu), dropping track=%zd sample",
             pendingSamples_.size(), track);
        return false;
    }
    pendingSamples_.push_back(PendingSample{track, std::vector<uint8_t>(data, data + size),
                                             ptsUs, flags});
    return true;
}

void VideoEncoder::maybeStartMuxer() {
    if (muxerStarted_ || !muxer_) return;
    if (!videoTrackAdded_) return;
    if (audioEnabled_ && !audioTrackAdded_) return;

    AMediaMuxer_start(muxer_);
    muxerStarted_ = true;
    for (auto& p : pendingSamples_) {
        AMediaCodecBufferInfo info{};
        info.offset = 0;
        info.size = static_cast<int32_t>(p.data.size());
        info.presentationTimeUs = p.ptsUs;
        info.flags = p.flags;
        AMediaMuxer_writeSampleData(muxer_, p.track, p.data.data(), &info);
    }
    LOGI("Encoder: muxer started, flushed %zu buffered samples", pendingSamples_.size());
    pendingSamples_.clear();
}

int64_t VideoEncoder::stop() {
    if (codec_) {
        AMediaCodec_signalEndOfInputStream(codec_);
        drain(true);
        AMediaCodec_stop(codec_);
        AMediaCodec_delete(codec_);
        codec_ = nullptr;
    }
    if (muxer_) {
        if (muxerStarted_) AMediaMuxer_stop(muxer_);
        AMediaMuxer_delete(muxer_);
        muxer_ = nullptr;
        muxerStarted_ = false;
    }
    if (fd_ >= 0) {
        close(fd_);
        fd_ = -1;
    }
    if (window_) {
        ANativeWindow_release(window_);
        window_ = nullptr;
    }
    if (!pendingSamples_.empty()) {
        LOGW("Encoder: stop() with %zu samples never flushed (muxer never fully started)",
             pendingSamples_.size());
        pendingSamples_.clear();
    }
    LOGI("Encoder: stopped, %lld frames written", static_cast<long long>(framesWritten_));
    return framesWritten_;
}
