#pragma once

#include <atomic>
#include <condition_variable>
#include <cstdint>
#include <deque>
#include <memory>
#include <mutex>
#include <string>
#include <thread>
#include <vector>

// Writes one uncompressed DNG (TIFF 1.4, single-strip CFA) per pushed RAW16
// frame into a per-take folder. push() is called from the render thread: it
// only grabs a free pool slot, memcpy's the frame in and enqueues an index —
// never touches the filesystem. A handful of writer threads do the blocking
// I/O. Frame order is preserved by assigning the file index at push() time
// (push() has a single caller), so files land in capture order on disk even
// though multiple threads write concurrently.
class DngWriter {
public:
    // Preallocates the frame pool, precomputes the DNG header once (fixed for
    // the life of this take — dimensions/CFA/color metadata don't change
    // mid-recording) and starts the writer threads.
    bool start(const char* dirPath, const char* stem, int width, int height, int cfaLayout,
               int blackLevel, int whiteLevel, const float colorMatrix1[9],
               int calibrationIlluminant1, const float asShotNeutral[3], const char* cameraModel);

    // Copies one frame into a free pool slot and enqueues it for a writer
    // thread. Returns false (and counts a drop) when the pool is exhausted.
    // Never blocks on I/O; the only allocation-free work happens here.
    bool push(const uint8_t* frame);

    // Signals shutdown, lets the writer threads fully drain the queue, joins
    // them, and frees the pool. Returns the number of frames written.
    int64_t stop();

    int64_t framesWritten() const { return framesWritten_.load(std::memory_order_relaxed); }
    int64_t dropped() const { return dropped_.load(std::memory_order_relaxed); }

private:
    void writerLoop();
    void buildHeader(int width, int height, int cfaLayout, int blackLevel, int whiteLevel,
                      const float colorMatrix1[9], int calibrationIlluminant1,
                      const float asShotNeutral[3], const char* cameraModel);

    static constexpr int kWriterThreads = 3;

    std::string dir_;
    std::string stem_;
    size_t frameBytes_ = 0;
    std::vector<uint8_t> header_;

    std::vector<std::unique_ptr<uint8_t[]>> pool_;

    struct QueuedFrame {
        int slot;
        int64_t index;
    };

    std::mutex m_;
    std::condition_variable cv_;
    std::vector<int> freeSlots_;
    std::deque<QueuedFrame> queue_;
    bool shuttingDown_ = false;

    std::atomic<int64_t> nextIndex_{0};
    std::atomic<int64_t> framesWritten_{0};
    std::atomic<int64_t> dropped_{0};

    std::vector<std::thread> writers_;
};
