#include "ring_buffer.h"

#include <chrono>
#include <cstring>

#include "log_util.h"

bool RingBuffer::init(int width, int height, int slots) {
    free();
    width_ = width;
    height_ = height;
    slots_ = slots;
    frameBytes_ = static_cast<size_t>(width) * height * 2;
    buf_.resize(slots);
    ts_.assign(slots, 0);
    for (int i = 0; i < slots; i++) {
        buf_[i].reset(new (std::nothrow) uint8_t[frameBytes_]);
        if (!buf_[i]) {
            LOGE("RingBuffer: OOM at slot %d (%zu bytes each)", i, frameBytes_);
            free();
            return false;
        }
    }
    head_ = tail_ = count_ = 0;
    LOGI("RingBuffer: %d slots x %zu MB", slots, frameBytes_ / (1024 * 1024));
    return true;
}

void RingBuffer::clear() {
    std::lock_guard<std::mutex> l(m_);
    head_ = tail_ = count_ = 0;
    dropped_.store(0);
}

void RingBuffer::free() {
    std::lock_guard<std::mutex> l(m_);
    buf_.clear();
    ts_.clear();
    head_ = tail_ = count_ = 0;
    slots_ = 0;
}

bool RingBuffer::push(const uint8_t* src, int rowStrideBytes, int64_t timestampNs) {
    int slot;
    {
        std::lock_guard<std::mutex> l(m_);
        if (slots_ == 0) return false;
        if (count_ == slots_) {
            dropped_.fetch_add(1, std::memory_order_relaxed);
            return false;
        }
        slot = head_;
    }
    uint8_t* dst = buf_[slot].get();
    const int rowBytes = width_ * 2;
    if (rowStrideBytes == rowBytes) {
        memcpy(dst, src, frameBytes_);
    } else {
        for (int y = 0; y < height_; y++) {
            memcpy(dst + static_cast<size_t>(y) * rowBytes,
                   src + static_cast<size_t>(y) * rowStrideBytes, rowBytes);
        }
    }
    {
        std::lock_guard<std::mutex> l(m_);
        ts_[slot] = timestampNs;
        head_ = (head_ + 1) % slots_;
        count_++;
    }
    cv_.notify_one();
    return true;
}

bool RingBuffer::pop(uint8_t** data, int64_t* timestampNs, int timeoutMs) {
    std::unique_lock<std::mutex> l(m_);
    if (!cv_.wait_for(l, std::chrono::milliseconds(timeoutMs), [this] { return count_ > 0; })) {
        return false;
    }
    *data = buf_[tail_].get();
    *timestampNs = ts_[tail_];
    return true;
}

void RingBuffer::popDone() {
    std::lock_guard<std::mutex> l(m_);
    if (count_ > 0) {
        tail_ = (tail_ + 1) % slots_;
        count_--;
    }
}

void RingBuffer::wake() { cv_.notify_all(); }

int RingBuffer::count() {
    std::lock_guard<std::mutex> l(m_);
    return count_;
}
