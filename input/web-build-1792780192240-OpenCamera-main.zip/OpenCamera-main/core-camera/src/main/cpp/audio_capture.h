#pragma once

#include <atomic>
#include <cstdint>
#include <mutex>
#include <thread>
#include <vector>

#include <media/NdkMediaCodec.h>
#include <media/NdkMediaFormat.h>

// One encoded AAC access unit, ready for AMediaMuxer_writeSampleData once
// rebased against the video firstPts. ptsUs is in the same CLOCK_BOOTTIME
// timebase as the video sensor timestamps (µs instead of ns because that's
// what AMediaCodec presentation times use).
struct AudioSample {
    std::vector<uint8_t> data;
    int64_t ptsUs = 0;
    uint32_t flags = 0;
};

// Owns an AAudio input stream, a dedicated capture thread, and the AMediaCodec
// AAC-LC encoder that thread feeds. Everything here runs off the render
// thread: the render thread only calls takeFormat()/popSample()/getLevels().
// This class NEVER touches the muxer.
class AudioCapture {
public:
    // Opens the AAudio stream (48kHz stereo PCM16) + the AAC encoder and
    // starts the capture thread. Returns false if either failed to open, in
    // which case the caller should fall back to video-only recording; stop()
    // is still safe to call afterward.
    bool start();

    // Signals the capture thread to stop, joins it (the thread flushes its
    // own encoder with an EOS before exiting), then tears down the codec and
    // the AAudio stream. Safe to call even if start() was never called or
    // failed.
    void stop();

    // Pops the AAC output format once the encoder has produced it (mirrors
    // the video encoder's FORMAT_CHANGED event). Returns nullptr if not
    // ready yet or already taken. Caller owns the result and must
    // AMediaFormat_delete it.
    AMediaFormat* takeFormat();

    // Pops one encoded sample if available. Returns false if the queue is
    // empty. Safe to call after stop() to drain whatever is left.
    bool popSample(AudioSample* out);

    // Peak |sample|/32767 per channel since the last call, then resets both
    // to 0. Cheap enough to call from a UI-polling JNI thread.
    void getLevels(float* outLeft, float* outRight);

private:
    void captureLoop();
    void drainEncoder(bool endOfStream);
    // data == nullptr with eos == true signals end-of-stream with no payload.
    void queuePcm(const uint8_t* data, size_t bytes, int64_t ptsUs, bool eos);

    void* stream_ = nullptr;  // AAudioStream*, opaque here to avoid pulling <aaudio/AAudio.h> into every TU
    AMediaCodec* codec_ = nullptr;

    std::thread thread_;
    std::atomic<bool> running_{false};

    std::mutex formatM_;
    AMediaFormat* pendingFormat_ = nullptr;

    std::mutex queueM_;
    std::vector<AudioSample> queue_;
    static constexpr size_t kMaxQueue = 256;

    std::atomic<float> peakL_{0.0f};
    std::atomic<float> peakR_{0.0f};

    int64_t totalFramesRead_ = 0;
    int64_t anchorNs_ = -1;
};
