#pragma once

#include <cstdint>
#include <vector>

#include <media/NdkMediaCodec.h>
#include <media/NdkMediaFormat.h>
#include <media/NdkMediaMuxer.h>

struct ANativeWindow;

// HEVC surface-input encoder + MP4 muxer, all NDK (no JVM involvement on the
// hot path). Presentation timestamps come from eglPresentationTimeANDROID.
//
// When audio is enabled, muxer start is deferred until both the video and
// audio tracks have been added (MediaMuxer requires every track to be added
// before start()). Whatever samples arrive in the meantime are buffered
// (bounded) and flushed in arrival order once the muxer actually starts.
class VideoEncoder {
public:
    bool start(const char* path, int width, int height, int fps, int bitrateBps,
               bool audioEnabled, const char* mime);
    ANativeWindow* inputWindow() { return window_; }

    // Pump any pending video output packets into the muxer (or the pending
    // buffer, if the muxer hasn't started yet). Call after every frame.
    void drain(bool endOfStream);

    // Adds the audio track from the AAC encoder's output format. Only valid
    // to call once; safe to call from a thread other than the one calling
    // drain(), as long as they don't race (the native render thread owns
    // both in practice).
    bool addAudioTrack(AMediaFormat* fmt);

    // Writes (or buffers, pre-muxer-start) one AAC access unit.
    void writeAudioSample(const uint8_t* data, size_t size, int64_t ptsUs, uint32_t flags);

    // Signal EOS, drain, finalize the file. Returns frames written.
    int64_t stop();

    int64_t framesWritten() const { return framesWritten_; }

private:
    // Writes to the muxer if it's started; otherwise buffers (bounded) for
    // replay once maybeStartMuxer() flips muxerStarted_. Returns whether the
    // sample was accepted (written or buffered) vs. dropped.
    bool writeOrBuffer(ssize_t track, const uint8_t* data, size_t size, int64_t ptsUs,
                        uint32_t flags);
    void maybeStartMuxer();

    struct PendingSample {
        ssize_t track;
        std::vector<uint8_t> data;
        int64_t ptsUs;
        uint32_t flags;
    };

    AMediaCodec* codec_ = nullptr;
    AMediaMuxer* muxer_ = nullptr;
    ANativeWindow* window_ = nullptr;
    int fd_ = -1;
    ssize_t track_ = -1;
    ssize_t audioTrack_ = -1;
    bool muxerStarted_ = false;
    bool videoTrackAdded_ = false;
    bool audioTrackAdded_ = false;
    bool audioEnabled_ = false;
    int64_t framesWritten_ = 0;

    std::vector<PendingSample> pendingSamples_;
    static constexpr size_t kMaxPending = 256;
};
