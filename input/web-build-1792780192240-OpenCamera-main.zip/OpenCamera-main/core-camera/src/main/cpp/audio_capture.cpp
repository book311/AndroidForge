#include "audio_capture.h"

#include <aaudio/AAudio.h>
#include <time.h>

#include <algorithm>
#include <cmath>
#include <cstring>

#include "log_util.h"

namespace {
constexpr int32_t kSampleRate = 48000;
constexpr int32_t kChannelCount = 2;
constexpr int32_t kBitrateBps = 256000;
// ~20ms chunks, per spec.
constexpr int32_t kChunkFrames = kSampleRate * 20 / 1000;
constexpr int64_t kDequeueTimeoutUs = 0;
constexpr int64_t kEosTimeoutUs = 100000;
constexpr int32_t kAacObjectLC = 2;  // AMediaCodecInfo.CodecProfileLevel.AACObjectLC

int64_t nowBootNs() {
    struct timespec ts {};
    clock_gettime(CLOCK_BOOTTIME, &ts);
    return static_cast<int64_t>(ts.tv_sec) * 1000000000LL + ts.tv_nsec;
}
}  // namespace

bool AudioCapture::start() {
    AAudioStreamBuilder* builder = nullptr;
    if (AAudio_createStreamBuilder(&builder) != AAUDIO_OK || !builder) {
        LOGE("AudioCapture: createStreamBuilder failed");
        return false;
    }
    AAudioStreamBuilder_setDirection(builder, AAUDIO_DIRECTION_INPUT);
    AAudioStreamBuilder_setSampleRate(builder, kSampleRate);
    AAudioStreamBuilder_setChannelCount(builder, kChannelCount);
    AAudioStreamBuilder_setFormat(builder, AAUDIO_FORMAT_PCM_I16);
    AAudioStreamBuilder_setPerformanceMode(builder, AAUDIO_PERFORMANCE_MODE_NONE);
    AAudioStreamBuilder_setSharingMode(builder, AAUDIO_SHARING_MODE_SHARED);

    AAudioStream* stream = nullptr;
    aaudio_result_t ares = AAudioStreamBuilder_openStream(builder, &stream);
    AAudioStreamBuilder_delete(builder);
    if (ares != AAUDIO_OK || !stream) {
        LOGE("AudioCapture: openStream failed %d (%s)", ares, AAudio_convertResultToText(ares));
        return false;
    }
    stream_ = stream;

    codec_ = AMediaCodec_createEncoderByType("audio/mp4a-latm");
    if (!codec_) {
        LOGE("AudioCapture: no AAC encoder available");
        AAudioStream_close(stream);
        stream_ = nullptr;
        return false;
    }

    AMediaFormat* fmt = AMediaFormat_new();
    AMediaFormat_setString(fmt, AMEDIAFORMAT_KEY_MIME, "audio/mp4a-latm");
    AMediaFormat_setInt32(fmt, AMEDIAFORMAT_KEY_SAMPLE_RATE, kSampleRate);
    AMediaFormat_setInt32(fmt, AMEDIAFORMAT_KEY_CHANNEL_COUNT, kChannelCount);
    AMediaFormat_setInt32(fmt, AMEDIAFORMAT_KEY_BIT_RATE, kBitrateBps);
    AMediaFormat_setInt32(fmt, AMEDIAFORMAT_KEY_AAC_PROFILE, kAacObjectLC);
    media_status_t st = AMediaCodec_configure(codec_, fmt, nullptr, nullptr,
                                              AMEDIACODEC_CONFIGURE_FLAG_ENCODE);
    AMediaFormat_delete(fmt);
    if (st != AMEDIA_OK) {
        LOGE("AudioCapture: AAC configure failed %d", st);
        AMediaCodec_delete(codec_);
        codec_ = nullptr;
        AAudioStream_close(stream);
        stream_ = nullptr;
        return false;
    }

    st = AMediaCodec_start(codec_);
    if (st != AMEDIA_OK) {
        LOGE("AudioCapture: AAC start failed %d", st);
        AMediaCodec_delete(codec_);
        codec_ = nullptr;
        AAudioStream_close(stream);
        stream_ = nullptr;
        return false;
    }

    ares = AAudioStream_requestStart(stream);
    if (ares != AAUDIO_OK) {
        LOGE("AudioCapture: requestStart failed %d (%s)", ares, AAudio_convertResultToText(ares));
        AMediaCodec_stop(codec_);
        AMediaCodec_delete(codec_);
        codec_ = nullptr;
        AAudioStream_close(stream);
        stream_ = nullptr;
        return false;
    }

    totalFramesRead_ = 0;
    anchorNs_ = -1;
    peakL_.store(0.0f, std::memory_order_relaxed);
    peakR_.store(0.0f, std::memory_order_relaxed);
    running_.store(true, std::memory_order_release);
    thread_ = std::thread(&AudioCapture::captureLoop, this);
    LOGI("AudioCapture: started 48kHz stereo PCM16 -> AAC-LC %d kbps", kBitrateBps / 1000);
    return true;
}

void AudioCapture::captureLoop() {
    auto* stream = static_cast<AAudioStream*>(stream_);
    std::vector<int16_t> chunk(static_cast<size_t>(kChunkFrames) * kChannelCount);

    while (running_.load(std::memory_order_acquire)) {
        aaudio_result_t framesRead = AAudioStream_read(
            stream, chunk.data(), kChunkFrames, 20'000'000L /* 20ms timeout, ns */);
        if (framesRead < 0) {
            LOGW("AudioCapture: read error %d (%s)", framesRead,
                 AAudio_convertResultToText(static_cast<aaudio_result_t>(framesRead)));
            continue;
        }
        if (framesRead == 0) continue;

        const int64_t framesBefore = totalFramesRead_;
        if (anchorNs_ < 0) {
            anchorNs_ = nowBootNs() - static_cast<int64_t>((double)framesRead * 1e9 / kSampleRate);
        }
        const int64_t ptsNs =
            anchorNs_ + static_cast<int64_t>((double)framesBefore * 1e9 / kSampleRate);
        totalFramesRead_ += framesRead;

        float peakL = 0.0f, peakR = 0.0f;
        for (int32_t i = 0; i < framesRead; i++) {
            const float l = std::abs((float)chunk[i * 2]) / 32767.0f;
            const float r = std::abs((float)chunk[i * 2 + 1]) / 32767.0f;
            if (l > peakL) peakL = l;
            if (r > peakR) peakR = r;
        }
        float prevL = peakL_.load(std::memory_order_relaxed);
        while (peakL > prevL && !peakL_.compare_exchange_weak(prevL, peakL)) {
        }
        float prevR = peakR_.load(std::memory_order_relaxed);
        while (peakR > prevR && !peakR_.compare_exchange_weak(prevR, peakR)) {
        }

        queuePcm(reinterpret_cast<const uint8_t*>(chunk.data()),
                 (size_t)framesRead * kChannelCount * sizeof(int16_t), ptsNs / 1000, false);
        drainEncoder(false);
    }

    // Final flush: signal EOS to the encoder and drain everything it has left.
    const int64_t eosPtsUs =
        anchorNs_ >= 0
            ? (anchorNs_ + (int64_t)((double)totalFramesRead_ * 1e9 / kSampleRate)) / 1000
            : 0;
    queuePcm(nullptr, 0, eosPtsUs, true);
    drainEncoder(true);
}

void AudioCapture::queuePcm(const uint8_t* data, size_t bytes, int64_t ptsUs, bool eos) {
    if (!codec_) return;
    ssize_t idx = AMediaCodec_dequeueInputBuffer(codec_, eos ? kEosTimeoutUs : 10000);
    if (idx < 0) {
        if (!eos) {
            LOGW("AudioCapture: no input buffer available, dropping chunk");
            return;
        }
        LOGW("AudioCapture: no input buffer for EOS signal");
        return;
    }
    size_t bufSize = 0;
    uint8_t* buf = AMediaCodec_getInputBuffer(codec_, idx, &bufSize);
    size_t toCopy = std::min(bytes, bufSize);
    if (buf && data && toCopy > 0) memcpy(buf, data, toCopy);
    const uint32_t flags = eos ? AMEDIACODEC_BUFFER_FLAG_END_OF_STREAM : 0;
    AMediaCodec_queueInputBuffer(codec_, idx, 0, toCopy, ptsUs, flags);
}

void AudioCapture::drainEncoder(bool endOfStream) {
    if (!codec_) return;
    const int64_t timeout = endOfStream ? kEosTimeoutUs : kDequeueTimeoutUs;
    while (true) {
        AMediaCodecBufferInfo info;
        ssize_t idx = AMediaCodec_dequeueOutputBuffer(codec_, &info, timeout);
        if (idx == AMEDIACODEC_INFO_TRY_AGAIN_LATER) {
            if (!endOfStream) break;
            LOGW("AudioCapture: EOS drain timeout");
            break;
        } else if (idx == AMEDIACODEC_INFO_OUTPUT_FORMAT_CHANGED) {
            AMediaFormat* ofmt = AMediaCodec_getOutputFormat(codec_);
            std::lock_guard<std::mutex> l(formatM_);
            if (pendingFormat_) AMediaFormat_delete(pendingFormat_);
            pendingFormat_ = ofmt;
        } else if (idx == AMEDIACODEC_INFO_OUTPUT_BUFFERS_CHANGED) {
            // ignore
        } else if (idx >= 0) {
            if ((info.flags & AMEDIACODEC_BUFFER_FLAG_CODEC_CONFIG) == 0 && info.size > 0) {
                size_t bufSize = 0;
                uint8_t* buf = AMediaCodec_getOutputBuffer(codec_, idx, &bufSize);
                if (buf) {
                    AudioSample sample;
                    sample.data.assign(buf, buf + info.size);
                    sample.ptsUs = info.presentationTimeUs;
                    sample.flags = info.flags;
                    std::lock_guard<std::mutex> l(queueM_);
                    if (queue_.size() < kMaxQueue) {
                        queue_.push_back(std::move(sample));
                    } else {
                        LOGW("AudioCapture: sample queue full (%zu), dropping audio sample",
                             queue_.size());
                    }
                }
            }
            AMediaCodec_releaseOutputBuffer(codec_, idx, false);
            if (info.flags & AMEDIACODEC_BUFFER_FLAG_END_OF_STREAM) break;
        }
    }
}

void AudioCapture::stop() {
    running_.store(false, std::memory_order_release);
    if (thread_.joinable()) thread_.join();

    if (codec_) {
        AMediaCodec_stop(codec_);
        AMediaCodec_delete(codec_);
        codec_ = nullptr;
    }
    if (stream_) {
        auto* stream = static_cast<AAudioStream*>(stream_);
        AAudioStream_requestStop(stream);
        AAudioStream_close(stream);
        stream_ = nullptr;
    }
    LOGI("AudioCapture: stopped");
}

AMediaFormat* AudioCapture::takeFormat() {
    std::lock_guard<std::mutex> l(formatM_);
    if (!pendingFormat_) return nullptr;
    AMediaFormat* f = pendingFormat_;
    pendingFormat_ = nullptr;
    return f;
}

bool AudioCapture::popSample(AudioSample* out) {
    std::lock_guard<std::mutex> l(queueM_);
    if (queue_.empty()) return false;
    *out = std::move(queue_.front());
    queue_.erase(queue_.begin());
    return true;
}

void AudioCapture::getLevels(float* outLeft, float* outRight) {
    *outLeft = peakL_.exchange(0.0f, std::memory_order_relaxed);
    *outRight = peakR_.exchange(0.0f, std::memory_order_relaxed);
}
