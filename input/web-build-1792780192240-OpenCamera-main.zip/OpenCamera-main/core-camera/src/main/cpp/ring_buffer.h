#pragma once

#include <atomic>
#include <condition_variable>
#include <cstdint>
#include <memory>
#include <mutex>
#include <vector>

// Preallocated SPSC ring of RAW16 frames. Producer = camera ImageReader
// thread (memcpy out of the HAL buffer, never blocks). Consumer = GL/encoder
// thread. All slot memory is malloc'd native heap — invisible to the JVM GC.
class RingBuffer {
public:
    bool init(int width, int height, int slots);
    void clear();
    void free();

    // Copies one frame in. Returns false (and counts a drop) when full.
    bool push(const uint8_t* src, int rowStrideBytes, int64_t timestampNs);

    // Blocks up to timeoutMs for a frame. Caller must popDone() after use.
    bool pop(uint8_t** data, int64_t* timestampNs, int timeoutMs);
    void popDone();
    void wake();

    int count();
    int64_t dropped() const { return dropped_.load(std::memory_order_relaxed); }

private:
    int width_ = 0, height_ = 0, slots_ = 0;
    size_t frameBytes_ = 0;
    std::vector<std::unique_ptr<uint8_t[]>> buf_;
    std::vector<int64_t> ts_;
    int head_ = 0, tail_ = 0, count_ = 0;
    std::mutex m_;
    std::condition_variable cv_;
    std::atomic<int64_t> dropped_{0};
};
