#include "dng_writer.h"

#include <algorithm>
#include <cerrno>
#include <cmath>
#include <cstdio>
#include <cstring>

#include <fcntl.h>
#include <unistd.h>

#include "log_util.h"

namespace {

void putU16(std::vector<uint8_t>& v, uint16_t x) {
    v.push_back(static_cast<uint8_t>(x & 0xFF));
    v.push_back(static_cast<uint8_t>((x >> 8) & 0xFF));
}

void putU32(std::vector<uint8_t>& v, uint32_t x) {
    v.push_back(static_cast<uint8_t>(x & 0xFF));
    v.push_back(static_cast<uint8_t>((x >> 8) & 0xFF));
    v.push_back(static_cast<uint8_t>((x >> 16) & 0xFF));
    v.push_back(static_cast<uint8_t>((x >> 24) & 0xFF));
}

void putI32(std::vector<uint8_t>& v, int32_t x) { putU32(v, static_cast<uint32_t>(x)); }

// One 12-byte TIFF IFD entry, pre-serialized value/offset field.
struct RawEntry {
    uint16_t tag;
    uint16_t type;
    uint32_t count;
    uint32_t value;
};

// TIFF field types used below.
constexpr uint16_t kByte = 1;
constexpr uint16_t kAscii = 2;
constexpr uint16_t kShort = 3;
constexpr uint16_t kLong = 4;
constexpr uint16_t kRational = 5;
constexpr uint16_t kSRational = 10;

}  // namespace

bool DngWriter::push(const uint8_t* frame) {
    int slot;
    int64_t idx;
    {
        std::lock_guard<std::mutex> l(m_);
        if (freeSlots_.empty()) {
            dropped_.fetch_add(1, std::memory_order_relaxed);
            return false;
        }
        slot = freeSlots_.back();
        freeSlots_.pop_back();
        idx = nextIndex_.fetch_add(1, std::memory_order_relaxed) + 1;  // file index starts at 1
    }
    memcpy(pool_[slot].get(), frame, frameBytes_);
    {
        std::lock_guard<std::mutex> l(m_);
        queue_.push_back({slot, idx});
    }
    cv_.notify_one();
    return true;
}

void DngWriter::writerLoop() {
    for (;;) {
        int slot;
        int64_t idx;
        {
            std::unique_lock<std::mutex> l(m_);
            cv_.wait(l, [this] { return !queue_.empty() || shuttingDown_; });
            if (queue_.empty()) {
                if (shuttingDown_) return;
                continue;
            }
            slot = queue_.front().slot;
            idx = queue_.front().index;
            queue_.pop_front();
        }
        char path[1024];
        snprintf(path, sizeof(path), "%s/%s_%06lld.dng", dir_.c_str(), stem_.c_str(),
                 static_cast<long long>(idx));
        int fd = open(path, O_CREAT | O_TRUNC | O_WRONLY, 0644);
        if (fd >= 0) {
            ssize_t w1 = write(fd, header_.data(), header_.size());
            ssize_t w2 = write(fd, pool_[slot].get(), frameBytes_);
            close(fd);
            if (w1 == static_cast<ssize_t>(header_.size()) && w2 == static_cast<ssize_t>(frameBytes_)) {
                framesWritten_.fetch_add(1, std::memory_order_relaxed);
            } else {
                LOGE("DngWriter: short write for %s", path);
            }
        } else {
            LOGE("DngWriter: open failed for %s (errno=%d)", path, errno);
        }
        {
            std::lock_guard<std::mutex> l(m_);
            freeSlots_.push_back(slot);
        }
    }
}

void DngWriter::buildHeader(int width, int height, int cfaLayout, int blackLevel, int whiteLevel,
                             const float colorMatrix1[9], int calibrationIlluminant1,
                             const float asShotNeutral[3], const char* cameraModel) {
    constexpr int kNumEntries = 23;
    constexpr uint32_t kIfdOffset = 8;
    // TIFF header (8) + entry count (2) + entries (12 each) + next-IFD ptr (4).
    constexpr uint32_t kDataStart = kIfdOffset + 2 + kNumEntries * 12 + 4;

    // --- Data area for values that don't fit inline (>4 bytes), built first
    // so their absolute offsets are known when the entries are written. ---
    std::vector<uint8_t> data;
    auto appendCString = [&](const char* s) -> uint32_t {
        uint32_t off = kDataStart + static_cast<uint32_t>(data.size());
        size_t len = strlen(s) + 1;  // include NUL
        data.insert(data.end(), s, s + len);
        if (data.size() % 2 != 0) data.push_back(0);  // even-byte alignment
        return off;
    };
    const uint32_t makeOff = appendCString("OpenLumen");
    const uint32_t modelOff = appendCString(cameraModel);

    auto appendSRationals9 = [&](const float m[9]) -> uint32_t {
        uint32_t off = kDataStart + static_cast<uint32_t>(data.size());
        for (int i = 0; i < 9; i++) {
            putI32(data, static_cast<int32_t>(lroundf(m[i] * 10000.0f)));
            putI32(data, 10000);
        }
        return off;
    };
    const uint32_t cm1Off = appendSRationals9(colorMatrix1);

    auto appendRationals3 = [&](const float v[3]) -> uint32_t {
        uint32_t off = kDataStart + static_cast<uint32_t>(data.size());
        for (int i = 0; i < 3; i++) {
            const float clamped = v[i] > 0.0f ? v[i] : 0.0f;
            putU32(data, static_cast<uint32_t>(lroundf(clamped * 10000.0f)));
            putU32(data, 10000);
        }
        return off;
    };
    const uint32_t neutralOff = appendRationals3(asShotNeutral);

    const uint32_t stripOffset = kDataStart + static_cast<uint32_t>(data.size());
    const uint32_t stripByteCount = static_cast<uint32_t>(frameBytes_);

    // Camera2 SENSOR_INFO_COLOR_FILTER_ARRANGEMENT: 0=RGGB,1=GRBG,2=GBRG,3=BGGR.
    // DNG CFAPattern is the 2x2 tile read left-to-right, top-to-bottom, using
    // DNG's color-plane indices 0=R,1=G,2=B.
    uint8_t cfa[4];
    switch (cfaLayout) {
        case 1: cfa[0] = 1; cfa[1] = 0; cfa[2] = 2; cfa[3] = 1; break;  // GRBG
        case 2: cfa[0] = 1; cfa[1] = 2; cfa[2] = 0; cfa[3] = 1; break;  // GBRG
        case 3: cfa[0] = 2; cfa[1] = 1; cfa[2] = 1; cfa[3] = 0; break;  // BGGR
        default: cfa[0] = 0; cfa[1] = 1; cfa[2] = 1; cfa[3] = 2; break; // RGGB
    }

    auto bytes4 = [](uint8_t b0, uint8_t b1, uint8_t b2, uint8_t b3) -> uint32_t {
        return static_cast<uint32_t>(b0) | (static_cast<uint32_t>(b1) << 8) |
               (static_cast<uint32_t>(b2) << 16) | (static_cast<uint32_t>(b3) << 24);
    };
    auto shortPair = [](uint16_t a, uint16_t b) -> uint32_t {
        return static_cast<uint32_t>(a) | (static_cast<uint32_t>(b) << 16);
    };

    std::vector<RawEntry> entries;
    entries.reserve(kNumEntries);
    entries.push_back({254, kLong, 1, 0});                                              // NewSubfileType
    entries.push_back({256, kLong, 1, static_cast<uint32_t>(width)});                    // ImageWidth
    entries.push_back({257, kLong, 1, static_cast<uint32_t>(height)});                   // ImageLength
    entries.push_back({258, kShort, 1, 16});                                             // BitsPerSample
    entries.push_back({259, kShort, 1, 1});                                              // Compression (none)
    entries.push_back({262, kShort, 1, 32803});                                          // PhotometricInterpretation (CFA)
    entries.push_back({271, kAscii, static_cast<uint32_t>(strlen("OpenLumen") + 1), makeOff});      // Make
    entries.push_back({272, kAscii, static_cast<uint32_t>(strlen(cameraModel) + 1), modelOff});     // Model
    entries.push_back({273, kLong, 1, stripOffset});                                     // StripOffsets
    entries.push_back({274, kShort, 1, 1});                                              // Orientation
    entries.push_back({277, kShort, 1, 1});                                              // SamplesPerPixel
    entries.push_back({278, kLong, 1, static_cast<uint32_t>(height)});                   // RowsPerStrip
    entries.push_back({279, kLong, 1, stripByteCount});                                  // StripByteCounts
    entries.push_back({284, kShort, 1, 1});                                              // PlanarConfiguration
    entries.push_back({33421, kShort, 2, shortPair(2, 2)});                              // CFARepeatPatternDim
    entries.push_back({33422, kByte, 4, bytes4(cfa[0], cfa[1], cfa[2], cfa[3])});         // CFAPattern
    entries.push_back({50706, kByte, 4, bytes4(1, 4, 0, 0)});                             // DNGVersion 1.4.0.0
    entries.push_back({50708, kAscii, static_cast<uint32_t>(strlen(cameraModel) + 1), modelOff}); // UniqueCameraModel
    entries.push_back({50714, kShort, 1, static_cast<uint32_t>(static_cast<uint16_t>(blackLevel))}); // BlackLevel
    entries.push_back({50717, kLong, 1, static_cast<uint32_t>(whiteLevel)});              // WhiteLevel
    entries.push_back({50721, kSRational, 9, cm1Off});                                    // ColorMatrix1
    entries.push_back({50728, kRational, 3, neutralOff});                                 // AsShotNeutral
    entries.push_back({50778, kShort, 1,
                        static_cast<uint32_t>(static_cast<uint16_t>(calibrationIlluminant1))}); // CalibrationIlluminant1

    std::sort(entries.begin(), entries.end(),
              [](const RawEntry& a, const RawEntry& b) { return a.tag < b.tag; });

    header_.clear();
    header_.reserve(kDataStart + data.size());
    header_.push_back('I');
    header_.push_back('I');
    putU16(header_, 42);
    putU32(header_, kIfdOffset);
    putU16(header_, static_cast<uint16_t>(entries.size()));
    for (const auto& e : entries) {
        putU16(header_, e.tag);
        putU16(header_, e.type);
        putU32(header_, e.count);
        putU32(header_, e.value);
    }
    putU32(header_, 0);  // no next IFD
    header_.insert(header_.end(), data.begin(), data.end());
}

bool DngWriter::start(const char* dirPath, const char* stem, int width, int height, int cfaLayout,
                       int blackLevel, int whiteLevel, const float colorMatrix1[9],
                       int calibrationIlluminant1, const float asShotNeutral[3],
                       const char* cameraModel) {
    dir_ = dirPath;
    stem_ = stem;
    frameBytes_ = static_cast<size_t>(width) * height * 2;
    if (frameBytes_ == 0) return false;

    // ~256 MB budget, 4-10 slots.
    int64_t poolSize = 268435456LL / static_cast<int64_t>(frameBytes_);
    if (poolSize < 4) poolSize = 4;
    if (poolSize > 10) poolSize = 10;

    pool_.clear();
    pool_.resize(static_cast<size_t>(poolSize));
    freeSlots_.clear();
    for (size_t i = 0; i < pool_.size(); i++) {
        pool_[i].reset(new (std::nothrow) uint8_t[frameBytes_]);
        if (!pool_[i]) {
            LOGE("DngWriter: OOM allocating pool slot %zu (%zu bytes)", i, frameBytes_);
            pool_.clear();
            return false;
        }
        freeSlots_.push_back(static_cast<int>(i));
    }
    queue_.clear();
    nextIndex_.store(0);
    framesWritten_.store(0);
    dropped_.store(0);
    shuttingDown_ = false;

    buildHeader(width, height, cfaLayout, blackLevel, whiteLevel, colorMatrix1,
                calibrationIlluminant1, asShotNeutral, cameraModel);

    writers_.clear();
    for (int i = 0; i < kWriterThreads; i++) writers_.emplace_back(&DngWriter::writerLoop, this);

    LOGI("DngWriter: start %dx%d pool=%zu frameBytes=%zu header=%zu bytes",
         width, height, pool_.size(), frameBytes_, header_.size());
    return true;
}

int64_t DngWriter::stop() {
    {
        std::lock_guard<std::mutex> l(m_);
        shuttingDown_ = true;
    }
    cv_.notify_all();
    for (auto& t : writers_) {
        if (t.joinable()) t.join();
    }
    writers_.clear();
    pool_.clear();
    freeSlots_.clear();
    queue_.clear();
    shuttingDown_ = false;

    const int64_t written = framesWritten_.load(std::memory_order_relaxed);
    LOGI("DngWriter: stop, wrote %lld frames, dropped %lld", static_cast<long long>(written),
         static_cast<long long>(dropped_.load(std::memory_order_relaxed)));
    framesWritten_.store(0);
    dropped_.store(0);
    nextIndex_.store(0);
    return written;
}
