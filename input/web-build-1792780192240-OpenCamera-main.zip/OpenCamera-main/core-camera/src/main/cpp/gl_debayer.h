#pragma once

#include <cstdint>

#include <EGL/egl.h>
#include <EGL/eglext.h>
#include <GLES3/gl3.h>

struct ANativeWindow;

// Per-frame look parameters, written by JNI setters, read on the GL thread.
struct LookParams {
    int logProfile = 0;      // 0 CINE_FLAT, 1 CINE_STD, 2 REC709, 3 ACES_CCT
    bool falseColor = false;
    bool zebras = false;
    float zebraHi = 0.95f;   // fraction of full scale
    bool peaking = false;
    float peakGain = 1.0f;
    // Row-major 3x3, applied to linear camera RGB right after debayer.
    // Identity = raw camera RGB (no IDT).
    float colorMat[9] = {1.f, 0.f, 0.f, 0.f, 1.f, 0.f, 0.f, 0.f, 1.f};
    // Per-channel white-balance gain applied right after debayer, before
    // colorMat. Identity = {1,1,1} (no WB correction).
    float wbGain[3] = {1.f, 1.f, 1.f};
    int   hotPixel = 0;       // 0 off, 1 on
    float sharpen  = 0.f;     // unsharp amount, 0 = off
    float denoise  = 0.f;     // 0..1 spatial denoise blend, 0 = off
    int   lensShadingOn = 0;  // 0 off, 1 on (applied only when a map is uploaded)
};

// GLES3 debayer + look pipeline. One context owned by the render thread, a
// 1x1 pbuffer keeps it current with no window attached; the viewfinder and
// the encoder input are two window surfaces sharing the same context, so a
// RAW frame is uploaded once per frame and drawn to both.
class GlDebayer {
public:
    // Create display/context/program on the calling (render) thread.
    bool initContext();
    void destroyContext();

    // (Re)allocate the R16UI source texture for a new sensor configuration.
    bool configureSource(int rawW, int rawH, float blackLevel, float whiteLevel,
                         int cfaPattern);

    // Viewfinder surface. Pass nullptr to detach. Takes ownership of window.
    void setPreviewWindow(ANativeWindow* window);
    // Encoder input surface (from AMediaCodec). Does NOT own the window.
    bool setEncoderWindow(ANativeWindow* window, int outW, int outH);
    void clearEncoderWindow();

    bool hasPreview() const { return previewSurface_ != EGL_NO_SURFACE; }
    bool hasEncoder() const { return encoderSurface_ != EGL_NO_SURFACE; }

    // Upload one RAW16 frame (once per frame, shared by both draw passes).
    void uploadFrame(const uint8_t* raw16);

    // Letterboxed draw to the viewfinder with scopes enabled.
    bool drawPreview(const LookParams& look);
    // Clean log draw to the encoder surface with a presentation timestamp.
    bool drawEncoder(const LookParams& look, int64_t presentationTimeNs);

    // Upload a size*size*size*3 RGB LUT as a GL_TEXTURE_3D. Render-thread only.
    bool uploadLut(const float* data, int size);
    void clearLut();

    bool uploadShadingMap(const float* rgb, int cols, int rows);
    void clearShadingMap();

private:
    GLuint compile(GLenum type, const char* src);
    // allowLut: only the preview draw samples the grading LUT; the encoder
    // stays a clean flat-log signal even when a LUT is selected.
    void applyUniforms(const LookParams& look, bool scopes, bool allowLut);

    EGLDisplay display_ = EGL_NO_DISPLAY;
    EGLConfig config_ = nullptr;
    EGLContext context_ = EGL_NO_CONTEXT;
    EGLSurface pbuffer_ = EGL_NO_SURFACE;
    EGLSurface previewSurface_ = EGL_NO_SURFACE;
    EGLSurface encoderSurface_ = EGL_NO_SURFACE;
    ANativeWindow* previewWindow_ = nullptr;
    PFNEGLPRESENTATIONTIMEANDROIDPROC presentationTime_ = nullptr;

    GLuint program_ = 0;
    GLuint texture_ = 0;
    GLuint vao_ = 0;
    int uLog_ = -1, uFalse_ = -1, uZebra_ = -1, uZebraHi_ = -1;
    int uPeak_ = -1, uPeakGain_ = -1, uRange_ = -1;
    int uColorMat_ = -1, uLutEnabled_ = -1, uLutSize_ = -1;
    int uWbGain_ = -1;
    int uHotPixel_ = -1, uSharpen_ = -1, uDenoise_ = -1, uShading_ = -1;
    GLuint shadingTex_ = 0; int shadingCols_ = 0, shadingRows_ = 0;

    GLuint lutTex_ = 0;
    int lutSize_ = 0;

    int rawW_ = 0, rawH_ = 0, outW_ = 0, outH_ = 0;
    float black_ = 64.0f, white_ = 1023.0f;
    int cfa_ = 0;
};
